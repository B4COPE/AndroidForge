#!/usr/bin/env bash
# Reference bootstrap script for Oracle Cloud Infrastructure (OCI) Always Free Ampere A1 VM
# (4 OCPUs ARM64, 24 GB RAM, Ubuntu 22.04/24.04).
# Review carefully before running on your own OCI instance.

set -euo pipefail

echo "=== 1. Updating packages & installing Docker ==="
sudo apt-get update -y
sudo apt-get install -y ca-certificates curl gnupg ufw
if ! command -v docker >/dev/null 2>&1; then
  curl -fsSL https://get.docker.com | sh
  sudo usermod -aG docker "$USER"
fi

echo "=== 2. Hardening host firewall (SSH + TLS reverse proxy only) ==="
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable

echo "=== 3. Preparing JAMES .env ==="
if [ ! -f .env ]; then
  cp .env.example .env
  GEN_TOKEN="$(openssl rand -hex 32)"
  sed -i "s/^JAMES_BACKEND_TOKEN=.*/JAMES_BACKEND_TOKEN=${GEN_TOKEN}/" .env
  sed -i "s/^PRIMARY_MODEL=.*/PRIMARY_MODEL=gemma3:4b-it/" .env
  echo "Generated JAMES_BACKEND_TOKEN in .env (keep this secret!)."
fi

echo "=== 4. Starting JAMES Core + Ollama (ARM64 CPU quantized model) ==="
docker compose --profile ollama up -d --build
echo "Optional: pull quantized Gemma 3 4B inside Ollama:"
echo "  docker exec -it james-ollama-runtime ollama pull gemma3:4b-it"
echo "Place Caddy or Nginx TLS reverse proxy in front of port 8787 for HTTPS access from Android."
