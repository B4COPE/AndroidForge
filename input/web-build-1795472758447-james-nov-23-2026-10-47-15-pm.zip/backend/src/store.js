import fs from "node:fs";
import path from "node:path";
import { resolveSafePath } from "./security.js";

const DEFAULT_STATE = {
  knowledgeItems: [
    {
      id: "know_james_identity_01",
      title: "JAMES Independent Core Identity & Routing Policy",
      content:
        "JAMES is an independent AI ecosystem founded by Abbas Adel Rahim (Cope / Mark). It prioritizes its primary open-weight model (such as Google Gemma 3 via Ollama/vLLM/llama.cpp) for routine work, reserves commercial APIs and the AI Council for multi-perspective verification, and keeps Private Vault credentials isolated from external providers.",
      category: "architecture",
      source: "JAMES Core Specification",
      sourceType: "system_seed",
      acquiredAtMillis: Date.now(),
      lastVerifiedAtMillis: Date.now(),
      reliabilityScore: 0.98,
      confidence: 0.96,
      topics: ["identity", "routing", "open-weight", "privacy"],
      version: 1,
      validationStatus: "VERIFIED"
    }
  ],
  experiences: [],
  skills: [],
  councilSessions: [],
  proposals: [],
  jobs: [
    {
      id: "job_knowledge_verify",
      name: "Periodic Knowledge Verification",
      taskType: "KNOWLEDGE_VERIFICATION",
      intervalHours: 24,
      enabled: false,
      maxBudgetTokens: 12000,
      lastRunMillis: 0,
      lastStatus: "NEVER_RUN",
      lastSummary: "Disabled by default until operator configures schedule."
    },
    {
      id: "job_architecture_council",
      name: "Scheduled Architecture Review Council",
      taskType: "COUNCIL_REVIEW",
      intervalHours: 168,
      enabled: false,
      maxBudgetTokens: 25000,
      lastRunMillis: 0,
      lastStatus: "NEVER_RUN",
      lastSummary: "Disabled by default."
    }
  ],
  migrations: [],
  storageObjects: {},
  auditLogs: []
};

export class JamesBackendStore {
  constructor(dataDir) {
    this.baseDir = path.resolve(dataDir || "./data");
    fs.mkdirSync(this.baseDir, { recursive: true });
    this.dbFile = resolveSafePath(this.baseDir, "james-core-state.json");
    this.state = this.#load();
  }

  #load() {
    try {
      if (fs.existsSync(this.dbFile)) {
        const parsed = JSON.parse(fs.readFileSync(this.dbFile, "utf8"));
        return { ...structuredClone(DEFAULT_STATE), ...parsed };
      }
    } catch {
      // Corrupt state falls back cleanly
    }
    const fresh = structuredClone(DEFAULT_STATE);
    this.#save(fresh);
    return fresh;
  }

  #save(next = this.state) {
    const tmp = `${this.dbFile}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(next, null, 2), "utf8");
    fs.renameSync(tmp, this.dbFile);
  }

  snapshot() {
    return this.state;
  }

  mutate(fn) {
    const result = fn(this.state);
    this.#save(this.state);
    return result;
  }

  appendLog(level, component, message) {
    this.mutate((s) => {
      s.auditLogs.unshift({
        id: `log_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`,
        level,
        component,
        message,
        timestampMillis: Date.now()
      });
      if (s.auditLogs.length > 300) {
        s.auditLogs.length = 300;
      }
    });
  }
}
