import crypto from "node:crypto";
import http from "node:http";
import { CouncilEngine } from "./councilEngine.js";
import { KnowledgeEngine } from "./knowledgeEngine.js";
import { LearningEngine } from "./learningEngine.js";
import { ModelRouter } from "./modelRouter.js";
import { JobScheduler } from "./scheduler.js";
import { verifyBearerToken } from "./security.js";
import { McpClientManager, SkillsManager } from "./skillsAndMcp.js";
import { MigrationManager, STORAGE_PROVIDERS } from "./storageAndMigration.js";
import { JamesBackendStore } from "./store.js";

function readJsonBody(req, maxBytes = 1_048_576) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error("Request payload too large."));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      try {
        const raw = Buffer.concat(chunks).toString("utf8").trim();
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error("Invalid JSON body."));
      }
    });
    req.on("error", reject);
  });
}

function sendJson(res, status, data) {
  const payload = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(payload);
}

export function createJamesBackend({
  dataDir = process.env.JAMES_DATA_DIR || "./data",
  authToken = process.env.JAMES_BACKEND_TOKEN || crypto.randomBytes(24).toString("hex"),
  modelRouter = new ModelRouter(),
  fetchImpl = globalThis.fetch
} = {}) {
  const store = new JamesBackendStore(dataDir);
  const knowledgeEngine = new KnowledgeEngine(store);
  const learningEngine = new LearningEngine(store, knowledgeEngine);
  const councilEngine = new CouncilEngine(store, modelRouter, knowledgeEngine);
  const skillsManager = new SkillsManager(store);
  const mcpManager = new McpClientManager(store, fetchImpl);
  const migrationManager = new MigrationManager(store);
  const scheduler = new JobScheduler(store, learningEngine);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url || "/", "http://localhost");

    if (req.method === "GET" && url.pathname === "/health") {
      return sendJson(res, 200, {
        status: "ok",
        service: "JAMES Cloud Core",
        version: "2.0.0",
        founder: "Abbas Adel Rahim (Cope / Mark)",
        primaryRuntime: modelRouter.config.primaryRuntime,
        primaryModel: modelRouter.config.primaryModel,
        primaryConfigured: Boolean(modelRouter.config.primaryEndpoint),
        availableParticipants: modelRouter.describeAvailableParticipants(),
        storageProviders: STORAGE_PROVIDERS
      });
    }

    // All /api/v1/* endpoints require verified Bearer token
    if (!verifyBearerToken(req.headers.authorization, authToken)) {
      return sendJson(res, 401, { error: "Unauthorized: valid JAMES Bearer token required." });
    }

    try {
      // JAMES Core Orchestration endpoint
      if (req.method === "POST" && url.pathname === "/api/v1/core/respond") {
        const body = await readJsonBody(req);
        const route = modelRouter.selectRoute({
          prompt: body.prompt,
          policy: body.routingPolicy || "PRIMARY_FIRST",
          isSecuritySensitive: Boolean(body.isSecuritySensitive)
        });
        const retrieved = knowledgeEngine.retrieveRelevant(body.prompt, 3);
        const contextStr = retrieved
          .map((r) => `- [${r.item.title}] (${r.item.validationStatus}): ${r.matchedExcerpt}`)
          .join("\n");

        const result = await modelRouter.invokeProvider({
          providerType: body.providerType || "JAMES_PRIMARY_OPEN_WEIGHT",
          runtime: body.runtime,
          endpoint: body.endpoint,
          model: body.model,
          apiKey: body.apiKey,
          systemPrompt: [
            "You are JAMES Core, an independent AI system.",
            contextStr ? `Retrieved Verified Knowledge:\n${contextStr}` : ""
          ]
            .filter(Boolean)
            .join("\n\n"),
          messages: Array.isArray(body.messages) && body.messages.length > 0
            ? body.messages
            : [{ role: "user", content: String(body.prompt || "") }]
        });

        return sendJson(res, 200, {
          route,
          retrievedKnowledgeCount: retrieved.length,
          response: result
        });
      }

      // Knowledge Repository
      if (req.method === "GET" && url.pathname === "/api/v1/knowledge") {
        return sendJson(res, 200, { items: store.snapshot().knowledgeItems });
      }
      if (req.method === "POST" && url.pathname === "/api/v1/knowledge") {
        const body = await readJsonBody(req);
        const ingested = knowledgeEngine.ingestDocument(body);
        return sendJson(res, ingested.duplicate ? 200 : 201, ingested);
      }
      if (req.method === "POST" && url.pathname === "/api/v1/knowledge/search") {
        const body = await readJsonBody(req);
        const matches = knowledgeEngine.retrieveRelevant(body.query, body.limit || 5);
        return sendJson(res, 200, { matches });
      }

      // Learning Engine
      if (req.method === "POST" && url.pathname === "/api/v1/learning/run") {
        const report = learningEngine.runAnalysisCycle();
        return sendJson(res, 200, { report });
      }
      if (req.method === "POST" && url.pathname === "/api/v1/learning/experiences") {
        const body = await readJsonBody(req);
        const exp = learningEngine.recordExperience(body);
        return sendJson(res, 201, { experience: exp });
      }

      // AI Council
      if (req.method === "GET" && url.pathname === "/api/v1/council/sessions") {
        return sendJson(res, 200, {
          sessions: store.snapshot().councilSessions,
          proposals: store.snapshot().proposals
        });
      }
      if (req.method === "POST" && url.pathname === "/api/v1/council/sessions") {
        const body = await readJsonBody(req);
        const out = await councilEngine.runSession(body);
        return sendJson(res, 201, out);
      }
      const proposalMatch = url.pathname.match(/^\/api\/v1\/council\/proposals\/([^/]+)\/decision$/);
      if (req.method === "POST" && proposalMatch) {
        const body = await readJsonBody(req);
        const updated = councilEngine.decideProposal(proposalMatch[1], body.decision);
        if (!updated) return sendJson(res, 404, { error: "Proposal not found." });
        return sendJson(res, 200, { proposal: updated });
      }

      // Skills & MCP
      if (req.method === "GET" && url.pathname === "/api/v1/skills") {
        return sendJson(res, 200, { skills: store.snapshot().skills });
      }
      if (req.method === "POST" && url.pathname === "/api/v1/skills") {
        const body = await readJsonBody(req);
        const installed = skillsManager.installSkill(body);
        return sendJson(res, 201, installed);
      }
      if (req.method === "POST" && url.pathname === "/api/v1/mcp/inspect") {
        const body = await readJsonBody(req);
        const inspected = await mcpManager.inspectServer(body);
        return sendJson(res, 200, inspected);
      }

      // Migration & Scheduler & Logs
      if (req.method === "POST" && url.pathname === "/api/v1/migration/run") {
        const body = await readJsonBody(req);
        const record = migrationManager.runMigration(body);
        return sendJson(res, 200, { migration: record });
      }
      if (req.method === "POST" && url.pathname.startsWith("/api/v1/migration/") && url.pathname.endsWith("/rollback")) {
        const id = url.pathname.split("/")[4];
        const rolled = migrationManager.rollbackMigration(id);
        if (!rolled) return sendJson(res, 404, { error: "Migration record not found." });
        return sendJson(res, 200, { migration: rolled });
      }
      if (req.method === "GET" && url.pathname === "/api/v1/jobs") {
        return sendJson(res, 200, { jobs: store.snapshot().jobs });
      }
      if (req.method === "POST" && url.pathname.startsWith("/api/v1/jobs/") && url.pathname.endsWith("/run")) {
        const id = url.pathname.split("/")[4];
        const job = await scheduler.runJobNow(id);
        return sendJson(res, 200, { job });
      }
      if (req.method === "GET" && url.pathname === "/api/v1/logs") {
        return sendJson(res, 200, { logs: store.snapshot().auditLogs });
      }

      return sendJson(res, 404, { error: "Endpoint not found." });
    } catch (err) {
      store.appendLog("ERROR", "Server", err.message);
      return sendJson(res, 400, { error: err.message });
    }
  });

  return {
    server,
    store,
    knowledgeEngine,
    learningEngine,
    councilEngine,
    skillsManager,
    mcpManager,
    migrationManager,
    scheduler,
    authToken
  };
}

// Start HTTP listener when executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.env.PORT || 8787);
  const host = process.env.HOST || "0.0.0.0";
  const app = createJamesBackend();
  app.scheduler.start(60_000);
  app.server.listen(port, host, () => {
    const tokenStatus = process.env.JAMES_BACKEND_TOKEN
      ? "configured via env"
      : `auto-generated ephemeral dev token (${app.authToken.slice(0, 6)}...)`;
    console.log(`JAMES Cloud Core listening on http://${host}:${port} [auth: ${tokenStatus}]`);
  });
}
