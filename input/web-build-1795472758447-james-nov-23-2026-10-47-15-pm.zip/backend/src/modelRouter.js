import { redactSecrets, validateOutboundUrl } from "./security.js";

/**
 * Standardized Model Abstraction Layer for JAMES Cloud Core.
 * Decouples JAMES identity, routing, and orchestration from any specific runtime or vendor.
 */
export class ModelRouter {
  constructor(config = {}, fetchImpl = globalThis.fetch) {
    this.config = {
      primaryRuntime: config.primaryRuntime || process.env.PRIMARY_RUNTIME || "ollama",
      primaryEndpoint: config.primaryEndpoint || process.env.PRIMARY_ENDPOINT || "",
      primaryModel: config.primaryModel || process.env.PRIMARY_MODEL || "gemma3:12b-it",
      allowLocalEndpoints:
        config.allowLocalEndpoints ?? (process.env.ALLOW_LOCAL_MODEL_ENDPOINTS === "true"),
      openAiKey: config.openAiKey || process.env.OPENAI_API_KEY || "",
      anthropicKey: config.anthropicKey || process.env.ANTHROPIC_API_KEY || "",
      deepSeekKey: config.deepSeekKey || process.env.DEEPSEEK_API_KEY || "",
      geminiKey: config.geminiKey || process.env.GEMINI_API_KEY || ""
    };
    this.fetch = fetchImpl;
  }

  describeAvailableParticipants() {
    const participants = [];
    if (this.config.primaryEndpoint && this.config.primaryRuntime !== "none") {
      participants.push({
        id: "james_primary",
        name: `JAMES Primary (${this.config.primaryModel})`,
        providerType: "JAMES_PRIMARY_OPEN_WEIGHT",
        runtime: this.config.primaryRuntime,
        isSelfHosted: true,
        configured: true
      });
    }
    if (this.config.openAiKey) {
      participants.push({
        id: "openai",
        name: "OpenAI",
        providerType: "OPENAI",
        runtime: "CLOUD_API",
        isSelfHosted: false,
        configured: true
      });
    }
    if (this.config.anthropicKey) {
      participants.push({
        id: "anthropic",
        name: "Anthropic Claude",
        providerType: "ANTHROPIC",
        runtime: "CLOUD_API",
        isSelfHosted: false,
        configured: true
      });
    }
    if (this.config.deepSeekKey) {
      participants.push({
        id: "deepseek",
        name: "DeepSeek",
        providerType: "DEEPSEEK",
        runtime: "CLOUD_API",
        isSelfHosted: false,
        configured: true
      });
    }
    if (this.config.geminiKey) {
      participants.push({
        id: "gemini",
        name: "Google Gemini",
        providerType: "GOOGLE_GEMINI",
        runtime: "CLOUD_API",
        isSelfHosted: false,
        configured: true
      });
    }
    return participants;
  }

  selectRoute({ prompt, policy = "PRIMARY_FIRST", isSecuritySensitive = false }) {
    const lower = String(prompt || "").toLowerCase();
    const isComplex =
      lower.length > 420 ||
      /(architect|compare|research|audit|security|vulnerability|design system|multi-step)/.test(lower);

    if (policy === "COUNCIL_RESEARCH" || (policy === "BALANCED_HYBRID" && isComplex)) {
      return {
        mode: "COUNCIL_OR_MULTI",
        reason: isSecuritySensitive
          ? "Security-sensitive task requires verification"
          : "Complex analytical task benefits from multi-model verification"
      };
    }
    return {
      mode: "PRIMARY_MODEL",
      reason: "Routine or context-grounded task routed to JAMES Primary Open-Weight Engine"
    };
  }

  async invokeProvider(providerRequest) {
    const {
      providerType = "JAMES_PRIMARY_OPEN_WEIGHT",
      runtime = this.config.primaryRuntime,
      endpoint,
      model,
      apiKey,
      systemPrompt = "",
      messages = [],
      temperature = 0.7
    } = providerRequest;

    if (providerType === "JAMES_PRIMARY_OPEN_WEIGHT") {
      const targetEndpoint = endpoint || this.config.primaryEndpoint;
      const targetModel = model || this.config.primaryModel;
      if (!targetEndpoint || runtime === "none") {
        throw new Error(
          "No open-weight inference server is configured on this backend. Set PRIMARY_ENDPOINT (Ollama, llama.cpp, or vLLM) to run JAMES independently."
        );
      }
      const safeUrl = validateOutboundUrl(targetEndpoint, {
        allowPrivateLocal: this.config.allowLocalEndpoints
      });

      if (runtime === "ollama") {
        const chatUrl = safeUrl.replace(/\/$/, "") + "/api/chat";
        const body = {
          model: targetModel,
          stream: false,
          options: { temperature },
          messages: [
            ...(systemPrompt ? [{ role: "system", content: systemPrompt }] : []),
            ...messages
          ]
        };
        const resp = await this.fetch(chatUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        if (!resp.ok) {
          throw new Error(`Ollama error (${resp.status}): ${redactSecrets(await resp.text())}`);
        }
        const json = await resp.json();
        return {
          text: json?.message?.content || "",
          model: targetModel,
          providerType,
          isSelfHosted: true,
          estimatedTokens: Math.ceil(((json?.message?.content || "").length + JSON.stringify(messages).length) / 4)
        };
      }

      // llama.cpp server & vLLM expose OpenAI-compatible /v1/chat/completions
      return this.#invokeOpenAiCompatible({
        url: safeUrl.replace(/\/$/, "") + "/v1/chat/completions",
        apiKey: apiKey || "",
        model: targetModel,
        systemPrompt,
        messages,
        temperature,
        providerType,
        isSelfHosted: true
      });
    }

    if (providerType === "OPENAI" || providerType === "DEEPSEEK" || providerType === "CUSTOM_OPENAI") {
      const key =
        apiKey ||
        (providerType === "OPENAI" ? this.config.openAiKey : this.config.deepSeekKey);
      if (!key) {
        throw new Error(`${providerType} API key is not configured.`);
      }
      const defaultEndpoint =
        providerType === "DEEPSEEK"
          ? "https://api.deepseek.com/v1/chat/completions"
          : "https://api.openai.com/v1/chat/completions";
      const targetUrl = validateOutboundUrl(endpoint || defaultEndpoint, {
        allowPrivateLocal: false
      });
      return this.#invokeOpenAiCompatible({
        url: targetUrl,
        apiKey: key,
        model: model || (providerType === "DEEPSEEK" ? "deepseek-chat" : "gpt-4o-mini"),
        systemPrompt,
        messages,
        temperature,
        providerType,
        isSelfHosted: false
      });
    }

    if (providerType === "ANTHROPIC") {
      const key = apiKey || this.config.anthropicKey;
      if (!key) throw new Error("Anthropic API key is not configured.");
      const targetUrl = validateOutboundUrl(endpoint || "https://api.anthropic.com/v1/messages");
      const resp = await this.fetch(targetUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": key,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: model || "claude-3-5-sonnet-latest",
          max_tokens: 2048,
          system: systemPrompt,
          messages
        })
      });
      if (!resp.ok) {
        throw new Error(`Anthropic error (${resp.status}): ${redactSecrets(await resp.text())}`);
      }
      const json = await resp.json();
      const text = (json?.content || []).map((c) => c.text || "").join("\n");
      return {
        text,
        model: json?.model || model,
        providerType,
        isSelfHosted: false,
        estimatedTokens: (json?.usage?.input_tokens || 0) + (json?.usage?.output_tokens || 0)
      };
    }

    throw new Error(`Unsupported providerType: ${providerType}`);
  }

  async #invokeOpenAiCompatible({
    url,
    apiKey,
    model,
    systemPrompt,
    messages,
    temperature,
    providerType,
    isSelfHosted
  }) {
    const headers = { "Content-Type": "application/json" };
    if (apiKey) headers.Authorization = `Bearer ${apiKey}`;

    const resp = await this.fetch(url, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        temperature,
        messages: [
          ...(systemPrompt ? [{ role: "system", content: systemPrompt }] : []),
          ...messages
        ]
      })
    });
    if (!resp.ok) {
      throw new Error(`${providerType} error (${resp.status}): ${redactSecrets(await resp.text())}`);
    }
    const json = await resp.json();
    const text = json?.choices?.[0]?.message?.content || "";
    const tokens =
      json?.usage?.total_tokens ||
      Math.ceil((text.length + JSON.stringify(messages).length) / 4);
    return {
      text,
      model: json?.model || model,
      providerType,
      isSelfHosted,
      estimatedTokens: tokens
    };
  }
}
