import { sanitizeUntrustedPayload, validateOutboundUrl } from "./security.js";

const DANGEROUS_PATTERNS = [
  { regex: /\b(rm\s+-rf|mkfs|dd\s+if=|chmod\s+777)\b/i, reason: "Destructive shell command pattern detected." },
  { regex: /\b(curl|wget)\b.*\|\s*(sh|bash)/i, reason: "Remote pipe-to-shell execution pattern detected." },
  { regex: /ignore\s+previous\s+instructions|system\s+prompt\s+override/i, reason: "Potential prompt-injection directive in skill content." },
  { regex: /eval\(|child_process|Runtime\.getRuntime\(\)\.exec/i, reason: "Arbitrary code execution call requires explicit isolated sandbox." }
];

export class SkillsManager {
  constructor(store) {
    this.store = store;
  }

  inspectSkill({ name, skillMarkdown, permissions = [], hasScripts = false }) {
    const warnings = [];
    for (const rule of DANGEROUS_PATTERNS) {
      if (rule.regex.test(skillMarkdown || "")) {
        warnings.push(rule.reason);
      }
    }
    if (hasScripts) {
      warnings.push("Skill contains scripts: execution remains blocked unless explicitly permitted and isolated.");
    }
    if (permissions.length > 0) {
      warnings.push(`Declared permissions require operator review: ${permissions.join(", ")}`);
    }
    return {
      safeToAutoEnable: warnings.length === 0,
      warnings,
      inspectedAtMillis: Date.now(),
      name: String(name || "unnamed")
    };
  }

  installSkill(skillInput) {
    const inspection = this.inspectSkill(skillInput);
    const skill = {
      id: skillInput.id || `skill_${Date.now()}_${Math.random().toString(16).slice(2, 6)}`,
      name: String(skillInput.name || "").trim(),
      description: String(skillInput.description || "").trim(),
      version: String(skillInput.version || "1.0.0"),
      category: String(skillInput.category || "general"),
      sourceType: String(skillInput.sourceType || "MANUAL"),
      skillMarkdown: String(skillInput.skillMarkdown || ""),
      permissions: Array.isArray(skillInput.permissions) ? skillInput.permissions : [],
      dependencies: Array.isArray(skillInput.dependencies) ? skillInput.dependencies : [],
      enabled: inspection.safeToAutoEnable ? Boolean(skillInput.enabled ?? false) : false,
      inspected: true,
      inspectionWarnings: inspection.warnings,
      updatedAtMillis: Date.now()
    };
    if (!skill.name || !skill.skillMarkdown) {
      throw new Error("Skill requires name and SKILL.md content.");
    }
    this.store.mutate((s) => {
      const idx = s.skills.findIndex((x) => x.id === skill.id || x.name === skill.name);
      if (idx >= 0) s.skills[idx] = skill;
      else s.skills.unshift(skill);
    });
    this.store.appendLog(
      inspection.warnings.length > 0 ? "WARN" : "INFO",
      "SkillsManager",
      `Installed skill "${skill.name}" (enabled=${skill.enabled}, warnings=${inspection.warnings.length}).`
    );
    return { skill, inspection };
  }
}

export class McpClientManager {
  constructor(store, fetchImpl = globalThis.fetch) {
    this.store = store;
    this.fetch = fetchImpl;
  }

  /**
   * Connects to an MCP server over Streamable HTTP (JSON-RPC 2.0 POST)
   * and returns discovered tools/resources/prompts wrapped as untrusted data.
   */
  async inspectServer({ endpointUrl, bearerToken = "", allowLocal = false }) {
    const safeUrl = validateOutboundUrl(endpointUrl, { allowPrivateLocal: allowLocal });
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json, text/event-stream"
    };
    if (bearerToken) headers.Authorization = `Bearer ${bearerToken}`;

    const initResp = await this.fetch(safeUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "initialize",
        params: {
          protocolVersion: "2025-03-26",
          capabilities: {},
          clientInfo: { name: "JAMES-Cloud-Core", version: "2.0.0" }
        }
      })
    });
    if (!initResp.ok) {
      throw new Error(`MCP initialize failed with HTTP ${initResp.status}`);
    }
    const initJson = await initResp.json();

    const toolsResp = await this.fetch(safeUrl, {
      method: "POST",
      headers,
      body: JSON.stringify({ jsonrpc: "2.0", id: 2, method: "tools/list", params: {} })
    });
    const toolsJson = toolsResp.ok ? await toolsResp.json() : { result: { tools: [] } };
    const tools = (toolsJson?.result?.tools || []).map((t) => ({
      name: String(t.name || ""),
      description: sanitizeUntrustedPayload(`mcp_tool:${t.name}`, t.description || ""),
      inputSchema: t.inputSchema || {}
    }));

    this.store.appendLog("INFO", "McpClientManager", `Inspected MCP endpoint ${safeUrl}: ${tools.length} tool(s).`);
    return {
      serverInfo: initJson?.result?.serverInfo || { name: "MCP Server" },
      protocolVersion: initJson?.result?.protocolVersion || "unknown",
      tools
    };
  }
}
