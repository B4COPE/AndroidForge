import { sha256Hex } from "./security.js";

function tokenize(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]+/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 2);
}

export function chunkText(text, maxChars = 650, overlapChars = 100) {
  const clean = String(text || "").trim();
  if (!clean) return [];
  if (clean.length <= maxChars) return [clean];

  const chunks = [];
  let cursor = 0;
  while (cursor < clean.length) {
    const end = Math.min(clean.length, cursor + maxChars);
    chunks.push(clean.slice(cursor, end));
    if (end >= clean.length) break;
    cursor = Math.max(0, end - overlapChars);
  }
  return chunks;
}

export class KnowledgeEngine {
  constructor(store) {
    this.store = store;
  }

  ingestDocument({
    title,
    content,
    category = "technical",
    source = "User Submitted",
    sourceType = "manual",
    reliabilityScore = 0.85,
    confidence = 0.85,
    topics = [],
    validationStatus = "PENDING_REVIEW"
  }) {
    const normalizedTitle = String(title || "").trim();
    const normalizedContent = String(content || "").trim();
    if (!normalizedTitle || !normalizedContent) {
      throw new Error("Knowledge item requires both title and content.");
    }

    const checksum = sha256Hex(`${normalizedTitle}\n${normalizedContent}`);
    const existing = this.store
      .snapshot()
      .knowledgeItems.find((k) => k.checksumSha256 === checksum);
    if (existing) {
      return { item: existing, duplicate: true };
    }

    const chunks = chunkText(normalizedContent);
    const now = Date.now();
    const item = {
      id: `know_${now}_${Math.random().toString(16).slice(2, 8)}`,
      title: normalizedTitle,
      content: normalizedContent,
      category,
      source,
      sourceType,
      acquiredAtMillis: now,
      lastVerifiedAtMillis: now,
      reliabilityScore: Math.min(1, Math.max(0, reliabilityScore)),
      confidence: Math.min(1, Math.max(0, confidence)),
      topics: Array.isArray(topics) ? topics : [],
      version: 1,
      validationStatus,
      chunkCount: chunks.length,
      checksumSha256: checksum
    };

    this.store.mutate((s) => {
      s.knowledgeItems.unshift(item);
    });
    this.store.appendLog("INFO", "KnowledgeEngine", `Ingested "${normalizedTitle}" (${chunks.length} chunks).`);
    return { item, duplicate: false };
  }

  retrieveRelevant(query, limit = 5) {
    const qTokens = tokenize(query);
    if (qTokens.length === 0) return [];

    const items = this.store.snapshot().knowledgeItems;
    if (items.length === 0) return [];

    // Compute IDF over indexed items
    const docFreq = new Map();
    const itemDocs = items.map((item) => {
      const tokens = tokenize(`${item.title} ${item.topics?.join(" ") || ""} ${item.content}`);
      const unique = new Set(tokens);
      for (const tok of unique) {
        docFreq.set(tok, (docFreq.get(tok) || 0) + 1);
      }
      return { item, tokens };
    });

    const N = items.length;
    const scored = itemDocs
      .map(({ item, tokens }) => {
        const chunks = chunkText(item.content);
        let bestChunk = chunks[0] || item.content;
        let bestScore = 0;

        for (const chunk of chunks) {
          const chunkTokens = tokenize(`${item.title} ${item.topics?.join(" ") || ""} ${chunk}`);
          const tf = new Map();
          for (const t of chunkTokens) {
            tf.set(t, (tf.get(t) || 0) + 1);
          }
          let score = 0;
          for (const qt of qTokens) {
            const count = tf.get(qt) || 0;
            if (count > 0) {
              const idf = Math.log(1 + N / ((docFreq.get(qt) || 0) + 0.5));
              score += (1 + Math.log(count)) * idf;
            }
          }
          if (item.validationStatus === "VERIFIED") {
            score *= 1.15;
          }
          if (score > bestScore) {
            bestScore = score;
            bestChunk = chunk;
          }
        }

        // Exact phrase bonus
        if (tokens.length > 0 && item.content.toLowerCase().includes(String(query).toLowerCase().trim())) {
          bestScore += 2.0;
        }

        return {
          item,
          matchedExcerpt: bestChunk,
          score: Number(bestScore.toFixed(4))
        };
      })
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    return scored;
  }

  verifyItem(id, { validationStatus = "VERIFIED", reliabilityScore, confidence }) {
    let updated = null;
    this.store.mutate((s) => {
      const idx = s.knowledgeItems.findIndex((i) => i.id === id);
      if (idx !== -1) {
        const current = s.knowledgeItems[idx];
        updated = {
          ...current,
          validationStatus,
          reliabilityScore: reliabilityScore ?? current.reliabilityScore,
          confidence: confidence ?? current.confidence,
          lastVerifiedAtMillis: Date.now(),
          version: (current.version || 1) + 1
        };
        s.knowledgeItems[idx] = updated;
      }
    });
    return updated;
  }
}
