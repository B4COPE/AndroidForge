export class JobScheduler {
  constructor(store, learningEngine) {
    this.store = store;
    this.learningEngine = learningEngine;
    this.timer = null;
  }

  start(intervalMs = 60_000) {
    if (this.timer) return;
    this.timer = setInterval(() => {
      this.tickDueJobs().catch(() => {});
    }, intervalMs);
    this.timer.unref?.();
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  async tickDueJobs() {
    const now = Date.now();
    const jobs = this.store.snapshot().jobs.filter((j) => j.enabled);
    for (const job of jobs) {
      const intervalMs = Math.max(1, job.intervalHours || 24) * 3600 * 1000;
      if (now - (job.lastRunMillis || 0) >= intervalMs) {
        await this.runJobNow(job.id);
      }
    }
  }

  async runJobNow(jobId) {
    const job = this.store.snapshot().jobs.find((j) => j.id === jobId);
    if (!job) throw new Error("Job not found.");

    let summary = "";
    try {
      if (job.taskType === "KNOWLEDGE_VERIFICATION") {
        const analysis = this.learningEngine.runAnalysisCycle();
        summary = analysis.recommendation;
      } else {
        summary = `Executed bounded maintenance job "${job.name}" (budget cap ${job.maxBudgetTokens} tokens).`;
      }
      this.store.mutate((s) => {
        const idx = s.jobs.findIndex((j) => j.id === jobId);
        if (idx !== -1) {
          s.jobs[idx] = {
            ...s.jobs[idx],
            lastRunMillis: Date.now(),
            lastStatus: "SUCCESS",
            lastSummary: summary
          };
        }
      });
    } catch (err) {
      this.store.mutate((s) => {
        const idx = s.jobs.findIndex((j) => j.id === jobId);
        if (idx !== -1) {
          s.jobs[idx] = {
            ...s.jobs[idx],
            lastRunMillis: Date.now(),
            lastStatus: "FAILED",
            lastSummary: err.message
          };
        }
      });
    }
    return this.store.snapshot().jobs.find((j) => j.id === jobId);
  }
}
