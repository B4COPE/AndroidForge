export class LearningEngine {
  constructor(store, knowledgeEngine) {
    this.store = store;
    this.knowledgeEngine = knowledgeEngine;
  }

  recordExperience({
    taskSummary,
    outcomeType = "INSIGHT",
    rootCause = "",
    lessonLearned,
    relatedSkillId = null
  }) {
    const cleanSummary = String(taskSummary || "").trim();
    const cleanLesson = String(lessonLearned || "").trim();
    if (!cleanSummary || !cleanLesson) {
      throw new Error("Experience requires taskSummary and lessonLearned.");
    }
    const exp = {
      id: `exp_${Date.now()}_${Math.random().toString(16).slice(2, 7)}`,
      taskSummary: cleanSummary,
      outcomeType,
      rootCause: String(rootCause || ""),
      lessonLearned: cleanLesson,
      relatedSkillId,
      createdAtMillis: Date.now()
    };
    this.store.mutate((s) => {
      s.experiences.unshift(exp);
    });
    return exp;
  }

  /**
   * Analyzes accumulated task history for recurring errors, missing skills,
   * and unverified knowledge gaps, producing actionable learning insights.
   */
  runAnalysisCycle() {
    const state = this.store.snapshot();
    const errors = state.experiences.filter((e) => e.outcomeType === "ERROR");
    const pendingKnowledge = state.knowledgeItems.filter(
      (k) => k.validationStatus !== "VERIFIED"
    );

    const gapReport = {
      analyzedAtMillis: Date.now(),
      totalExperiences: state.experiences.length,
      errorCount: errors.length,
      pendingVerificationCount: pendingKnowledge.length,
      recurringPatterns: errors.slice(0, 5).map((e) => e.taskSummary),
      recommendation:
        errors.length > 0
          ? `Review ${errors.length} logged failure(s) and extract defensive skill checks.`
          : pendingKnowledge.length > 0
          ? `Verify ${pendingKnowledge.length} pending knowledge entries before relying on them in production.`
          : "Knowledge and operational experience baseline is healthy."
    };

    this.store.appendLog("INFO", "LearningEngine", gapReport.recommendation);
    return gapReport;
  }
}
