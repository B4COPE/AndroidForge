export const COUNCIL_ROLES = [
  "AI Architect",
  "AI Researcher",
  "AI Developer",
  "AI Critic",
  "AI Security Auditor",
  "AI Tester",
  "AI Knowledge Analyst",
  "JAMES Moderator"
];

export class CouncilEngine {
  constructor(store, modelRouter, knowledgeEngine) {
    this.store = store;
    this.modelRouter = modelRouter;
    this.knowledgeEngine = knowledgeEngine;
  }

  /**
   * Executes a bounded multi-round council discussion across configured participants.
   * Explicitly preserves disagreements and generates a structured Improvement Proposal
   * requiring human approval before any critical change.
   */
  async runSession({
    topic,
    mode = "MANUAL",
    participants = [],
    maxRounds = 2,
    maxBudgetTokens = 16000
  }) {
    const cleanTopic = String(topic || "").trim();
    if (!cleanTopic) throw new Error("Council topic cannot be empty.");

    const boundedRounds = Math.min(Math.max(1, Number(maxRounds) || 2), 4);
    const activeParticipants = participants.slice(0, 6);
    if (activeParticipants.length === 0) {
      throw new Error("At least one configured AI participant is required to convene the Council.");
    }

    const relevantKnowledge = this.knowledgeEngine.retrieveRelevant(cleanTopic, 3);
    const contextText =
      relevantKnowledge.length > 0
        ? relevantKnowledge
            .map((k) => `[${k.item.title} | ${k.item.validationStatus}]: ${k.matchedExcerpt}`)
            .join("\n")
        : "No prior verified knowledge matched this topic.";

    const roundsTranscript = [];
    let totalTokens = 0;
    const participantErrors = [];

    // Round 1: Independent analysis per role
    const round1Entries = [];
    for (const p of activeParticipants) {
      if (totalTokens >= maxBudgetTokens) break;
      try {
        const res = await this.modelRouter.invokeProvider({
          providerType: p.providerType,
          runtime: p.runtime,
          endpoint: p.endpoint,
          model: p.model,
          apiKey: p.apiKey,
          systemPrompt: [
            `You are participating in the JAMES Collaborative Intelligence Council as ${p.role}.`,
            "Analyze the problem independently. Explicitly separate Confirmed Facts, Hypotheses, and Unverified Proposals.",
            "Do NOT agree blindly; surface technical weaknesses, risks, and disagreements clearly."
          ].join("\n"),
          messages: [
            {
              role: "user",
              content: `Council Topic: ${cleanTopic}\n\nRelevant JAMES Knowledge:\n${contextText}`
            }
          ]
        });
        totalTokens += res.estimatedTokens || 0;
        round1Entries.push({
          round: 1,
          participantId: p.id,
          role: p.role,
          modelUsed: res.model,
          providerType: res.providerType,
          content: res.text
        });
      } catch (err) {
        participantErrors.push(`${p.role} (${p.providerType}): ${err.message}`);
      }
    }
    roundsTranscript.push(...round1Entries);

    if (round1Entries.length === 0) {
      throw new Error(
        `No council participant succeeded. Details: ${participantErrors.join(" | ")}`
      );
    }

    // Round 2..N: Peer critique & refinement when budget & rounds allow
    for (let r = 2; r <= boundedRounds; r++) {
      if (totalTokens >= maxBudgetTokens || round1Entries.length < 2) break;
      const priorSummary = roundsTranscript
        .filter((e) => e.round === r - 1)
        .map((e) => `[${e.role} / ${e.modelUsed}]:\n${e.content.slice(0, 1200)}`)
        .join("\n\n");

      for (const p of activeParticipants) {
        if (totalTokens >= maxBudgetTokens) break;
        try {
          const res = await this.modelRouter.invokeProvider({
            providerType: p.providerType,
            runtime: p.runtime,
            endpoint: p.endpoint,
            model: p.model,
            apiKey: p.apiKey,
            systemPrompt: `You are ${p.role} on the JAMES Council (Round ${r}). Critique peers' proposals, highlight disagreements or risks, and refine actionable steps.`,
            messages: [
              {
                role: "user",
                content: `Topic: ${cleanTopic}\n\nPeer Responses from Round ${r - 1}:\n${priorSummary}`
              }
            ]
          });
          totalTokens += res.estimatedTokens || 0;
          roundsTranscript.push({
            round: r,
            participantId: p.id,
            role: p.role,
            modelUsed: res.model,
            providerType: res.providerType,
            content: res.text
          });
        } catch (err) {
          participantErrors.push(`Round ${r} ${p.role}: ${err.message}`);
        }
      }
    }

    // Moderator Synthesis
    const moderator =
      activeParticipants.find((p) => p.role === "JAMES Moderator") || activeParticipants[0];
    const allNotes = roundsTranscript
      .map((e) => `[Round ${e.round} · ${e.role} (${e.modelUsed})]\n${e.content}`)
      .join("\n\n");

    let conclusionText = allNotes;
    try {
      const modRes = await this.modelRouter.invokeProvider({
        providerType: moderator.providerType,
        runtime: moderator.runtime,
        endpoint: moderator.endpoint,
        model: moderator.model,
        apiKey: moderator.apiKey,
        systemPrompt: [
          "You are JAMES Moderator. Synthesize the council transcript WITHOUT forcing false consensus.",
          "Return sections clearly labeled: AGREEMENTS:, DISAGREEMENTS:, VERIFIED_FACTS:, HYPOTHESES:, and PROPOSAL_SUMMARY:."
        ].join("\n"),
        messages: [{ role: "user", content: allNotes.slice(0, 16000) }]
      });
      totalTokens += modRes.estimatedTokens || 0;
      conclusionText = modRes.text || conclusionText;
    } catch {
      // Preserve transcript if moderator synthesis hits a budget/network error
    }

    const sessionId = `council_${Date.now()}_${Math.random().toString(16).slice(2, 7)}`;
    const session = {
      id: sessionId,
      topic: cleanTopic,
      mode,
      status: participantErrors.length > 0 ? "COMPLETED_WITH_WARNINGS" : "COMPLETED",
      maxRounds: boundedRounds,
      roundsCompleted: Math.max(...roundsTranscript.map((t) => t.round)),
      participants: activeParticipants.map((p) => ({
        id: p.id,
        role: p.role,
        providerType: p.providerType,
        model: p.model
      })),
      transcript: roundsTranscript,
      warnings: participantErrors,
      conclusionText,
      estimatedTokensUsed: totalTokens,
      createdAtMillis: Date.now()
    };

    const proposal = {
      id: `prop_${Date.now()}_${Math.random().toString(16).slice(2, 7)}`,
      sessionId,
      title: `Proposal: ${cleanTopic.slice(0, 72)}`,
      problemDescription: cleanTopic,
      proposedSolution: conclusionText.slice(0, 2000),
      expectedBenefits: "Improved reliability, modularity, and capability grounded in multi-role review.",
      potentialRisks: participantErrors.length
        ? `Partial council participation: ${participantErrors.join("; ")}`
        : "Requires human review and automated regression testing before activation.",
      dependenciesText: "Verify compatible runtime, permissions, and unit/integration tests.",
      implementationPlan: "Stage incrementally with feature flags and schema migrations.",
      testPlan: "Run unit, security, and integration tests prior to deployment.",
      rollbackPlan: "Revert proposal status to ROLLED_BACK and restore previous configuration snapshot.",
      approvalStatus: "PENDING",
      createdAtMillis: Date.now()
    };

    this.store.mutate((s) => {
      s.councilSessions.unshift(session);
      s.proposals.unshift(proposal);
    });
    this.store.appendLog("INFO", "CouncilEngine", `Completed session ${sessionId} on "${cleanTopic}".`);

    return { session, proposal };
  }

  decideProposal(proposalId, decision) {
    const allowed = new Set(["APPROVED", "REJECTED", "ROLLED_BACK"]);
    if (!allowed.has(decision)) {
      throw new Error("Invalid proposal decision.");
    }
    let updated = null;
    this.store.mutate((s) => {
      const idx = s.proposals.findIndex((p) => p.id === proposalId);
      if (idx !== -1) {
        updated = { ...s.proposals[idx], approvalStatus: decision, decidedAtMillis: Date.now() };
        s.proposals[idx] = updated;
      }
    });
    if (updated) {
      this.store.appendLog("SECURITY", "CouncilEngine", `Proposal ${proposalId} marked ${decision} by operator.`);
    }
    return updated;
  }
}
