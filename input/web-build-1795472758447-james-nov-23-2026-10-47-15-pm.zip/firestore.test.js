const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users cannot read or write any user-scoped data", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const past = new Date(Date.now() - 2000);

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("conversations").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("memories").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("notes").get()
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Unauth",
      createdAt: past,
      updatedAt: past,
    })
  );
});

test("User profile: owner create, partial update, cross-user denial, shadow field rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const past = new Date(Date.now() - 5000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      email: "alice@example.com",
      createdAt: past,
      updatedAt: past,
    })
  );

  // Partial update allowed fields
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      e2eeSalt: "c2FsdA==",
      e2eeVerifier: "dmVyaWZpZXI=",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Shadow field rejected
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      isAdmin: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Immutable createdAt rejection
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Cross-user read & write rejected
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      displayName: "Hijacked",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});

test("Conversations and Messages: owner lifecycle, parent check, and cross-user isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const past = new Date(Date.now() - 5000);

  const convRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("conversations")
    .doc("conv_1");

  // Orphaned message without parent conversation must fail
  await assertFails(
    convRef.collection("messages").doc("msg_orphan").set({
      userId: ALICE_UID,
      conversationId: "conv_1",
      role: "user",
      content: "Orphan",
      encrypted: false,
      createdAt: past,
      updatedAt: past,
    })
  );

  // Create conversation (no @DocumentId `id` field)
  await assertSucceeds(
    convRef.set({
      userId: ALICE_UID,
      title: "Architecture Discussion",
      modelName: "gemini-3.8-flash",
      lastMessagePreview: "Let's plan JAMES.",
      messageCount: 1,
      pinned: false,
      encrypted: false,
      createdAt: past,
      updatedAt: past,
    })
  );

  // Create valid message under existing conversation
  await assertSucceeds(
    convRef.collection("messages").doc("msg_1").set({
      userId: ALICE_UID,
      conversationId: "conv_1",
      role: "user",
      content: "Hello JAMES",
      encrypted: false,
      modelName: "gemini-3.8-flash",
      createdAt: past,
      updatedAt: past,
    })
  );

  // Reject extra `id` field matching @DocumentId trap
  await assertFails(
    convRef.collection("messages").doc("msg_2").set({
      id: "msg_2",
      userId: ALICE_UID,
      conversationId: "conv_1",
      role: "assistant",
      content: "Bad",
      encrypted: false,
      createdAt: past,
      updatedAt: past,
    })
  );

  // Reject future timestamp
  await assertFails(
    convRef.collection("messages").doc("msg_future").set({
      userId: ALICE_UID,
      conversationId: "conv_1",
      role: "user",
      content: "Future",
      encrypted: false,
      createdAt: new Date(Date.now() + 60000),
      updatedAt: new Date(Date.now() + 60000),
    })
  );

  // Partial update on conversation and message
  await assertSucceeds(
    convRef.update({
      title: "Updated Title",
      pinned: true,
      messageCount: 2,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertSucceeds(
    convRef.collection("messages").doc("msg_1").update({
      content: "Edited message",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // List queries match Kotlin repository
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("conversations").get()
  );
  await assertSucceeds(convRef.collection("messages").get());

  // Cross-user isolation
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("conversations").get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("conversations")
      .doc("conv_1")
      .collection("messages")
      .get()
  );
});

test("Memories and Notes: owner CRUD, category validation, and isolation", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const past = new Date(Date.now() - 4000);

  const memRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("memories")
    .doc("mem_1");

  await assertSucceeds(
    memRef.set({
      userId: ALICE_UID,
      category: "preference",
      content: "Prefers concise Kotlin code",
      encrypted: false,
      enabled: true,
      createdAt: past,
      updatedAt: past,
    })
  );

  // Invalid category fails
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("memories")
      .doc("mem_bad")
      .set({
        userId: ALICE_UID,
        category: "secret_system",
        content: "Bad category",
        encrypted: false,
        enabled: true,
        createdAt: past,
        updatedAt: past,
      })
  );

  // Note CRUD
  const noteRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("notes")
    .doc("note_1");

  await assertSucceeds(
    noteRef.set({
      userId: ALICE_UID,
      title: "Offline Scratchpad",
      content: "Encrypted note body",
      encrypted: true,
      createdAt: past,
      updatedAt: past,
    })
  );

  await assertSucceeds(
    noteRef.update({
      content: "Updated encrypted note body",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("memories").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("notes").doc("note_1").delete()
  );
});
