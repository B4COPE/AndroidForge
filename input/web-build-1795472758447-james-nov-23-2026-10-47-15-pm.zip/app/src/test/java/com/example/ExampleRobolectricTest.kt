package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.ai.UnifiedModelClient
import com.example.data.core.CloudBackendClient
import com.example.data.core.ConnectorProbeClient
import com.example.data.core.CouncilOrchestrator
import com.example.data.core.LearningOrchestrator
import com.example.data.core.McpHttpClient
import com.example.data.core.RepositoryMigrationEngine
import com.example.data.local.AppLanguage
import com.example.data.local.JamesDatabase
import com.example.data.local.PreferencesRepository
import com.example.data.model.ChatMessage
import com.example.data.model.MemoryCategory
import com.example.data.model.ProposalApprovalStatus
import com.example.data.model.VaultItemType
import com.example.data.remote.CloudSyncRepository
import com.example.data.repository.EcosystemRepository
import com.example.data.repository.JamesRepository
import com.example.security.CryptoManager
import com.example.security.PrivateVaultManager
import com.example.ui.components.MarkdownTextContent
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.ControlCenterScreen
import com.example.ui.screens.CouncilDashboardScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.theme.JamesTheme
import com.example.ui.viewmodel.EcosystemViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createComposeRule()

    private lateinit var context: Context
    private lateinit var database: JamesDatabase
    private lateinit var repository: JamesRepository
    private lateinit var ecosystemRepository: EcosystemRepository
    private lateinit var cryptoManager: CryptoManager
    private lateinit var vaultManager: PrivateVaultManager
    private lateinit var preferencesRepository: PreferencesRepository

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, JamesDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        cryptoManager = CryptoManager()
        vaultManager = PrivateVaultManager(context)
        vaultManager.clearAllVaultData()
        preferencesRepository = PreferencesRepository(context)
        val cloudSync = CloudSyncRepository(context, cryptoManager)
        repository = JamesRepository(
            conversationDao = database.conversationDao(),
            messageDao = database.messageDao(),
            memoryDao = database.memoryDao(),
            noteDao = database.noteDao(),
            preferencesRepository = preferencesRepository,
            cryptoManager = cryptoManager,
            cloudSyncRepository = cloudSync
        )
        ecosystemRepository = EcosystemRepository(
            dao = database.ecosystemDao(),
            vaultManager = vaultManager
        )
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun appResources_matchJamesBrandIdentity() {
        val appName = context.getString(R.string.app_name)
        assertEquals("JAMES", appName)
        val dbId = context.getString(R.string.firestore_database_id)
        assertTrue(dbId.isNotBlank())
    }

    @Test
    fun cryptoManager_e2eeVaultRoundTripAndWrongPassphraseRejection() {
        val salt = cryptoManager.generateRandomSaltBase64()
        val key = cryptoManager.unlockE2eeVault("strong-passphrase-123", salt)
        val verifier = cryptoManager.createVerifierToken(key)

        val secret = "Confidential user note about project roadmap"
        val (cipher, encrypted) = cryptoManager.encryptForCloud(secret)
        assertTrue(encrypted)
        assertTrue(cipher.startsWith("e2ee:v1:"))
        assertNotEquals(secret, cipher)

        assertEquals(secret, cryptoManager.decryptFromCloud(cipher, true))

        cryptoManager.lockE2eeVault()
        assertFalse(cryptoManager.isE2eeUnlocked())
        assertTrue(cryptoManager.decryptFromCloud(cipher, true).contains("Unlock E2EE Vault"))

        assertFalse(cryptoManager.verifyPassphraseWithToken("wrong-passphrase", salt, verifier))
        assertFalse(cryptoManager.isE2eeUnlocked())

        assertTrue(cryptoManager.verifyPassphraseWithToken("strong-passphrase-123", salt, verifier))
        assertTrue(cryptoManager.isE2eeUnlocked())
        assertEquals(secret, cryptoManager.decryptFromCloud(cipher, true))
    }

    @Test
    fun privateVaultManager_enforcesPinLockIsolationAndSecretRedaction() = runTest {
        assertFalse(vaultManager.isPinConfigured())
        assertFalse(vaultManager.isVaultUnlocked())

        vaultManager.setupPin("4321")
        assertTrue(vaultManager.isPinConfigured())
        assertTrue(vaultManager.isVaultUnlocked())

        vaultManager.lockVault()
        assertFalse(vaultManager.isVaultUnlocked())
        assertFalse(vaultManager.unlockWithPin("0000"))
        assertTrue(vaultManager.unlockWithPin("4321"))

        val cipher = vaultManager.encryptVaultPayload("Top secret API strategy")
        assertTrue(cipher.startsWith("vault:v1:"))
        assertEquals("Top secret API strategy", vaultManager.decryptVaultPayload(cipher))

        vaultManager.storeCredential("prov_openai", "sk-test-secret-9999888877776666")
        assertTrue(vaultManager.hasCredential("prov_openai"))
        assertFalse(vaultManager.getMaskedCredentialHint("prov_openai").contains("999988887777"))

        ecosystemRepository.addLog("INFO", "VaultTest", "Attempted key sk-test-secret-9999888877776666")
        val logs = ecosystemRepository.logsFlow.first()
        assertTrue(logs.any { it.message.contains("[REDACTED]") && !it.message.contains("999988887777") })

        ecosystemRepository.addPrivateVaultItem("Backup Recovery", VaultItemType.SECRET, "recovery-code-xyz")
        val items = ecosystemRepository.privateVaultFlow.first()
        assertEquals(1, items.size)
        assertEquals("recovery-code-xyz", items.first().decryptedContent)
    }

    @Test
    fun roomRepository_persistsConversationsMessagesMemoriesAndOfflineNotes() = runTest {
        val conv = repository.createConversation("Architecture Review", "gemini-3.8-flash")
        val msg = ChatMessage(
            id = "msg_test_1",
            conversationId = conv.id,
            role = "user",
            content = "Summarize clean MVVM rules.",
            createdAtMillis = 1000L,
            updatedAtMillis = 1000L
        )
        repository.saveMessage(msg)

        val mem = repository.addMemory(MemoryCategory.PREFERENCE, "Prefer Kotlin Coroutines & Flow")
        val note = repository.saveNote("Sprint Checklist", "Verify Room + Firestore sync")

        val loadedConv = repository.getConversation(conv.id)
        assertNotNull(loadedConv)
        assertEquals("Architecture Review", loadedConv?.title)

        val loadedMessages = repository.getMessagesOnce(conv.id)
        assertEquals(1, loadedMessages.size)
        assertEquals("Summarize clean MVVM rules.", loadedMessages.first().content)

        val loadedMemories = repository.getEnabledMemoriesOnce()
        assertEquals(1, loadedMemories.size)
        assertEquals(mem.id, loadedMemories.first().id)

        val loadedNotes = repository.observeNotes().first()
        assertEquals(1, loadedNotes.size)
        assertEquals(note.id, loadedNotes.first().id)

        repository.deleteConversation(conv.id)
        assertTrue(repository.getMessagesOnce(conv.id).isEmpty())
    }

    @Test
    fun roomMigration1To2_preservesLegacyDataAndAddsEcosystemTables() = runTest {
        val dbName = "james_migration_test_${System.currentTimeMillis()}.db"
        val dbFile = context.getDatabasePath(dbName)
        dbFile.parentFile?.mkdirs()

        // Build a v1 SQLite database containing original tables
        val helper = FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(dbFile.absolutePath)
                .callback(object : SupportSQLiteOpenHelper.Callback(1) {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        db.execSQL("CREATE TABLE IF NOT EXISTS `conversations` (`id` TEXT NOT NULL, `title` TEXT NOT NULL, `modelName` TEXT NOT NULL, `lastMessagePreview` TEXT NOT NULL, `messageCount` INTEGER NOT NULL, `pinned` INTEGER NOT NULL, `contextSummary` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
                        db.execSQL("CREATE TABLE IF NOT EXISTS `messages` (`id` TEXT NOT NULL, `conversationId` TEXT NOT NULL, `role` TEXT NOT NULL, `content` TEXT NOT NULL, `attachmentName` TEXT, `attachmentMimeType` TEXT, `attachmentUri` TEXT, `attachmentSizeBytes` INTEGER NOT NULL, `modelName` TEXT, `isError` INTEGER NOT NULL, `createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`conversationId`) REFERENCES `conversations`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)")
                        db.execSQL("CREATE INDEX IF NOT EXISTS `index_messages_conversationId` ON `messages` (`conversationId`)")
                        db.execSQL("CREATE INDEX IF NOT EXISTS `index_messages_createdAtMillis` ON `messages` (`createdAtMillis`)")
                        db.execSQL("CREATE TABLE IF NOT EXISTS `memories` (`id` TEXT NOT NULL, `category` TEXT NOT NULL, `content` TEXT NOT NULL, `enabled` INTEGER NOT NULL, `createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
                        db.execSQL("CREATE TABLE IF NOT EXISTS `notes` (`id` TEXT NOT NULL, `title` TEXT NOT NULL, `content` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`))")
                        db.execSQL("INSERT INTO `conversations` VALUES ('conv_legacy_1', 'Legacy Chat', 'gemini-3.8-flash', 'Hi JAMES', 1, 1, '', 100, 100)")
                    }
                    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
                })
                .build()
        )
        helper.writableDatabase.close()

        val migratedDb = Room.databaseBuilder(context, JamesDatabase::class.java, dbFile.absolutePath)
            .addMigrations(JamesDatabase.MIGRATION_1_2)
            .allowMainThreadQueries()
            .build()
        try {
            val legacy = migratedDb.conversationDao().getConversation("conv_legacy_1")
            assertNotNull(legacy)
            assertEquals("Legacy Chat", legacy?.title)
            val ecoRepo = EcosystemRepository(migratedDb.ecosystemDao(), vaultManager)
            ecoRepo.ensureDefaultsSeeded()
            assertTrue(ecoRepo.getProvidersOnce().isNotEmpty())
        } finally {
            migratedDb.close()
            dbFile.delete()
        }
    }

    @Test
    fun councilAndMigrationEngines_enforceHumanApprovalAndChecksums() = runTest {
        val council = CouncilOrchestrator(UnifiedModelClient(), ecosystemRepository, vaultManager)
        val (session, proposal) = council.conveneCouncil(
            topic = "Harden MCP Untrusted Input Isolation",
            mode = "Architecture & Security Critique",
            assignments = emptyList(),
            maxRounds = 1,
            tokenBudget = 3000
        )
        assertEquals(1, session.roundsCompleted)
        assertTrue(session.transcriptMarkdown.contains("AI Architect"))
        assertEquals(ProposalApprovalStatus.PENDING, proposal.approvalStatus)

        val approved = council.reviewProposal(proposal, ProposalApprovalStatus.APPROVED)
        assertEquals(ProposalApprovalStatus.APPROVED, approved.approvalStatus)

        val migrationEngine = RepositoryMigrationEngine(ecosystemRepository)
        val stagingRoot = File(context.cacheDir, "mig_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val record = migrationEngine.executeVerifiedStagingMigration(
            stagingDir = stagingRoot,
            sourceLabel = "Local Staging",
            targetLabel = "WebDAV Mirror",
            payloads = mapOf("knowledge.json" to "{\"verified\":true}", "skills.md" to "# Skill")
        )
        assertEquals("VERIFIED_AWAITING_DELETE_APPROVAL", record.status)
        assertFalse(record.sourceDeleteApproved)
        assertEquals(2, record.transferredFiles)

        val cleaned = migrationEngine.approveSourceCleanup(record)
        assertTrue(cleaned.sourceDeleteApproved)
        stagingRoot.deleteRecursively()
    }

    @Test
    fun markdownRenderer_rendersHeadingsListsTablesAndCodeBlocks() {
        val sampleMarkdown = """
            # Architecture Overview
            - Native Kotlin
            - Jetpack Compose

            | Layer | Responsibility |
            |---|---|
            | UI | Material 3 |
            | Data | Room + Firestore |

            ```kotlin
            fun greet(name: String) = "Hello, ${'$'}name"
            ```
        """.trimIndent()

        composeRule.setContent {
            CompositionLocalProvider(LocalJamesStrings provides stringsFor(AppLanguage.ENGLISH)) {
                JamesTheme {
                    MarkdownTextContent(markdown = sampleMarkdown)
                }
            }
        }

        composeRule.onNodeWithText("Architecture Overview").assertIsDisplayed()
        composeRule.onNodeWithText("Native Kotlin", substring = true).assertIsDisplayed()
        composeRule.onNodeWithText("KOTLIN").assertIsDisplayed()
        composeRule.onNodeWithText("Material 3").assertIsDisplayed()
    }

    @Test
    fun onboardingScreen_rendersArabicRtlSafely() {
        composeRule.setContent {
            CompositionLocalProvider(LocalJamesStrings provides stringsFor(AppLanguage.ARABIC)) {
                JamesTheme {
                    OnboardingScreen(
                        currentLanguage = AppLanguage.ARABIC,
                        isSignedIn = false,
                        onSelectLanguage = {},
                        onSignedIn = {},
                        onComplete = {}
                    )
                }
            }
        }

        composeRule.onNodeWithTag("onboarding_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("onboarding_skip_button").assertIsDisplayed()
        composeRule.onNodeWithTag("onboarding_next_button").assertIsDisplayed()
    }

    @Test
    fun aboutScreen_displaysHonestCapabilitiesSummaryAndFounderAttribution() {
        composeRule.setContent {
            CompositionLocalProvider(LocalJamesStrings provides stringsFor(AppLanguage.ENGLISH)) {
                JamesTheme {
                    AboutScreen(onNavigateBack = {})
                }
            }
        }

        composeRule.onNodeWithText("JAMES").assertIsDisplayed()
        composeRule.onNodeWithText("Abbas Adel Rahim", substring = true).performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Cope / Mark", substring = true).performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Identity & Architecture").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Capabilities & Transparency").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun controlCenterAndCouncilDashboard_renderAllEcosystemHubs() {
        val ecoVm = EcosystemViewModel(
            ecosystemRepository = ecosystemRepository,
            preferencesRepository = preferencesRepository,
            unifiedModelClient = UnifiedModelClient(),
            cloudBackendClient = CloudBackendClient(),
            mcpHttpClient = McpHttpClient(),
            connectorProbeClient = ConnectorProbeClient(),
            councilOrchestrator = CouncilOrchestrator(UnifiedModelClient(), ecosystemRepository, vaultManager),
            learningOrchestrator = LearningOrchestrator(ecosystemRepository),
            migrationEngine = RepositoryMigrationEngine(ecosystemRepository),
            vaultManager = vaultManager,
            stagingFilesDir = context.filesDir
        )

        composeRule.setContent {
            CompositionLocalProvider(LocalJamesStrings provides stringsFor(AppLanguage.ENGLISH)) {
                JamesTheme {
                    ControlCenterScreen(
                        ecosystemViewModel = ecoVm,
                        onNavigateBack = {},
                        onOpenProvidersRuntime = {},
                        onOpenCouncilDashboard = {},
                        onOpenKnowledgeLearning = {},
                        onOpenExtensionsHub = {},
                        onOpenCloudMigration = {},
                        onOpenPrivateVault = {},
                        onOpenDiagnosticsLogs = {},
                        onOpenMemory = {},
                        onOpenGeneralSettings = {},
                        onOpenAbout = {}
                    )
                }
            }
        }

        composeRule.onNodeWithTag("control_center_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("hub_providers_runtime").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("hub_council_dashboard").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("hub_knowledge_learning").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("hub_private_vault").performScrollTo().assertIsDisplayed()
    }
}
