package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ChatMessage
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.LocalJamesColors
import com.example.util.AttachmentProcessor
import com.example.util.TtsPlaybackState
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChatMessageBubble(
    message: ChatMessage,
    isLastAssistantMessage: Boolean,
    ttsState: TtsPlaybackState,
    activeTtsMessageId: String?,
    onCopy: (String) -> Unit,
    onEdit: (ChatMessage) -> Unit,
    onRegenerate: (ChatMessage) -> Unit,
    onDelete: (ChatMessage) -> Unit,
    onSaveMemory: (ChatMessage) -> Unit,
    onSpeak: (ChatMessage) -> Unit,
    onPauseSpeech: () -> Unit,
    onResumeSpeech: () -> Unit,
    onStopSpeech: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val strings = LocalJamesStrings.current
    val jamesColors = LocalJamesColors.current
    val clipboard = LocalClipboardManager.current

    var copied by remember { mutableStateOf(false) }
    var savedMemory by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1800)
            copied = false
        }
    }
    LaunchedEffect(savedMemory) {
        if (savedMemory) {
            delay(2000)
            savedMemory = false
        }
    }

    val bubbleBg = when {
        message.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
        isUser -> jamesColors.userBubble
        else -> jamesColors.assistantBubble
    }
    val bubbleBorder = when {
        message.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.55f)
        isUser -> MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        else -> jamesColors.subtleBorder
    }

    val timeLabel = remember(message.createdAtMillis) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.createdAtMillis))
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Author + Model / Timestamp Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.dp)
        ) {
            if (!isUser) {
                JamesLogoMark(size = 20.dp, animated = message.isStreaming)
                Text(
                    text = "JAMES",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                message.modelName?.let { model ->
                    Text(
                        text = model,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    text = timeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Message Bubble Surface
        Surface(
            shape = RoundedCornerShape(
                topStart = if (isUser) 18.dp else 6.dp,
                topEnd = if (isUser) 6.dp else 18.dp,
                bottomStart = 18.dp,
                bottomEnd = 18.dp
            ),
            color = bubbleBg,
            modifier = Modifier
                .widthIn(max = 640.dp)
                .then(if (!isUser) Modifier.fillMaxWidth() else Modifier)
                .clip(
                    RoundedCornerShape(
                        topStart = if (isUser) 18.dp else 6.dp,
                        topEnd = if (isUser) 6.dp else 18.dp,
                        bottomStart = 18.dp,
                        bottomEnd = 18.dp
                    )
                )
                .border(
                    width = 1.dp,
                    color = bubbleBorder,
                    shape = RoundedCornerShape(
                        topStart = if (isUser) 18.dp else 6.dp,
                        topEnd = if (isUser) 6.dp else 18.dp,
                        bottomStart = 18.dp,
                        bottomEnd = 18.dp
                    )
                )
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (message.attachmentName != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(bottom = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.65f))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AttachFile,
                            contentDescription = "Attachment",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${message.attachmentName} (${AttachmentProcessor.formatFileSize(message.attachmentSizeBytes)})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                if (message.isError) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = "Error",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                } else if (isUser) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                } else {
                    if (message.content.isBlank() && message.isStreaming) {
                        Text(
                            text = strings.generating,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    } else {
                        MarkdownTextContent(
                            markdown = if (message.isStreaming) "${message.content} ▍" else message.content
                        )
                    }
                }
            }
        }

        // Action Bar (only when not actively streaming)
        if (!message.isStreaming) {
            val isSpeakingThis = activeTtsMessageId == message.id && ttsState != TtsPlaybackState.IDLE
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                modifier = Modifier.padding(top = 2.dp)
            ) {
                IconButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(message.content))
                        onCopy(message.content)
                        copied = true
                    },
                    modifier = Modifier.size(40.dp).testTag("msg_copy_${message.id}")
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                        contentDescription = strings.copy,
                        tint = if (copied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(17.dp)
                    )
                }

                if (isUser) {
                    IconButton(
                        onClick = { onEdit(message) },
                        modifier = Modifier.size(40.dp).testTag("msg_edit_${message.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Edit,
                            contentDescription = strings.edit,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                } else if (!message.isError) {
                    // TTS Controls
                    if (isSpeakingThis) {
                        IconButton(
                            onClick = {
                                if (ttsState == TtsPlaybackState.SPEAKING) onPauseSpeech() else onResumeSpeech()
                            },
                            modifier = Modifier.size(40.dp).testTag("msg_tts_toggle_${message.id}")
                        ) {
                            Icon(
                                imageVector = if (ttsState == TtsPlaybackState.SPEAKING) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = if (ttsState == TtsPlaybackState.SPEAKING) strings.pauseSpeech else strings.resumeSpeech,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(
                            onClick = onStopSpeech,
                            modifier = Modifier.size(40.dp).testTag("msg_tts_stop_${message.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = strings.stopSpeech,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else {
                        IconButton(
                            onClick = { onSpeak(message) },
                            modifier = Modifier.size(40.dp).testTag("msg_tts_play_${message.id}")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                                contentDescription = strings.readAloud,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }

                    if (isLastAssistantMessage) {
                        IconButton(
                            onClick = { onRegenerate(message) },
                            modifier = Modifier.size(40.dp).testTag("msg_regen_${message.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Refresh,
                                contentDescription = strings.regenerate,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            onSaveMemory(message)
                            savedMemory = true
                        },
                        modifier = Modifier.size(40.dp).testTag("msg_save_mem_${message.id}")
                    ) {
                        Icon(
                            imageVector = if (savedMemory) Icons.Rounded.Check else Icons.Outlined.BookmarkAdd,
                            contentDescription = if (savedMemory) strings.savedToMemory else strings.saveToMemory,
                            tint = if (savedMemory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { onDelete(message) },
                    modifier = Modifier.size(40.dp).testTag("msg_delete_${message.id}")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Delete,
                        contentDescription = strings.delete,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(17.dp)
                    )
                }

                if (!isUser && !message.isError && isSpeakingThis) {
                    AssistChip(
                        onClick = onStopSpeech,
                        label = {
                            Text(
                                text = if (ttsState == TtsPlaybackState.SPEAKING) "Speaking" else "Paused",
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
            }
        }
    }
}
