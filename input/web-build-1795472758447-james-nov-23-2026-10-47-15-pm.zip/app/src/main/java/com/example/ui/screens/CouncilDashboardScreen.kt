package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CouncilRole
import com.example.data.model.ProposalApprovalStatus
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusDanger
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CouncilDashboardScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val providers by ecosystemViewModel.providers.collectAsStateWithLifecycle()
    val sessions by ecosystemViewModel.councilSessions.collectAsStateWithLifecycle()
    val proposals by ecosystemViewModel.proposals.collectAsStateWithLifecycle()
    val isBusy by ecosystemViewModel.isBusy.collectAsStateWithLifecycle()
    val banner by ecosystemViewModel.statusBanner.collectAsStateWithLifecycle()

    var topicInput by remember { mutableStateOf("") }
    var selectedMode by remember { mutableStateOf("Architecture & Security Critique") }
    val roleProviderMap = remember(providers) {
        mutableStateMapOf<CouncilRole, String>().apply {
            val primary = providers.firstOrNull { it.isDefaultPrimary }?.id ?: providers.firstOrNull()?.id.orEmpty()
            val gemini = providers.firstOrNull { it.id == "prov_firebase_gemini" }?.id ?: primary
            CouncilRole.entries.forEachIndexed { idx, role ->
                this[role] = if (idx % 2 == 0) primary else gemini
            }
        }
    }

    val modes = listOf(
        "Architecture & Security Critique",
        "Research & Fact Synthesis",
        "Skill & Code Review",
        "Deep Multi-Round Debate"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.aiCouncil) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("council_dashboard_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (isBusy) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                banner?.let { msg ->
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { ecosystemViewModel.dismissBanner() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // Launch New Council Session
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Convene Collaborative Intelligence Council",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        OutlinedTextField(
                            value = topicInput,
                            onValueChange = { topicInput = it },
                            label = { Text("Deliberation topic or system improvement question") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("council_topic_input")
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            modes.forEach { m ->
                                FilterChip(
                                    selected = selectedMode == m,
                                    onClick = { selectedMode = m },
                                    label = { Text(m) }
                                )
                            }
                        }
                        Text(
                            text = "Active Council Roles (${CouncilRole.entries.size} roles)",
                            style = MaterialTheme.typography.labelLarge
                        )
                        CouncilRole.entries.take(5).forEach { role ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = role.labelEn,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    modifier = Modifier.weight(0.45f)
                                )
                                FlowRow(modifier = Modifier.weight(0.55f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    providers.filter { it.enabled }.take(3).forEach { prov ->
                                        FilterChip(
                                            selected = roleProviderMap[role] == prov.id,
                                            onClick = { roleProviderMap[role] = prov.id },
                                            label = { Text(prov.name.take(14)) }
                                        )
                                    }
                                }
                            }
                        }
                        Button(
                            onClick = {
                                ecosystemViewModel.runCouncilDiscussion(
                                    topic = topicInput,
                                    mode = selectedMode,
                                    roleProviderMap = roleProviderMap.toMap()
                                )
                            },
                            enabled = !isBusy,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("council_run_button")
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run Bounded Council Deliberation")
                        }
                    }
                }

                // Improvement Proposals Queue (Mandatory Human Approval Gate)
                Text(
                    text = "Improvement Proposals Queue (${proposals.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                if (proposals.isEmpty()) {
                    Text(
                        text = "No improvement proposals yet. Convene a Council deliberation above to generate one.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    proposals.forEach { prop ->
                        val statusColor = when (prop.approvalStatus) {
                            ProposalApprovalStatus.APPROVED -> StatusSuccess
                            ProposalApprovalStatus.REJECTED, ProposalApprovalStatus.ROLLED_BACK -> StatusDanger
                            ProposalApprovalStatus.PENDING -> StatusWarning
                        }
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = prop.title,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = prop.approvalStatus.id,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = statusColor
                                    )
                                }
                                Text("Solution: ${prop.proposedSolution}", style = MaterialTheme.typography.bodySmall)
                                Text("Risks: ${prop.potentialRisks}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Test Plan: ${prop.testPlan}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { ecosystemViewModel.decideProposal(prop, ProposalApprovalStatus.APPROVED) },
                                        enabled = prop.approvalStatus != ProposalApprovalStatus.APPROVED,
                                        modifier = Modifier.testTag("approve_proposal_${prop.id}")
                                    ) {
                                        Icon(Icons.Rounded.Check, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Approve")
                                    }
                                    OutlinedButton(
                                        onClick = { ecosystemViewModel.decideProposal(prop, ProposalApprovalStatus.REJECTED) },
                                        enabled = prop.approvalStatus != ProposalApprovalStatus.REJECTED
                                    ) {
                                        Icon(Icons.Rounded.Close, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Reject")
                                    }
                                    OutlinedButton(
                                        onClick = { ecosystemViewModel.decideProposal(prop, ProposalApprovalStatus.ROLLED_BACK) }
                                    ) {
                                        Icon(Icons.Rounded.Replay, contentDescription = null)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Rollback")
                                    }
                                }
                            }
                        }
                    }
                }

                // Past Council Sessions preserving agreements vs disagreements
                Text(
                    text = "Deliberation Archive (${sessions.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                sessions.forEach { sess ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(sess.topic, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                            Text(
                                text = "${sess.mode} · Rounds: ${sess.roundsCompleted}/${sess.maxRounds} · ~${sess.estimatedTokensUsed} tokens",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (sess.agreementsText.isNotBlank()) {
                                Text("Agreements: ${sess.agreementsText}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (sess.disagreementsText.isNotBlank()) {
                                Text(
                                    "Preserved Disagreements: ${sess.disagreementsText}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusWarning
                                )
                            }
                            Text(sess.conclusionText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
