package com.example.data.model

import android.graphics.Bitmap
import android.net.Uri

enum class MemoryCategory(val id: String, val labelEn: String, val labelAr: String) {
    PREFERENCE("preference", "Preference", "تفضيل"),
    FACT("fact", "Personal Fact", "معلومة شخصية"),
    INSTRUCTION("instruction", "Instruction", "تعليمة"),
    CONTEXT("context", "Work & Context", "السياق والعمل");

    companion object {
        fun fromId(id: String): MemoryCategory =
            entries.firstOrNull { it.id == id } ?: PREFERENCE
    }
}

enum class AttachmentType {
    IMAGE,
    PDF,
    TEXT
}

data class PendingAttachment(
    val id: String,
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val type: AttachmentType,
    val previewBitmap: Bitmap? = null,
    val textContent: String? = null,
    val pdfBytes: ByteArray? = null,
    val pdfPageCount: Int = 0
)

data class Conversation(
    val id: String,
    val title: String,
    val modelName: String,
    val lastMessagePreview: String,
    val messageCount: Int,
    val pinned: Boolean,
    val contextSummary: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val role: String, // "user" or "assistant"
    val content: String,
    val attachmentName: String? = null,
    val attachmentMimeType: String? = null,
    val attachmentUri: String? = null,
    val attachmentSizeBytes: Long = 0L,
    val modelName: String? = null,
    val isError: Boolean = false,
    val isStreaming: Boolean = false,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

data class MemoryItem(
    val id: String,
    val category: MemoryCategory,
    val content: String,
    val enabled: Boolean,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

data class LocalNote(
    val id: String,
    val title: String,
    val content: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

data class MemorySuggestion(
    val category: MemoryCategory,
    val content: String
)
