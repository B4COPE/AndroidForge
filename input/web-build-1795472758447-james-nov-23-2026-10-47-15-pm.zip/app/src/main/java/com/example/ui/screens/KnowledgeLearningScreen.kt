package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ExperienceOutcomeType
import com.example.data.model.ValidationStatus
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun KnowledgeLearningScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val knowledge by ecosystemViewModel.knowledgeItems.collectAsStateWithLifecycle()
    val matches by ecosystemViewModel.knowledgeMatches.collectAsStateWithLifecycle()
    val experiences by ecosystemViewModel.experiences.collectAsStateWithLifecycle()
    val banner by ecosystemViewModel.statusBanner.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var newTitle by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Architecture") }
    var newTopics by remember { mutableStateOf("") }
    var newSource by remember { mutableStateOf("manual://verified-note") }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.knowledgeAndLearning) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("knowledge_learning_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                banner?.let { msg ->
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { ecosystemViewModel.dismissBanner() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // Hybrid Search Test Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        ecosystemViewModel.searchKnowledge(it)
                    },
                    label = { Text("TF-IDF Hybrid Knowledge Retrieval Search") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("knowledge_search_input")
                )
                if (matches.isNotEmpty()) {
                    Text("Top Retrieval Matches (${matches.size})", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    matches.forEach { m ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("${m.item.title} (score=${"%.2f".format(m.score)})", style = MaterialTheme.typography.labelLarge)
                                Text(m.matchedExcerpt, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                // Ingest New Verified Knowledge
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Ingest & Chunk Knowledge (SHA-256 Deduplicated)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        OutlinedTextField(value = newTitle, onValueChange = { newTitle = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = newContent, onValueChange = { newContent = it }, label = { Text("Knowledge Content / Reference") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = newCategory, onValueChange = { newCategory = it }, label = { Text("Category") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = newTopics, onValueChange = { newTopics = it }, label = { Text("Topics CSV") }, modifier = Modifier.weight(1f))
                        }
                        OutlinedTextField(value = newSource, onValueChange = { newSource = it }, label = { Text("Source URI") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                ecosystemViewModel.ingestKnowledge(newTitle, newContent, newCategory, newSource, newTopics)
                                newTitle = ""
                                newContent = ""
                                newTopics = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Chunk, Deduplicate & Store")
                        }
                    }
                }

                // Stored Knowledge Items with Verification Controls
                Text("Persistent Knowledge Repository (${knowledge.size})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                knowledge.forEach { item ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${item.title} (v${item.version} · ${item.chunkCount} chunk(s))", style = MaterialTheme.typography.titleSmall)
                            Text(item.content.take(260), style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "Source: ${item.source} · Status: ${item.validationStatus.id} · Reliability ${(item.reliabilityScore * 100).toInt()}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(ValidationStatus.VERIFIED, ValidationStatus.OUTDATED, ValidationStatus.DISPUTED).forEach { st ->
                                    FilterChip(
                                        selected = item.validationStatus == st,
                                        onClick = { ecosystemViewModel.verifyKnowledgeItem(item, st) },
                                        label = { Text(st.id) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Continuous Learning Engine & Experience Repository
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Learning Experiences (${experiences.size})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    OutlinedButton(onClick = { ecosystemViewModel.runLearningCycleNow() }) {
                        Icon(Icons.Rounded.AutoFixHigh, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Run Learning Cycle")
                    }
                }
                if (experiences.isEmpty()) {
                    Text(
                        text = "No learning experiences logged yet. JAMES automatically logs structured outcomes from orchestrated tasks and allows logging manual gap/error lessons.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(
                        onClick = {
                            ecosystemViewModel.logManualExperience(
                                task = "Baseline System Audit",
                                outcome = ExperienceOutcomeType.INSIGHT,
                                rootCause = "Initial system setup",
                                lesson = "Validate open-weight runtime health before delegating long-running tasks."
                            )
                        }
                    ) { Text("Record Sample Audit Lesson") }
                } else {
                    experiences.take(15).forEach { exp ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("[${exp.outcomeType.id}] ${exp.taskSummary}", style = MaterialTheme.typography.labelLarge)
                                Text("Root Cause: ${exp.rootCause}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Lesson: ${exp.lessonLearned}", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
