package com.example.data.core

import com.example.data.ai.GeminiAiService
import com.example.data.ai.UnifiedModelClient
import com.example.data.local.JamesSettings
import com.example.data.model.AiProviderConfig
import com.example.data.model.ChatMessage
import com.example.data.model.ExperienceOutcomeType
import com.example.data.model.KnowledgeMatch
import com.example.data.model.MemoryItem
import com.example.data.model.PendingAttachment
import com.example.data.model.ProviderType
import com.example.data.model.RoutingPolicy
import com.example.data.repository.EcosystemRepository
import com.example.security.PrivateVaultManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

data class CoreExecutionPlan(
    val selectedProviderLabel: String,
    val selectedModelId: String,
    val knowledgeMatches: List<KnowledgeMatch>,
    val activeSkillNames: List<String>,
    val enrichedSystemInstructions: String
)

data class CoreResponseChunk(
    val text: String,
    val engineLabel: String,
    val modelId: String,
    val knowledgeUsedCount: Int
)

/**
 * JAMES Core — Central System Orchestrator & Brain Controller.
 *
 * Responsibilities:
 * - Owns JAMES identity, personality, knowledge retrieval, active skill guidelines, and permissions.
 * - Routes tasks per user policy:
 *   1. PRIMARY_FIRST -> self-hosted open-weight model (Ollama / llama.cpp / vLLM) when healthy, else fallback
 *   2. BALANCED_HYBRID -> primary open-weight if reachable, multimodal/attachments via Gemini when needed
 *   3. BACKEND_DELEGATED -> JAMES Independent Cloud Core Backend
 *   4. COUNCIL_RESEARCH -> invokes Primary / configured provider with explicit fact-vs-hypothesis review framing
 *   5. FIREBASE_GEMINI_FALLBACK -> Firebase AI Logic (Gemini) with App Check
 * - Automatically logs non-secret interaction experiences for continuous learning.
 */
class JamesCoreOrchestrator(
    private val geminiAiService: GeminiAiService,
    private val unifiedModelClient: UnifiedModelClient,
    private val cloudBackendClient: CloudBackendClient,
    private val ecosystemRepository: EcosystemRepository,
    private val learningOrchestrator: LearningOrchestrator,
    private val vaultManager: PrivateVaultManager
) {
    suspend fun buildExecutionPlan(
        userPrompt: String,
        attachment: PendingAttachment?,
        settings: JamesSettings
    ): CoreExecutionPlan {
        ecosystemRepository.ensureDefaultsSeeded()
        val knowledge = ecosystemRepository.getKnowledgeOnce()
        val matches = KnowledgeRetrievalEngine.search(userPrompt, knowledge, topK = 3)
        val activeSkills = ecosystemRepository.getSkillsOnce().filter { it.enabled && it.inspected }

        val augmentedPrompt = buildString {
            appendLine("JAMES Core Policy: Maintain JAMES independent identity; external models act only as collaborators.")
            if (matches.isNotEmpty()) {
                appendLine()
                appendLine("Verified Local Knowledge Matches (cite when relevant):")
                matches.forEach { m ->
                    appendLine("- [${m.item.title} | ${m.item.validationStatus.id}]: ${m.matchedExcerpt}")
                }
            }
            if (activeSkills.isNotEmpty()) {
                appendLine()
                appendLine("Enabled Inspected Skills:")
                activeSkills.take(4).forEach { skill ->
                    appendLine("- ${skill.name}: ${skill.description}")
                }
            }
            if (settings.customInstructions.isNotBlank()) {
                appendLine()
                appendLine(settings.customInstructions.trim())
            }
        }

        val providers = ecosystemRepository.getProvidersOnce().filter { it.enabled }
        val policy = settings.routingPolicy
        val primary = pickProviderForPolicy(policy, providers, attachment != null, settings)

        return CoreExecutionPlan(
            selectedProviderLabel = primary?.name ?: "Firebase AI Logic",
            selectedModelId = primary?.modelId ?: settings.selectedModel,
            knowledgeMatches = matches,
            activeSkillNames = activeSkills.map { it.name },
            enrichedSystemInstructions = augmentedPrompt
        )
    }

    fun executeChatTurn(
        historyMessages: List<ChatMessage>,
        userPrompt: String,
        attachment: PendingAttachment?,
        settings: JamesSettings,
        memories: List<MemoryItem>,
        priorSummary: String
    ): Flow<CoreResponseChunk> = flow {
        ecosystemRepository.ensureDefaultsSeeded()
        val plan = buildExecutionPlan(userPrompt, attachment, settings)
        val policy = settings.routingPolicy
        val providers = ecosystemRepository.getProvidersOnce().filter { it.enabled }
        val modifiedSettings = settings.copy(customInstructions = plan.enrichedSystemInstructions)

        // Option 1: Try JAMES Cloud Core Backend if delegated & configured
        if (policy == RoutingPolicy.BACKEND_DELEGATED ||
            (settings.useCloudBackendWhenAvailable && settings.backendBaseUrl.isNotBlank())
        ) {
            val backendToken = vaultManager.getCredential("james_cloud_backend")
            val historyPairs = historyMessages.takeLast(12).map { it.role to it.content }
            val backendResult = cloudBackendClient.queryChat(
                baseUrl = settings.backendBaseUrl,
                bearerToken = backendToken,
                prompt = userPrompt,
                history = historyPairs,
                routingPolicy = policy.id
            )
            if (backendResult.isSuccess) {
                val answer = backendResult.getOrThrow()
                learningOrchestrator.recordInteractionOutcome(
                    taskSummary = userPrompt.take(120),
                    outcomeType = ExperienceOutcomeType.SUCCESS,
                    rootCause = "Completed via JAMES Cloud Core Backend",
                    lessonLearned = "Backend routing succeeded cleanly with ${plan.knowledgeMatches.size} knowledge match(es)."
                )
                emit(
                    CoreResponseChunk(
                        text = answer,
                        engineLabel = "JAMES Cloud Core",
                        modelId = "backend-routed",
                        knowledgeUsedCount = plan.knowledgeMatches.size
                    )
                )
                return@flow
            } else {
                ecosystemRepository.addLog(
                    "WARN",
                    "JamesCore",
                    "Backend delegation failed (${backendResult.exceptionOrNull()?.message}); falling back locally."
                )
            }
        }

        // Option 2: Try Primary Open-Weight or selected OpenAI/Anthropic/DeepSeek HTTP Provider
        val candidateProvider = pickProviderForPolicy(policy, providers, attachment != null, settings)
        if (candidateProvider != null &&
            candidateProvider.providerType != ProviderType.FIREBASE_AI_LOGIC
        ) {
            val apiKey = vaultManager.getCredential(candidateProvider.id)
            val canAttemptHttp = if (candidateProvider.providerType.isCommercialApi &&
                candidateProvider.providerType != ProviderType.CUSTOM_OPENAI
            ) {
                !apiKey.isNullOrBlank()
            } else {
                candidateProvider.endpointUrl.isNotBlank()
            }

            if (canAttemptHttp) {
                try {
                    val historyPairs = historyMessages.takeLast(settings.contextTurnLimit)
                        .filter { !it.isError && it.content.isNotBlank() }
                        .map { it.role to it.content } + listOf("user" to userPrompt)
                    val systemWithMemories = buildString {
                        append(plan.enrichedSystemInstructions)
                        if (settings.memoryEnabled && memories.isNotEmpty()) {
                            appendLine("\nConfirmed User Memories:")
                            memories.take(20).forEach { appendLine("- ${it.content}") }
                        }
                        if (priorSummary.isNotBlank()) {
                            appendLine("\nEarlier Summary:\n$priorSummary")
                        }
                    }
                    val result = unifiedModelClient.generate(
                        provider = candidateProvider,
                        apiKey = apiKey,
                        systemPrompt = systemWithMemories,
                        messages = historyPairs,
                        temperature = settings.temperature
                    )
                    repositoryRecordAndLog(
                        provider = candidateProvider,
                        tokens = result.estimatedTokens,
                        latencyMs = result.latencyMs,
                        userPrompt = userPrompt,
                        knowledgeCount = plan.knowledgeMatches.size
                    )
                    emit(
                        CoreResponseChunk(
                            text = result.text,
                            engineLabel = candidateProvider.name,
                            modelId = candidateProvider.modelId,
                            knowledgeUsedCount = plan.knowledgeMatches.size
                        )
                    )
                    return@flow
                } catch (e: Exception) {
                    ecosystemRepository.addLog(
                        "WARN",
                        "JamesCore",
                        "Provider ${candidateProvider.name} unavailable (${PrivateVaultManager.redactSecrets(e.message ?: "error")}); falling back to Firebase AI Logic."
                    )
                }
            }
        }

        // Option 3: Built-in Firebase AI Logic (Gemini) streaming fallback (also handles images & PDFs)
        geminiAiService.streamResponse(
            historyMessages = historyMessages,
            userPrompt = userPrompt,
            attachment = attachment,
            settings = modifiedSettings,
            memories = memories,
            priorSummary = priorSummary
        ).map { accumulated ->
            CoreResponseChunk(
                text = accumulated,
                engineLabel = "Firebase AI Logic",
                modelId = settings.selectedModel,
                knowledgeUsedCount = plan.knowledgeMatches.size
            )
        }.collect { chunk ->
            emit(chunk)
        }

        val firebaseProvider = providers.firstOrNull { it.providerType == ProviderType.FIREBASE_AI_LOGIC }
        if (firebaseProvider != null) {
            ecosystemRepository.recordProviderUsage(
                providerId = firebaseProvider.id,
                tokens = (userPrompt.length / 3L).coerceAtLeast(10L),
                status = "Active via App Check"
            )
        }
    }

    private suspend fun repositoryRecordAndLog(
        provider: AiProviderConfig,
        tokens: Long,
        latencyMs: Long,
        userPrompt: String,
        knowledgeCount: Int
    ) {
        ecosystemRepository.recordProviderUsage(
            providerId = provider.id,
            tokens = tokens,
            status = "Healthy (${latencyMs}ms)"
        )
        learningOrchestrator.recordInteractionOutcome(
            taskSummary = userPrompt.take(120),
            outcomeType = ExperienceOutcomeType.SUCCESS,
            rootCause = "Completed via ${provider.name} (${provider.modelId})",
            lessonLearned = "Latency ${latencyMs}ms; matched $knowledgeCount local knowledge item(s)."
        )
    }

    private fun pickProviderForPolicy(
        policy: RoutingPolicy,
        enabledProviders: List<AiProviderConfig>,
        hasBinaryAttachment: Boolean,
        @Suppress("UNUSED_PARAMETER") settings: JamesSettings
    ): AiProviderConfig? {
        // Multimodal binary attachments (images/PDFs) currently route to Firebase Gemini Vision
        if (hasBinaryAttachment) {
            return enabledProviders.firstOrNull { it.providerType == ProviderType.FIREBASE_AI_LOGIC }
        }
        return when (policy) {
            RoutingPolicy.FIREBASE_GEMINI_FALLBACK ->
                enabledProviders.firstOrNull { it.providerType == ProviderType.FIREBASE_AI_LOGIC }
            RoutingPolicy.PRIMARY_FIRST,
            RoutingPolicy.BALANCED_HYBRID,
            RoutingPolicy.COUNCIL_RESEARCH ->
                enabledProviders.firstOrNull { it.isDefaultPrimary }
                    ?: enabledProviders.firstOrNull { it.providerType == ProviderType.JAMES_PRIMARY_OPEN_WEIGHT }
                    ?: enabledProviders.firstOrNull()
            RoutingPolicy.BACKEND_DELEGATED ->
                enabledProviders.firstOrNull { it.isDefaultPrimary } ?: enabledProviders.firstOrNull()
        }
    }
}
