package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.MarkdownTextContent
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.GenerationStatus
import com.example.ui.viewmodel.MainAppViewModel
import com.example.util.TtsPlaybackState
import com.example.util.VoiceInputState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceModeScreen(
    chatViewModel: ChatViewModel,
    mainViewModel: MainAppViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalJamesStrings.current
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val isOnline by mainViewModel.isOnline.collectAsStateWithLifecycle()
    val voiceState by mainViewModel.voiceInputManager.state.collectAsStateWithLifecycle()
    val partialText by mainViewModel.voiceInputManager.partialText.collectAsStateWithLifecycle()
    val rmsLevel by mainViewModel.voiceInputManager.rmsLevel.collectAsStateWithLifecycle()

    val ttsState by mainViewModel.voiceOutputManager.playbackState.collectAsStateWithLifecycle()
    val messages by chatViewModel.messages.collectAsStateWithLifecycle()
    val streamingMessage by chatViewModel.streamingMessage.collectAsStateWithLifecycle()
    val generationStatus by chatViewModel.generationStatus.collectAsStateWithLifecycle()

    var editableTranscript by remember { mutableStateOf("") }
    var permissionDeniedNote by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            permissionDeniedNote = false
            mainViewModel.voiceInputManager.startListening(settings.voiceInputLanguage)
        } else {
            permissionDeniedNote = true
        }
    }

    LaunchedEffect(voiceState) {
        if (voiceState is VoiceInputState.Result) {
            editableTranscript = (voiceState as VoiceInputState.Result).text
        }
    }

    val latestAssistant = remember(messages, streamingMessage) {
        streamingMessage ?: messages.lastOrNull { it.role == "assistant" }
    }

    val animatedRms by animateFloatAsState(
        targetValue = if (voiceState is VoiceInputState.Listening) rmsLevel else 0.1f,
        label = "voice_rms"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = {
                        mainViewModel.voiceInputManager.stopListening()
                        onNavigateBack()
                    }) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.voiceModeTitle) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Recognition language chips (EN / AR)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        selected = settings.voiceInputLanguage.startsWith("en"),
                        onClick = { mainViewModel.setVoiceInputLanguage("en-US") },
                        label = { Text("English (US)") }
                    )
                    FilterChip(
                        selected = settings.voiceInputLanguage.startsWith("ar"),
                        onClick = { mainViewModel.setVoiceInputLanguage("ar-SA") },
                        label = { Text("العربية (AR)") }
                    )
                }

                // Reactive Orbital Audio Visualizer + Mic Trigger
                val primary = MaterialTheme.colorScheme.primary
                val secondary = MaterialTheme.colorScheme.secondary
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(180.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val baseR = size.minDimension * 0.30f
                        drawCircle(
                            color = primary.copy(alpha = 0.22f),
                            radius = baseR * (1.0f + animatedRms * 0.65f),
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = secondary.copy(alpha = 0.45f),
                            radius = baseR * (1.0f + animatedRms * 0.38f),
                            center = Offset(cx, cy),
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }

                    Surface(
                        onClick = {
                            if (voiceState is VoiceInputState.Listening) {
                                mainViewModel.voiceInputManager.stopListening()
                            } else {
                                val hasMic = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (hasMic) {
                                    mainViewModel.voiceInputManager.startListening(settings.voiceInputLanguage)
                                } else {
                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        shape = CircleShape,
                        color = if (voiceState is VoiceInputState.Listening) MaterialTheme.colorScheme.error else primary,
                        modifier = Modifier.size(84.dp).testTag("voice_mode_mic_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (voiceState is VoiceInputState.Listening) Icons.Rounded.Stop else Icons.Rounded.Mic,
                                contentDescription = strings.tapMicToSpeak,
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }

                Text(
                    text = when (val st = voiceState) {
                        is VoiceInputState.Listening -> partialText.ifBlank { strings.listening }
                        is VoiceInputState.Error -> st.message
                        else -> strings.tapMicToSpeak
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (voiceState is VoiceInputState.Error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (permissionDeniedNote) {
                    Text(
                        text = "Microphone permission is required for Android SpeechRecognizer.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                if (!mainViewModel.voiceInputManager.isAvailable()) {
                    Text(
                        text = "Android SpeechRecognizer service is unavailable on this device/emulator image. You can still type or edit your prompt below.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Transcript Review Box (user reviews before sending)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = strings.reviewBeforeSending,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        OutlinedTextField(
                            value = editableTranscript,
                            onValueChange = { editableTranscript = it },
                            placeholder = { Text(strings.messagePlaceholder) },
                            minLines = 2,
                            maxLines = 5,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().testTag("voice_transcript_input")
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    val text = editableTranscript.trim()
                                    if (text.isNotEmpty()) {
                                        chatViewModel.sendVoicePrompt(text, speakResponseOnComplete = true)
                                        editableTranscript = ""
                                    }
                                },
                                enabled = editableTranscript.isNotBlank() && generationStatus !is GenerationStatus.Generating && isOnline,
                                modifier = Modifier.testTag("voice_send_button")
                            ) {
                                Icon(Icons.AutoMirrored.Rounded.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(strings.sendToJames)
                            }
                        }
                    }
                }

                if (!isOnline) {
                    Text(
                        text = strings.offlineBannerBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                // Assistant Response + TTS Playback Controls
                latestAssistant?.let { assistantMsg ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = "JAMES",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            MarkdownTextContent(markdown = assistantMsg.content.ifBlank { strings.generating })

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        when (ttsState) {
                                            TtsPlaybackState.SPEAKING -> mainViewModel.voiceOutputManager.pause()
                                            TtsPlaybackState.PAUSED -> mainViewModel.voiceOutputManager.resume()
                                            TtsPlaybackState.IDLE -> mainViewModel.voiceOutputManager.speak(
                                                text = assistantMsg.content,
                                                messageId = assistantMsg.id,
                                                speechRate = settings.speechRate,
                                                voiceName = settings.selectedTtsVoiceName,
                                                preferredLanguage = settings.preferredResponseLanguage
                                            )
                                        }
                                    },
                                    modifier = Modifier.testTag("voice_tts_play_pause")
                                ) {
                                    Icon(
                                        imageVector = if (ttsState == TtsPlaybackState.SPEAKING) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = null
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        when (ttsState) {
                                            TtsPlaybackState.SPEAKING -> strings.pauseSpeech
                                            TtsPlaybackState.PAUSED -> strings.resumeSpeech
                                            TtsPlaybackState.IDLE -> strings.readAloud
                                        }
                                    )
                                }
                                OutlinedButton(onClick = { mainViewModel.voiceOutputManager.replay() }) {
                                    Icon(Icons.Rounded.Replay, contentDescription = strings.replaySpeech)
                                }
                                OutlinedButton(onClick = { mainViewModel.voiceOutputManager.stop() }) {
                                    Icon(Icons.Rounded.Stop, contentDescription = strings.stopSpeech)
                                }
                            }

                            // Quick speech rate control
                            Column {
                                Text(
                                    text = "Speech Rate: ${String.format("%.2fx", settings.speechRate)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Slider(
                                    value = settings.speechRate,
                                    onValueChange = { mainViewModel.setSpeechRate(it) },
                                    valueRange = 0.6f..1.8f
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
