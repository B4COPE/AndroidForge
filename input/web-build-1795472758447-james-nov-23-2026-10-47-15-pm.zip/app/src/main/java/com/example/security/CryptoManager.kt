package com.example.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Provides AES-256-GCM encryption at rest backed by Android Keystore,
 * plus optional PBKDF2-HMAC-SHA256 derived AES-256-GCM end-to-end encryption
 * for cross-device Firestore cloud sync.
 */
class CryptoManager(
    private val keyAlias: String = DEFAULT_KEY_ALIAS
) {
    private val lock = Any()
    @Volatile
    private var sessionSyncKey: SecretKey? = null

    fun isHardwareKeystoreAvailable(): Boolean = getOrCreateLocalKey() != null

    fun isE2eeUnlocked(): Boolean = sessionSyncKey != null

    /**
     * Encrypts plaintext locally using the device's Android Keystore AES-256-GCM key.
     * Prefixes ciphertext with "enc:v1:" so legacy or fallback plain strings remain identifiable.
     */
    fun encryptLocal(plaintext: String): String {
        if (plaintext.isEmpty()) return plaintext
        val key = getOrCreateLocalKey() ?: return plaintext
        return try {
            LOCAL_PREFIX + encryptWithKey(plaintext, key)
        } catch (e: Exception) {
            Log.e(TAG, "Local encryption failed", e)
            plaintext
        }
    }

    fun decryptLocal(stored: String): String {
        if (!stored.startsWith(LOCAL_PREFIX)) return stored
        val payload = stored.removePrefix(LOCAL_PREFIX)
        val key = getOrCreateLocalKey() ?: return stored
        return try {
            decryptWithKey(payload, key)
        } catch (e: Exception) {
            Log.e(TAG, "Local decryption failed", e)
            "[Unable to decrypt local record]"
        }
    }

    /**
     * Derives an AES-256 sync key from a user passphrase and salt (PBKDF2WithHmacSHA256).
     * Holds the derived key strictly in memory during the unlocked session.
     */
    fun unlockE2eeVault(passphrase: String, saltBase64: String): SecretKey {
        require(passphrase.length >= 6) { "Passphrase must be at least 6 characters." }
        val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val keyBytes = factory.generateSecret(spec).encoded
        spec.clearPassword()
        val secretKey = SecretKeySpec(keyBytes, "AES")
        sessionSyncKey = secretKey
        return secretKey
    }

    fun lockE2eeVault() {
        sessionSyncKey = null
    }

    fun generateRandomSaltBase64(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun createVerifierToken(key: SecretKey): String {
        return encryptWithKey(VERIFIER_PLAINTEXT, key)
    }

    fun verifyPassphraseWithToken(passphrase: String, saltBase64: String, verifierToken: String): Boolean {
        return try {
            val candidate = unlockE2eeVault(passphrase, saltBase64)
            val decrypted = decryptWithKey(verifierToken, candidate)
            if (decrypted == VERIFIER_PLAINTEXT) {
                true
            } else {
                sessionSyncKey = null
                false
            }
        } catch (e: Exception) {
            sessionSyncKey = null
            false
        }
    }

    fun encryptForCloud(plaintext: String): Pair<String, Boolean> {
        val key = sessionSyncKey ?: return plaintext to false
        return try {
            E2EE_PREFIX + encryptWithKey(plaintext, key) to true
        } catch (e: Exception) {
            Log.e(TAG, "E2EE cloud encryption failed", e)
            plaintext to false
        }
    }

    fun decryptFromCloud(payload: String, encrypted: Boolean): String {
        if (!encrypted || !payload.startsWith(E2EE_PREFIX)) return payload
        val key = sessionSyncKey ?: return "[Encrypted — Unlock E2EE Vault in Account or Privacy settings to view]"
        return try {
            decryptWithKey(payload.removePrefix(E2EE_PREFIX), key)
        } catch (e: Exception) {
            Log.e(TAG, "E2EE cloud decryption failed", e)
            "[Encrypted — Invalid Vault Passphrase]"
        }
    }

    private fun encryptWithKey(plaintext: String, key: SecretKey): String {
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val cipherBytes = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        val combined = ByteArray(1 + iv.size + cipherBytes.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(cipherBytes, 0, combined, 1 + iv.size, cipherBytes.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decryptWithKey(encoded: String, key: SecretKey): String {
        val combined = Base64.decode(encoded, Base64.NO_WRAP)
        require(combined.size > 14) { "Invalid ciphertext payload." }
        val ivLen = combined[0].toInt() and 0xFF
        require(ivLen in 12..16 && combined.size > 1 + ivLen) { "Invalid IV length." }
        val iv = combined.copyOfRange(1, 1 + ivLen)
        val cipherBytes = combined.copyOfRange(1 + ivLen, combined.size)
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        val plainBytes = cipher.doFinal(cipherBytes)
        return String(plainBytes, StandardCharsets.UTF_8)
    }

    private fun getOrCreateLocalKey(): SecretKey? {
        synchronized(lock) {
            return try {
                val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
                val existing = keyStore.getKey(keyAlias, null) as? SecretKey
                if (existing != null) return existing

                val keyGenerator = KeyGenerator.getInstance(
                    KeyProperties.KEY_ALGORITHM_AES,
                    ANDROID_KEYSTORE
                )
                val spec = KeyGenParameterSpec.Builder(
                    keyAlias,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGenerator.init(spec)
                keyGenerator.generateKey()
            } catch (e: Exception) {
                // In Robolectric JVM tests AndroidKeyStore may be unavailable; fail gracefully
                Log.w(TAG, "AndroidKeyStore unavailable: ${e.message}")
                null
            }
        }
    }

    companion object {
        private const val TAG = "CryptoManager"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val DEFAULT_KEY_ALIAS = "james_local_aes256_key"
        private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
        private const val LOCAL_PREFIX = "enc:v1:"
        private const val E2EE_PREFIX = "e2ee:v1:"
        private const val PBKDF2_ITERATIONS = 100_000
        private const val VERIFIER_PLAINTEXT = "JAMES_VAULT_VERIFIED_V1"
    }
}
