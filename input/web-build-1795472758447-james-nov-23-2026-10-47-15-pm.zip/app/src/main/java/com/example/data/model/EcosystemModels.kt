package com.example.data.model

enum class RoutingPolicy(val id: String, val labelEn: String, val labelAr: String, val summaryEn: String) {
    PRIMARY_FIRST(
        "primary_first",
        "Primary Open-Weight First",
        "النموذج المفتوح الأساسي أولاً",
        "Routes routine tasks to JAMES Primary open-weight model when connected; uses fallback only when needed."
    ),
    BALANCED_HYBRID(
        "balanced_hybrid",
        "Balanced Hybrid Core",
        "هجين متوازن",
        "Uses Primary model for everyday tasks and consults external/council intelligence on complex reasoning."
    ),
    COUNCIL_RESEARCH(
        "council_research",
        "Multi-Model Council Research",
        "بحث مجلس الذكاء",
        "Convenes configured providers for multi-perspective analysis and critique on complex queries."
    ),
    FIREBASE_GEMINI_FALLBACK(
        "firebase_fallback",
        "Firebase AI Logic (Gemini)",
        "محرك Gemini عبر Firebase",
        "Uses built-in Firebase AI Logic with App Check when self-hosted inference is unavailable."
    ),
    BACKEND_DELEGATED(
        "backend_delegated",
        "JAMES Cloud Core Backend",
        "خادم JAMES السحابي",
        "Delegates orchestration, council runs, and knowledge retrieval to your independent JAMES backend."
    );

    companion object {
        fun fromId(id: String): RoutingPolicy = entries.firstOrNull { it.id == id } ?: BALANCED_HYBRID
    }
}

enum class ProviderType(val id: String, val label: String, val defaultEndpoint: String, val isCommercialApi: Boolean) {
    JAMES_PRIMARY_OPEN_WEIGHT("james_primary", "JAMES Primary (Open-Weight)", "http://10.0.2.2:11434", false),
    FIREBASE_AI_LOGIC("firebase_ai", "Firebase AI Logic (Gemini)", "firebase-app-check://ai-logic", true),
    OPENAI("openai", "OpenAI", "https://api.openai.com/v1/chat/completions", true),
    ANTHROPIC("anthropic", "Anthropic Claude", "https://api.anthropic.com/v1/messages", true),
    DEEPSEEK("deepseek", "DeepSeek", "https://api.deepseek.com/v1/chat/completions", true),
    CUSTOM_OPENAI("custom_openai", "Custom OpenAI-Compatible", "", true);

    companion object {
        fun fromId(id: String): ProviderType = entries.firstOrNull { it.id == id } ?: FIREBASE_AI_LOGIC
    }
}

enum class ModelRuntimeType(val id: String, val label: String) {
    OLLAMA("ollama", "Ollama (/api/chat)"),
    LLAMACPP("llamacpp", "llama.cpp Server (/v1/chat/completions)"),
    VLLM("vllm", "vLLM Server (/v1/chat/completions)"),
    FIREBASE_SDK("firebase_sdk", "Firebase AI Logic SDK"),
    CLOUD_API("cloud_api", "HTTPS REST API");

    companion object {
        fun fromId(id: String): ModelRuntimeType = entries.firstOrNull { it.id == id } ?: OLLAMA
    }
}

data class OpenWeightModelSpec(
    val id: String,
    val displayName: String,
    val organization: String,
    val licenseName: String,
    val isOsiOpenSource: Boolean,
    val licenseNotes: String,
    val recommendedQuantization: String,
    val minRamOrVramGb: Int,
    val englishQuality: String,
    val arabicQuality: String,
    val codingAndReasoning: String,
    val supportedRuntimes: String,
    val fineTuningNotes: String
)

object OpenWeightModelCatalog {
    val models = listOf(
        OpenWeightModelSpec(
            id = "gemma3:12b-it",
            displayName = "Google Gemma 3 12B Instruct",
            organization = "Google",
            licenseName = "Gemma Terms of Use",
            isOsiOpenSource = false,
            licenseNotes = "Open-weight under Gemma Terms of Use (includes acceptable-use restrictions; NOT an OSI open-source license). Separate from proprietary Gemini API.",
            recommendedQuantization = "Q4_K_M (~7.8 GB) / Q8_0 (~13.2 GB)",
            minRamOrVramGb = 12,
            englishQuality = "Strong reasoning & instruction adherence",
            arabicQuality = "Very good multilingual Arabic & English support",
            codingAndReasoning = "High coding, structured JSON, and tool-use clarity",
            supportedRuntimes = "Ollama, llama.cpp (GGUF), vLLM",
            fineTuningNotes = "Supports LoRA / QLoRA (4-bit NF4) on 16–24 GB VRAM GPUs"
        ),
        OpenWeightModelSpec(
            id = "gemma3:4b-it",
            displayName = "Google Gemma 3 4B Instruct",
            organization = "Google",
            licenseName = "Gemma Terms of Use",
            isOsiOpenSource = false,
            licenseNotes = "Open-weight under Gemma Terms of Use (NOT OSI-approved; commercial & safety restrictions apply).",
            recommendedQuantization = "Q4_K_M (~2.8 GB)",
            minRamOrVramGb = 6,
            englishQuality = "Fast, crisp everyday reasoning",
            arabicQuality = "Solid Arabic fluency for compact size",
            codingAndReasoning = "Good scripting & summarization; fits OCI Always Free 24 GB ARM CPU VM",
            supportedRuntimes = "Ollama, llama.cpp (GGUF), vLLM",
            fineTuningNotes = "Supports LoRA / QLoRA on 8–12 GB VRAM GPUs"
        ),
        OpenWeightModelSpec(
            id = "qwen2.5:14b-instruct",
            displayName = "Qwen 2.5 14B Instruct",
            organization = "Alibaba Qwen",
            licenseName = "Apache 2.0",
            isOsiOpenSource = true,
            licenseNotes = "Permissive OSI-approved Apache 2.0 license for 14B weights.",
            recommendedQuantization = "Q4_K_M (~9.0 GB)",
            minRamOrVramGb = 16,
            englishQuality = "Excellent reasoning and long-context adherence",
            arabicQuality = "Strong multilingual & Arabic instruction quality",
            codingAndReasoning = "Top-tier coding, math, and JSON function accuracy",
            supportedRuntimes = "Ollama, llama.cpp, vLLM",
            fineTuningNotes = "QLoRA / LoRA ready on 24 GB GPU"
        ),
        OpenWeightModelSpec(
            id = "llama3.1:8b-instruct",
            displayName = "Meta Llama 3.1 8B Instruct",
            organization = "Meta",
            licenseName = "Llama 3.1 Community License",
            isOsiOpenSource = false,
            licenseNotes = "Custom Community License (attribution & 700M MAU threshold restrictions; not OSI open-source).",
            recommendedQuantization = "Q4_K_M (~4.9 GB)",
            minRamOrVramGb = 8,
            englishQuality = "Strong general instruction following",
            arabicQuality = "Moderate Arabic (weaker than Gemma 3 / Qwen 2.5)",
            codingAndReasoning = "Fast baseline assistant & classification",
            supportedRuntimes = "Ollama, llama.cpp, vLLM",
            fineTuningNotes = "Widely supported by Unsloth / PEFT QLoRA"
        )
    )
}

data class CloudHostingOption(
    val id: String,
    val name: String,
    val cpuAndRam: String,
    val storageAndNetwork: String,
    val backgroundSuitability: String,
    val caveats: String
)

object CloudHostingCatalog {
    val options = listOf(
        CloudHostingOption(
            id = "oci_always_free",
            name = "Oracle Cloud Infrastructure (OCI) Always Free",
            cpuAndRam = "Up to 4 Ampere A1 ARM64 OCPUs + 24 GB RAM + 2x AMD Micro (1 GB)",
            storageAndNetwork = "200 GB Block Volume, 10 TB/mo outbound",
            backgroundSuitability = "Excellent for always-on JAMES Cloud Core + quantized 4B CPU inference (no idle sleep).",
            caveats = "Requires credit-card verification during signup; A1 ARM capacity can be scarce in popular regions."
        ),
        CloudHostingOption(
            id = "cloud_run",
            name = "Google Cloud Run (Free Monthly Grant)",
            cpuAndRam = "Serverless vCPU/RAM; 2M requests/mo free quota",
            storageAndNetwork = "Stateless containers (needs external DB/Firestore/S3)",
            backgroundSuitability = "Great for burst REST orchestration; NOT suitable for long in-memory loops unless min-instances billed.",
            caveats = "Scales to zero after idle; cold starts and max request timeouts apply."
        ),
        CloudHostingOption(
            id = "render_fly",
            name = "Render / Fly.io Free & Hobby Tiers",
            cpuAndRam = "256–512 MB shared RAM (Free)",
            storageAndNetwork = "Limited ephemeral or tiny persistent volumes",
            backgroundSuitability = "Insufficient RAM for open-weight model hosting; Render free instances sleep after 15 min inactivity.",
            caveats = "Suitable only for lightweight proxy demos, not persistent AI backend + scheduler."
        ),
        CloudHostingOption(
            id = "gpu_vps",
            name = "Dedicated GPU Node (Hetzner / RunPod / Lambda)",
            cpuAndRam = "24–48 GB VRAM GPU (e.g., L4 / RTX 4090 / A10G)",
            storageAndNetwork = "NVMe model cache + persistent volume",
            backgroundSuitability = "Required for fast vLLM 12B–32B inference and real LoRA/QLoRA fine-tuning.",
            caveats = "Paid hourly/monthly; JAMES Core stays independent so you can plug in a GPU worker later."
        )
    )
}

enum class CouncilRole(val id: String, val labelEn: String, val labelAr: String, val mandate: String) {
    ARCHITECT("architect", "AI Architect", "مهندس معماري", "Designs clean modular improvements to JAMES."),
    RESEARCHER("researcher", "AI Researcher", "باحث ذكاء", "Investigates methods, open models, and retrieval papers."),
    DEVELOPER("developer", "AI Developer", "مطور", "Produces concrete Kotlin/Node implementation designs."),
    CRITIC("critic", "AI Critic", "ناقد تقني", "Challenges assumptions and surfaces edge cases."),
    SECURITY_AUDITOR("security", "AI Security Auditor", "مدقق أمان", "Audits credentials, isolation, prompt-injection, and permissions."),
    TESTER("tester", "AI Tester", "مهندس اختبار", "Evaluates test plans and regression risks."),
    KNOWLEDGE_ANALYST("analyst", "AI Knowledge Analyst", "محلل معرفة", "Extracts verified reusable knowledge and skills."),
    MODERATOR("moderator", "JAMES Moderator", "منسق JAMES", "Compares views without forcing fake consensus.");

    companion object {
        fun fromId(id: String): CouncilRole = entries.firstOrNull { it.id == id } ?: ARCHITECT
    }
}

enum class ProposalApprovalStatus(val id: String) {
    PENDING("PENDING"),
    APPROVED("APPROVED"),
    REJECTED("REJECTED"),
    ROLLED_BACK("ROLLED_BACK");

    companion object {
        fun fromId(id: String): ProposalApprovalStatus = entries.firstOrNull { it.id == id } ?: PENDING
    }
}

enum class ValidationStatus(val id: String) {
    PENDING_REVIEW("PENDING_REVIEW"),
    VERIFIED("VERIFIED"),
    OUTDATED("OUTDATED"),
    DISPUTED("DISPUTED");

    companion object {
        fun fromId(id: String): ValidationStatus = entries.firstOrNull { it.id == id } ?: PENDING_REVIEW
    }
}

enum class ExperienceOutcomeType(val id: String) {
    SUCCESS("SUCCESS"),
    ERROR("ERROR"),
    GAP("GAP"),
    INSIGHT("INSIGHT");

    companion object {
        fun fromId(id: String): ExperienceOutcomeType = entries.firstOrNull { it.id == id } ?: INSIGHT
    }
}

enum class McpTransport(val id: String, val label: String) {
    STREAMABLE_HTTP("streamable_http", "Streamable HTTP"),
    HTTP_SSE("http_sse", "Legacy HTTP + SSE"),
    STDIO_BRIDGE("stdio_bridge", "Desktop STDIO (via Remote Bridge Only)");

    companion object {
        fun fromId(id: String): McpTransport = entries.firstOrNull { it.id == id } ?: STREAMABLE_HTTP
    }
}

enum class VaultItemType(val id: String, val labelEn: String) {
    SECRET("SECRET", "API Secret / Token"),
    MEMORY("MEMORY", "Private Memory"),
    NOTE("NOTE", "Private Note"),
    CONFIG("CONFIG", "Private Config");

    companion object {
        fun fromId(id: String): VaultItemType = entries.firstOrNull { it.id == id } ?: NOTE
    }
}

data class AiProviderConfig(
    val id: String,
    val name: String,
    val providerType: ProviderType,
    val runtimeType: ModelRuntimeType,
    val endpointUrl: String,
    val modelId: String,
    val enabled: Boolean,
    val isDefaultPrimary: Boolean,
    val estimatedInputCostPer1M: Double = 0.0,
    val estimatedOutputCostPer1M: Double = 0.0,
    val totalRequests: Int = 0,
    val totalEstimatedTokens: Long = 0L,
    val requestLimitPerDay: Int = 500,
    val lastStatus: String = "Configured",
    val lastTestedMillis: Long = 0L
)

data class CouncilParticipantAssignment(
    val providerId: String,
    val providerName: String,
    val role: CouncilRole
)

data class CouncilSession(
    val id: String,
    val topic: String,
    val mode: String,
    val status: String,
    val maxRounds: Int,
    val roundsCompleted: Int,
    val participantsSummary: String,
    val transcriptMarkdown: String,
    val agreementsText: String,
    val disagreementsText: String,
    val conclusionText: String,
    val estimatedTokensUsed: Long,
    val createdAtMillis: Long
)

data class ImprovementProposal(
    val id: String,
    val sessionId: String,
    val title: String,
    val problemDescription: String,
    val proposedSolution: String,
    val expectedBenefits: String,
    val potentialRisks: String,
    val dependenciesText: String,
    val implementationPlan: String,
    val testPlan: String,
    val rollbackPlan: String,
    val approvalStatus: ProposalApprovalStatus,
    val createdAtMillis: Long
)

data class KnowledgeItem(
    val id: String,
    val title: String,
    val content: String,
    val category: String,
    val source: String,
    val sourceType: String,
    val acquiredAtMillis: Long,
    val lastVerifiedAtMillis: Long,
    val reliabilityScore: Float,
    val confidence: Float,
    val topicsCsv: String,
    val version: Int,
    val validationStatus: ValidationStatus,
    val chunkCount: Int,
    val checksumSha256: String
)

data class KnowledgeMatch(
    val item: KnowledgeItem,
    val matchedExcerpt: String,
    val score: Double
)

data class LearningExperience(
    val id: String,
    val taskSummary: String,
    val outcomeType: ExperienceOutcomeType,
    val rootCause: String,
    val lessonLearned: String,
    val relatedSkillId: String?,
    val createdAtMillis: Long
)

data class SkillPackage(
    val id: String,
    val name: String,
    val description: String,
    val version: String,
    val category: String,
    val sourceType: String,
    val sourceUri: String,
    val skillMarkdown: String,
    val permissionsCsv: String,
    val dependenciesCsv: String,
    val enabled: Boolean,
    val inspected: Boolean,
    val inspectionNotes: String,
    val updatedAtMillis: Long
)

data class McpServerConfig(
    val id: String,
    val name: String,
    val transport: McpTransport,
    val endpointUrl: String,
    val status: String,
    val discoveredToolsSummary: String,
    val enabledToolsCsv: String,
    val requireApprovalPerCall: Boolean,
    val lastConnectedMillis: Long,
    val logsText: String
)

data class ConnectorIntegration(
    val id: String,
    val providerKey: String,
    val displayName: String,
    val category: String,
    val endpointOrScope: String,
    val authMode: String,
    val isSupportedOfficially: Boolean,
    val enabled: Boolean,
    val status: String,
    val notes: String,
    val lastCheckedMillis: Long
)

data class PrivateVaultItem(
    val id: String,
    val title: String,
    val itemType: VaultItemType,
    val decryptedContent: String,
    val updatedAtMillis: Long
)

data class ScheduledJobConfig(
    val id: String,
    val name: String,
    val taskType: String,
    val intervalHours: Int,
    val enabled: Boolean,
    val maxBudgetTokens: Int,
    val lastRunMillis: Long,
    val lastStatus: String,
    val lastSummary: String
)

data class MigrationRecord(
    val id: String,
    val sourceProvider: String,
    val targetProvider: String,
    val status: String,
    val totalFiles: Int,
    val transferredFiles: Int,
    val checksumManifestSha256: String,
    val reportSummary: String,
    val sourceDeleteApproved: Boolean,
    val createdAtMillis: Long
)

data class SystemLogEntry(
    val id: String,
    val level: String,
    val component: String,
    val message: String,
    val timestampMillis: Long
)
