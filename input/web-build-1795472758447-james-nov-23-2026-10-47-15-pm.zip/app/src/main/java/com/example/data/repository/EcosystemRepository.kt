package com.example.data.repository

import com.example.data.local.AiProviderEntity
import com.example.data.local.ConnectorEntity
import com.example.data.local.CouncilSessionEntity
import com.example.data.local.EcosystemDao
import com.example.data.local.ImprovementProposalEntity
import com.example.data.local.KnowledgeEntity
import com.example.data.local.LearningExperienceEntity
import com.example.data.local.McpServerEntity
import com.example.data.local.MigrationRecordEntity
import com.example.data.local.PrivateVaultEntity
import com.example.data.local.ScheduledJobEntity
import com.example.data.local.SkillEntity
import com.example.data.local.SystemLogEntity
import com.example.data.model.AiProviderConfig
import com.example.data.model.ConnectorIntegration
import com.example.data.model.CouncilSession
import com.example.data.model.ExperienceOutcomeType
import com.example.data.model.ImprovementProposal
import com.example.data.model.KnowledgeItem
import com.example.data.model.LearningExperience
import com.example.data.model.McpServerConfig
import com.example.data.model.McpTransport
import com.example.data.model.MigrationRecord
import com.example.data.model.ModelRuntimeType
import com.example.data.model.PrivateVaultItem
import com.example.data.model.ProposalApprovalStatus
import com.example.data.model.ProviderType
import com.example.data.model.ScheduledJobConfig
import com.example.data.model.SkillPackage
import com.example.data.model.SystemLogEntry
import com.example.data.model.ValidationStatus
import com.example.data.model.VaultItemType
import com.example.security.PrivateVaultManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

class EcosystemRepository(
    private val dao: EcosystemDao,
    private val vaultManager: PrivateVaultManager
) {
    private val seedMutex = Mutex()
    @Volatile
    private var seeded = false

    val providersFlow: Flow<List<AiProviderConfig>> =
        dao.observeProviders().map { list -> list.map { it.toDomain() } }

    val knowledgeFlow: Flow<List<KnowledgeItem>> =
        dao.observeKnowledge().map { list -> list.map { it.toDomain() } }

    val experiencesFlow: Flow<List<LearningExperience>> =
        dao.observeExperiences().map { list -> list.map { it.toDomain() } }

    val skillsFlow: Flow<List<SkillPackage>> =
        dao.observeSkills().map { list -> list.map { it.toDomain() } }

    val mcpServersFlow: Flow<List<McpServerConfig>> =
        dao.observeMcpServers().map { list -> list.map { it.toDomain() } }

    val connectorsFlow: Flow<List<ConnectorIntegration>> =
        dao.observeConnectors().map { list -> list.map { it.toDomain() } }

    val councilSessionsFlow: Flow<List<CouncilSession>> =
        dao.observeCouncilSessions().map { list -> list.map { it.toDomain() } }

    val proposalsFlow: Flow<List<ImprovementProposal>> =
        dao.observeProposals().map { list -> list.map { it.toDomain() } }

    val privateVaultFlow: Flow<List<PrivateVaultItem>> =
        dao.observeVaultItems().map { list ->
            list.map {
                PrivateVaultItem(
                    id = it.id,
                    title = it.title,
                    itemType = VaultItemType.fromId(it.itemType),
                    decryptedContent = vaultManager.decryptVaultPayload(it.encryptedPayload),
                    updatedAtMillis = it.updatedAtMillis
                )
            }
        }

    val scheduledJobsFlow: Flow<List<ScheduledJobConfig>> =
        dao.observeJobs().map { list -> list.map { it.toDomain() } }

    val migrationsFlow: Flow<List<MigrationRecord>> =
        dao.observeMigrations().map { list -> list.map { it.toDomain() } }

    val logsFlow: Flow<List<SystemLogEntry>> =
        dao.observeLogs().map { list -> list.map { it.toDomain() } }

    suspend fun ensureDefaultsSeeded() {
        if (seeded) return
        seedMutex.withLock {
            if (seeded) return
            val now = System.currentTimeMillis()
            if (dao.getProvidersOnce().isEmpty()) {
                val defaults = listOf(
                    AiProviderEntity(
                        id = "prov_james_primary_gemma3",
                        name = "JAMES Primary (Gemma 3 12B / Ollama)",
                        providerType = ProviderType.JAMES_PRIMARY_OPEN_WEIGHT.id,
                        runtimeType = ModelRuntimeType.OLLAMA.id,
                        endpointUrl = "http://10.0.2.2:11434",
                        modelId = "gemma3:12b-it",
                        enabled = true,
                        isDefaultPrimary = true,
                        estimatedInputCostPer1M = 0.0,
                        estimatedOutputCostPer1M = 0.0,
                        totalRequests = 0,
                        totalEstimatedTokens = 0L,
                        requestLimitPerDay = 2000,
                        lastStatus = "Configured (Connect local/OCI Ollama host to activate)",
                        lastTestedMillis = 0L
                    ),
                    AiProviderEntity(
                        id = "prov_james_primary_qwen",
                        name = "Qwen 2.5 14B (Apache 2.0 / vLLM or Ollama)",
                        providerType = ProviderType.JAMES_PRIMARY_OPEN_WEIGHT.id,
                        runtimeType = ModelRuntimeType.OLLAMA.id,
                        endpointUrl = "http://10.0.2.2:11434",
                        modelId = "qwen2.5:14b-instruct",
                        enabled = false,
                        isDefaultPrimary = false,
                        estimatedInputCostPer1M = 0.0,
                        estimatedOutputCostPer1M = 0.0,
                        totalRequests = 0,
                        totalEstimatedTokens = 0L,
                        requestLimitPerDay = 2000,
                        lastStatus = "Standby Open-Weight Backup",
                        lastTestedMillis = 0L
                    ),
                    AiProviderEntity(
                        id = "prov_firebase_gemini",
                        name = "Google Gemini (Firebase AI Logic)",
                        providerType = ProviderType.FIREBASE_AI_LOGIC.id,
                        runtimeType = ModelRuntimeType.FIREBASE_SDK.id,
                        endpointUrl = "firebase-app-check://ai-logic",
                        modelId = "gemini-3.8-flash",
                        enabled = true,
                        isDefaultPrimary = false,
                        estimatedInputCostPer1M = 0.075,
                        estimatedOutputCostPer1M = 0.30,
                        totalRequests = 0,
                        totalEstimatedTokens = 0L,
                        requestLimitPerDay = 1000,
                        lastStatus = "Active via Firebase App Check",
                        lastTestedMillis = now
                    ),
                    AiProviderEntity(
                        id = "prov_openai",
                        name = "OpenAI (Collaborator)",
                        providerType = ProviderType.OPENAI.id,
                        runtimeType = ModelRuntimeType.CLOUD_API.id,
                        endpointUrl = ProviderType.OPENAI.defaultEndpoint,
                        modelId = "gpt-4.1-mini",
                        enabled = false,
                        isDefaultPrimary = false,
                        estimatedInputCostPer1M = 0.40,
                        estimatedOutputCostPer1M = 1.60,
                        totalRequests = 0,
                        totalEstimatedTokens = 0L,
                        requestLimitPerDay = 300,
                        lastStatus = "Awaiting API key in Private Vault",
                        lastTestedMillis = 0L
                    ),
                    AiProviderEntity(
                        id = "prov_anthropic",
                        name = "Anthropic Claude (Critic / Reviewer)",
                        providerType = ProviderType.ANTHROPIC.id,
                        runtimeType = ModelRuntimeType.CLOUD_API.id,
                        endpointUrl = ProviderType.ANTHROPIC.defaultEndpoint,
                        modelId = "claude-sonnet-4-20250514",
                        enabled = false,
                        isDefaultPrimary = false,
                        estimatedInputCostPer1M = 3.00,
                        estimatedOutputCostPer1M = 15.00,
                        totalRequests = 0,
                        totalEstimatedTokens = 0L,
                        requestLimitPerDay = 200,
                        lastStatus = "Awaiting API key in Private Vault",
                        lastTestedMillis = 0L
                    ),
                    AiProviderEntity(
                        id = "prov_deepseek",
                        name = "DeepSeek (Reasoning / Coding)",
                        providerType = ProviderType.DEEPSEEK.id,
                        runtimeType = ModelRuntimeType.CLOUD_API.id,
                        endpointUrl = ProviderType.DEEPSEEK.defaultEndpoint,
                        modelId = "deepseek-chat",
                        enabled = false,
                        isDefaultPrimary = false,
                        estimatedInputCostPer1M = 0.27,
                        estimatedOutputCostPer1M = 1.10,
                        totalRequests = 0,
                        totalEstimatedTokens = 0L,
                        requestLimitPerDay = 300,
                        lastStatus = "Awaiting API key in Private Vault",
                        lastTestedMillis = 0L
                    )
                )
                defaults.forEach { dao.upsertProvider(it) }
            }

            if (dao.getConnectorsOnce().isEmpty()) {
                val connectors = listOf(
                    ConnectorEntity(
                        id = "conn_gdrive",
                        providerKey = "GOOGLE_DRIVE",
                        displayName = "Google Drive",
                        category = "CLOUD_STORAGE",
                        endpointOrScope = "https://www.googleapis.com/drive/v3",
                        authMode = "OAuth 2.0 (User Consent)",
                        isSupportedOfficially = true,
                        enabled = false,
                        status = "Requires Google Drive OAuth Scope Setup",
                        notes = "Verified official REST v3 storage target.",
                        lastCheckedMillis = now
                    ),
                    ConnectorEntity(
                        id = "conn_webdav",
                        providerKey = "WEBDAV_NEXTCLOUD",
                        displayName = "WebDAV / Nextcloud",
                        category = "CLOUD_STORAGE",
                        endpointOrScope = "",
                        authMode = "Basic / App Password over HTTPS",
                        isSupportedOfficially = true,
                        enabled = false,
                        status = "Configure WebDAV HTTPS URL",
                        notes = "Open standard cloud repository sync & migration target.",
                        lastCheckedMillis = now
                    ),
                    ConnectorEntity(
                        id = "conn_s3",
                        providerKey = "S3_COMPATIBLE",
                        displayName = "S3-Compatible Object Storage (OCI / R2 / MinIO)",
                        category = "CLOUD_STORAGE",
                        endpointOrScope = "",
                        authMode = "Pre-signed / Access Key in Vault",
                        isSupportedOfficially = true,
                        enabled = false,
                        status = "Configure Bucket Endpoint",
                        notes = "Ideal target for Oracle Cloud Free Object Storage & encrypted backups.",
                        lastCheckedMillis = now
                    ),
                    ConnectorEntity(
                        id = "conn_dropbox",
                        providerKey = "DROPBOX",
                        displayName = "Dropbox",
                        category = "CLOUD_STORAGE",
                        endpointOrScope = "https://api.dropboxapi.com/2",
                        authMode = "OAuth 2.0 Bearer Token",
                        isSupportedOfficially = true,
                        enabled = false,
                        status = "Token Not Configured",
                        notes = "Official HTTP API v2 file sync.",
                        lastCheckedMillis = now
                    ),
                    ConnectorEntity(
                        id = "conn_onedrive",
                        providerKey = "ONEDRIVE",
                        displayName = "Microsoft OneDrive",
                        category = "CLOUD_STORAGE",
                        endpointOrScope = "https://graph.microsoft.com/v1.0/me/drive",
                        authMode = "OAuth 2.0 Microsoft Graph",
                        isSupportedOfficially = true,
                        enabled = false,
                        status = "Token Not Configured",
                        notes = "Official Microsoft Graph Files API.",
                        lastCheckedMillis = now
                    ),
                    ConnectorEntity(
                        id = "conn_github",
                        providerKey = "GITHUB",
                        displayName = "GitHub Repositories",
                        category = "DEV_SERVICE",
                        endpointOrScope = "https://api.github.com",
                        authMode = "Fine-Grained PAT (Private Vault)",
                        isSupportedOfficially = true,
                        enabled = false,
                        status = "PAT Not Configured",
                        notes = "Read issues, repos, releases, and knowledge docs.",
                        lastCheckedMillis = now
                    ),
                    ConnectorEntity(
                        id = "conn_terabox",
                        providerKey = "TERABOX",
                        displayName = "TeraBox (1 TB Free)",
                        category = "CLOUD_STORAGE",
                        endpointOrScope = "N/A",
                        authMode = "Unavailable (No Official Public OAuth/REST API)",
                        isSupportedOfficially = false,
                        enabled = false,
                        status = "Unsupported for Autonomous Backend Sync",
                        notes = "Honest Technical Notice: TeraBox does not publish an official open developer REST/OAuth API for reliable automated server sync. Scraping or reverse-engineering private web cookies violates policy and breaks frequently. Export via Android SAF manually or use Nextcloud / WebDAV / OCI S3 / Google Drive.",
                        lastCheckedMillis = now
                    )
                )
                connectors.forEach { dao.upsertConnector(it) }
            }

            if (dao.getKnowledgeOnce().isEmpty()) {
                val seedKnowledge = listOf(
                    KnowledgeEntity(
                        id = "know_arch_james",
                        title = "JAMES Independent Ecosystem Architecture",
                        content = "JAMES is created and founded by Abbas Adel Rahim (also known as Cope / Mark). Its architecture separates JAMES Core orchestration, open-weight inference, collaborative AI Council review, verified knowledge storage, skills/MCP tooling, and the isolated Private Vault so external models serve as interchangeable collaborators rather than the system identity.",
                        category = "Architecture",
                        source = "internal://james-constitution",
                        sourceType = "SYSTEM_SPEC",
                        acquiredAtMillis = now,
                        lastVerifiedAtMillis = now,
                        reliabilityScore = 0.99f,
                        confidence = 0.99f,
                        topicsCsv = "architecture,founder,abbas,cope,mark,independence",
                        version = 1,
                        validationStatus = ValidationStatus.VERIFIED.id,
                        chunkCount = 1,
                        checksumSha256 = "seed-arch-v1"
                    ),
                    KnowledgeEntity(
                        id = "know_gemma_license",
                        title = "Open-Weight Model Licensing Facts",
                        content = "Google Gemma 3 weights are distributed under the Gemma Terms of Use (open-weight with acceptable-use restrictions, not an OSI open-source license). Qwen 2.5 14B is Apache 2.0 (OSI open-source). Llama 3.1 uses the Llama Community License. JAMES keeps all license notices explicit in documentation and settings.",
                        category = "Models & Licensing",
                        source = "internal://model-catalog",
                        sourceType = "CURATED_DOC",
                        acquiredAtMillis = now,
                        lastVerifiedAtMillis = now,
                        reliabilityScore = 0.97f,
                        confidence = 0.96f,
                        topicsCsv = "gemma,qwen,llama,license,open-weight,ollama,vllm",
                        version = 1,
                        validationStatus = ValidationStatus.VERIFIED.id,
                        chunkCount = 1,
                        checksumSha256 = "seed-license-v1"
                    )
                )
                seedKnowledge.forEach { dao.upsertKnowledge(it) }
            }

            if (dao.getAllSkillsOnce().isEmpty()) {
                val seedSkill = SkillEntity(
                    id = "skill_structured_verification",
                    name = "Fact vs Hypothesis Disciplined Reasoning",
                    description = "Guides JAMES to separate verified facts, unverified assumptions, and actionable next steps in technical responses.",
                    version = "1.0.0",
                    category = "Core Reasoning",
                    sourceType = "BUILTIN",
                    sourceUri = "internal://skills/structured-verification",
                    skillMarkdown = "# SKILL: Fact vs Hypothesis Reasoning\n- Separate confirmed facts from estimates.\n- Cite local knowledge sources when matched.\n- Never fabricate tool output or API success.",
                    permissionsCsv = "READ_KNOWLEDGE",
                    dependenciesCsv = "NONE",
                    enabled = true,
                    inspected = true,
                    inspectionNotes = "Clean read-only instruction skill. No shell execution or external exfiltration patterns.",
                    updatedAtMillis = now
                )
                dao.upsertSkill(seedSkill)
            }

            if (dao.getJobsOnce().isEmpty()) {
                listOf(
                    ScheduledJobEntity(
                        id = "job_learning_cycle",
                        name = "Bounded Learning & Gap Synthesis",
                        taskType = "LEARNING_ANALYSIS",
                        intervalHours = 24,
                        enabled = true,
                        maxBudgetTokens = 2500,
                        lastRunMillis = 0L,
                        lastStatus = "IDLE",
                        lastSummary = "Ready to analyze recent errors and missing knowledge."
                    ),
                    ScheduledJobEntity(
                        id = "job_knowledge_verify",
                        name = "Knowledge Stale-Check & Deduplication",
                        taskType = "KNOWLEDGE_VERIFICATION",
                        intervalHours = 72,
                        enabled = true,
                        maxBudgetTokens = 1000,
                        lastRunMillis = 0L,
                        lastStatus = "IDLE",
                        lastSummary = "Flags entries unverified for >30 days."
                    ),
                    ScheduledJobEntity(
                        id = "job_provider_health",
                        name = "Provider & Backend Health Probe",
                        taskType = "PROVIDER_HEALTH_CHECK",
                        intervalHours = 6,
                        enabled = false,
                        maxBudgetTokens = 0,
                        lastRunMillis = 0L,
                        lastStatus = "IDLE",
                        lastSummary = "On-demand or 6h endpoint connectivity verification."
                    )
                ).forEach { dao.upsertJob(it) }
            }

            seeded = true
        }
    }

    suspend fun getProvidersOnce(): List<AiProviderConfig> = dao.getProvidersOnce().map { it.toDomain() }
    suspend fun getKnowledgeOnce(): List<KnowledgeItem> = dao.getKnowledgeOnce().map { it.toDomain() }
    suspend fun getExperiencesOnce(): List<LearningExperience> = dao.getExperiencesOnce().map { it.toDomain() }
    suspend fun getSkillsOnce(): List<SkillPackage> = dao.getAllSkillsOnce().map { it.toDomain() }
    suspend fun getMcpServersOnce(): List<McpServerConfig> = dao.getMcpServersOnce().map { it.toDomain() }
    suspend fun getConnectorsOnce(): List<ConnectorIntegration> = dao.getConnectorsOnce().map { it.toDomain() }
    suspend fun getProposalsOnce(): List<ImprovementProposal> = dao.getProposalsOnce().map { it.toDomain() }
    suspend fun getScheduledJobsOnce(): List<ScheduledJobConfig> = dao.getJobsOnce().map { it.toDomain() }

    suspend fun saveProvider(provider: AiProviderConfig) {
        if (provider.isDefaultPrimary) {
            dao.clearDefaultPrimaryProviders()
        }
        dao.upsertProvider(provider.toEntity())
    }

    suspend fun setDefaultPrimaryProvider(providerId: String) {
        dao.clearDefaultPrimaryProviders()
        val target = dao.getProvidersOnce().firstOrNull { it.id == providerId } ?: return
        dao.upsertProvider(target.copy(isDefaultPrimary = true, enabled = true))
    }

    suspend fun recordProviderUsage(providerId: String, tokens: Long, status: String) {
        val current = dao.getProvidersOnce().firstOrNull { it.id == providerId } ?: return
        dao.upsertProvider(
            current.copy(
                totalRequests = current.totalRequests + 1,
                totalEstimatedTokens = current.totalEstimatedTokens + tokens.coerceAtLeast(0L),
                lastStatus = status,
                lastTestedMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteProvider(providerId: String) {
        vaultManager.clearCredential(providerId)
        dao.deleteProvider(providerId)
    }

    suspend fun saveKnowledgeItem(item: KnowledgeItem) {
        dao.upsertKnowledge(item.toEntity())
    }

    suspend fun findKnowledgeByChecksum(checksum: String): KnowledgeItem? =
        dao.findKnowledgeByChecksum(checksum)?.toDomain()

    suspend fun deleteKnowledgeItem(id: String) = dao.deleteKnowledge(id)

    suspend fun saveExperience(exp: LearningExperience) = dao.upsertExperience(exp.toEntity())

    suspend fun saveSkill(skill: SkillPackage) = dao.upsertSkill(skill.toEntity())
    suspend fun deleteSkill(id: String) = dao.deleteSkill(id)

    suspend fun saveMcpServer(server: McpServerConfig) = dao.upsertMcpServer(server.toEntity())
    suspend fun deleteMcpServer(id: String) = dao.deleteMcpServer(id)

    suspend fun saveConnector(connector: ConnectorIntegration) = dao.upsertConnector(connector.toEntity())

    suspend fun saveCouncilSession(session: CouncilSession) = dao.upsertCouncilSession(session.toEntity())

    suspend fun saveProposal(proposal: ImprovementProposal) = dao.upsertProposal(proposal.toEntity())

    suspend fun addPrivateVaultItem(title: String, type: VaultItemType, plaintext: String) {
        val id = "vault_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val encrypted = vaultManager.encryptVaultPayload(plaintext)
        dao.upsertVaultItem(
            PrivateVaultEntity(
                id = id,
                title = title.trim().ifBlank { "Private Record" },
                itemType = type.id,
                encryptedPayload = encrypted,
                updatedAtMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun deletePrivateVaultItem(id: String) = dao.deleteVaultItem(id)

    suspend fun saveScheduledJob(job: ScheduledJobConfig) = dao.upsertJob(job.toEntity())

    suspend fun saveMigrationRecord(record: MigrationRecord) = dao.upsertMigration(record.toEntity())

    suspend fun addLog(level: String, component: String, message: String) {
        val cleanMsg = PrivateVaultManager.redactSecrets(message)
        dao.insertLog(
            SystemLogEntity(
                id = "log_${UUID.randomUUID().toString().replace("-", "").take(14)}",
                level = level,
                component = component,
                message = cleanMsg.take(600),
                timestampMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearLogs() = dao.clearLogs()
}

private fun AiProviderEntity.toDomain() = AiProviderConfig(
    id = id, name = name, providerType = ProviderType.fromId(providerType),
    runtimeType = ModelRuntimeType.fromId(runtimeType), endpointUrl = endpointUrl,
    modelId = modelId, enabled = enabled, isDefaultPrimary = isDefaultPrimary,
    estimatedInputCostPer1M = estimatedInputCostPer1M,
    estimatedOutputCostPer1M = estimatedOutputCostPer1M,
    totalRequests = totalRequests, totalEstimatedTokens = totalEstimatedTokens,
    requestLimitPerDay = requestLimitPerDay, lastStatus = lastStatus,
    lastTestedMillis = lastTestedMillis
)

private fun AiProviderConfig.toEntity() = AiProviderEntity(
    id = id, name = name, providerType = providerType.id, runtimeType = runtimeType.id,
    endpointUrl = endpointUrl, modelId = modelId, enabled = enabled,
    isDefaultPrimary = isDefaultPrimary, estimatedInputCostPer1M = estimatedInputCostPer1M,
    estimatedOutputCostPer1M = estimatedOutputCostPer1M, totalRequests = totalRequests,
    totalEstimatedTokens = totalEstimatedTokens, requestLimitPerDay = requestLimitPerDay,
    lastStatus = lastStatus, lastTestedMillis = lastTestedMillis
)

private fun KnowledgeEntity.toDomain() = KnowledgeItem(
    id = id, title = title, content = content, category = category, source = source,
    sourceType = sourceType, acquiredAtMillis = acquiredAtMillis,
    lastVerifiedAtMillis = lastVerifiedAtMillis, reliabilityScore = reliabilityScore,
    confidence = confidence, topicsCsv = topicsCsv, version = version,
    validationStatus = ValidationStatus.fromId(validationStatus),
    chunkCount = chunkCount, checksumSha256 = checksumSha256
)

private fun KnowledgeItem.toEntity() = KnowledgeEntity(
    id = id, title = title, content = content, category = category, source = source,
    sourceType = sourceType, acquiredAtMillis = acquiredAtMillis,
    lastVerifiedAtMillis = lastVerifiedAtMillis, reliabilityScore = reliabilityScore,
    confidence = confidence, topicsCsv = topicsCsv, version = version,
    validationStatus = validationStatus.id, chunkCount = chunkCount,
    checksumSha256 = checksumSha256
)

private fun LearningExperienceEntity.toDomain() = LearningExperience(
    id = id, taskSummary = taskSummary,
    outcomeType = ExperienceOutcomeType.fromId(outcomeType),
    rootCause = rootCause, lessonLearned = lessonLearned,
    relatedSkillId = relatedSkillId, createdAtMillis = createdAtMillis
)

private fun LearningExperience.toEntity() = LearningExperienceEntity(
    id = id, taskSummary = taskSummary, outcomeType = outcomeType.id,
    rootCause = rootCause, lessonLearned = lessonLearned,
    relatedSkillId = relatedSkillId, createdAtMillis = createdAtMillis
)

private fun SkillEntity.toDomain() = SkillPackage(
    id = id, name = name, description = description, version = version,
    category = category, sourceType = sourceType, sourceUri = sourceUri,
    skillMarkdown = skillMarkdown, permissionsCsv = permissionsCsv,
    dependenciesCsv = dependenciesCsv, enabled = enabled, inspected = inspected,
    inspectionNotes = inspectionNotes, updatedAtMillis = updatedAtMillis
)

private fun SkillPackage.toEntity() = SkillEntity(
    id = id, name = name, description = description, version = version,
    category = category, sourceType = sourceType, sourceUri = sourceUri,
    skillMarkdown = skillMarkdown, permissionsCsv = permissionsCsv,
    dependenciesCsv = dependenciesCsv, enabled = enabled, inspected = inspected,
    inspectionNotes = inspectionNotes, updatedAtMillis = updatedAtMillis
)

private fun McpServerEntity.toDomain() = McpServerConfig(
    id = id, name = name, transport = McpTransport.fromId(transport),
    endpointUrl = endpointUrl, status = status,
    discoveredToolsSummary = discoveredToolsSummary,
    enabledToolsCsv = enabledToolsCsv,
    requireApprovalPerCall = requireApprovalPerCall,
    lastConnectedMillis = lastConnectedMillis, logsText = logsText
)

private fun McpServerConfig.toEntity() = McpServerEntity(
    id = id, name = name, transport = transport.id, endpointUrl = endpointUrl,
    status = status, discoveredToolsSummary = discoveredToolsSummary,
    enabledToolsCsv = enabledToolsCsv, requireApprovalPerCall = requireApprovalPerCall,
    lastConnectedMillis = lastConnectedMillis, logsText = logsText
)

private fun ConnectorEntity.toDomain() = ConnectorIntegration(
    id = id, providerKey = providerKey, displayName = displayName,
    category = category, endpointOrScope = endpointOrScope, authMode = authMode,
    isSupportedOfficially = isSupportedOfficially, enabled = enabled,
    status = status, notes = notes, lastCheckedMillis = lastCheckedMillis
)

private fun ConnectorIntegration.toEntity() = ConnectorEntity(
    id = id, providerKey = providerKey, displayName = displayName,
    category = category, endpointOrScope = endpointOrScope, authMode = authMode,
    isSupportedOfficially = isSupportedOfficially, enabled = enabled,
    status = status, notes = notes, lastCheckedMillis = lastCheckedMillis
)

private fun CouncilSessionEntity.toDomain() = CouncilSession(
    id = id, topic = topic, mode = mode, status = status, maxRounds = maxRounds,
    roundsCompleted = roundsCompleted, participantsSummary = participantsSummary,
    transcriptMarkdown = transcriptMarkdown, agreementsText = agreementsText,
    disagreementsText = disagreementsText, conclusionText = conclusionText,
    estimatedTokensUsed = estimatedTokensUsed, createdAtMillis = createdAtMillis
)

private fun CouncilSession.toEntity() = CouncilSessionEntity(
    id = id, topic = topic, mode = mode, status = status, maxRounds = maxRounds,
    roundsCompleted = roundsCompleted, participantsSummary = participantsSummary,
    transcriptMarkdown = transcriptMarkdown, agreementsText = agreementsText,
    disagreementsText = disagreementsText, conclusionText = conclusionText,
    estimatedTokensUsed = estimatedTokensUsed, createdAtMillis = createdAtMillis
)

private fun ImprovementProposalEntity.toDomain() = ImprovementProposal(
    id = id, sessionId = sessionId, title = title,
    problemDescription = problemDescription, proposedSolution = proposedSolution,
    expectedBenefits = expectedBenefits, potentialRisks = potentialRisks,
    dependenciesText = dependenciesText, implementationPlan = implementationPlan,
    testPlan = testPlan, rollbackPlan = rollbackPlan,
    approvalStatus = ProposalApprovalStatus.fromId(approvalStatus),
    createdAtMillis = createdAtMillis
)

private fun ImprovementProposal.toEntity() = ImprovementProposalEntity(
    id = id, sessionId = sessionId, title = title,
    problemDescription = problemDescription, proposedSolution = proposedSolution,
    expectedBenefits = expectedBenefits, potentialRisks = potentialRisks,
    dependenciesText = dependenciesText, implementationPlan = implementationPlan,
    testPlan = testPlan, rollbackPlan = rollbackPlan,
    approvalStatus = approvalStatus.id, createdAtMillis = createdAtMillis
)

private fun ScheduledJobEntity.toDomain() = ScheduledJobConfig(
    id = id, name = name, taskType = taskType, intervalHours = intervalHours,
    enabled = enabled, maxBudgetTokens = maxBudgetTokens, lastRunMillis = lastRunMillis,
    lastStatus = lastStatus, lastSummary = lastSummary
)

private fun ScheduledJobConfig.toEntity() = ScheduledJobEntity(
    id = id, name = name, taskType = taskType, intervalHours = intervalHours,
    enabled = enabled, maxBudgetTokens = maxBudgetTokens, lastRunMillis = lastRunMillis,
    lastStatus = lastStatus, lastSummary = lastSummary
)

private fun MigrationRecordEntity.toDomain() = MigrationRecord(
    id = id, sourceProvider = sourceProvider, targetProvider = targetProvider,
    status = status, totalFiles = totalFiles, transferredFiles = transferredFiles,
    checksumManifestSha256 = checksumManifestSha256, reportSummary = reportSummary,
    sourceDeleteApproved = sourceDeleteApproved, createdAtMillis = createdAtMillis
)

private fun MigrationRecord.toEntity() = MigrationRecordEntity(
    id = id, sourceProvider = sourceProvider, targetProvider = targetProvider,
    status = status, totalFiles = totalFiles, transferredFiles = transferredFiles,
    checksumManifestSha256 = checksumManifestSha256, reportSummary = reportSummary,
    sourceDeleteApproved = sourceDeleteApproved, createdAtMillis = createdAtMillis
)

private fun SystemLogEntity.toDomain() = SystemLogEntry(
    id = id, level = level, component = component, message = message,
    timestampMillis = timestampMillis
)
