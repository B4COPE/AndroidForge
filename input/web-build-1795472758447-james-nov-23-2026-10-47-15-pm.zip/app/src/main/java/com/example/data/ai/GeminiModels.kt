package com.example.data.ai

data class SupportedGeminiModel(
    val id: String,
    val displayName: String,
    val tierLabelEn: String,
    val tierLabelAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val requiresBillingNote: Boolean = false
)

object GeminiModelCatalog {
    const val DEFAULT_MODEL_ID = "gemini-3.8-flash"

    val models: List<SupportedGeminiModel> = listOf(
        SupportedGeminiModel(
            id = "gemini-3.8-flash",
            displayName = "Gemini 3.8 Flash",
            tierLabelEn = "Recommended · Free Tier",
            tierLabelAr = "موصى به · مجاني",
            descriptionEn = "Frontier-class reasoning, multimodal vision & PDF understanding, and low-latency streaming.",
            descriptionAr = "أداء متقدم في التحليل وفهم الصور وملفات PDF واستجابة فائقة السرعة.",
            requiresBillingNote = false
        ),
        SupportedGeminiModel(
            id = "gemini-3.5-flash-lite",
            displayName = "Gemini 3.5 Flash-Lite",
            tierLabelEn = "Ultra Fast · Free Tier",
            tierLabelAr = "سريع جداً · مجاني",
            descriptionEn = "Ultra-fast lightweight model ideal for quick tasks, drafting, and high-volume queries.",
            descriptionAr = "نموذج خفيف وسريع جداً للمهام اليومية السريعة والمسودات.",
            requiresBillingNote = false
        ),
        SupportedGeminiModel(
            id = "gemini-4-argon",
            displayName = "Gemini 4 Argon",
            tierLabelEn = "Deep Reasoning · Blaze Plan",
            tierLabelAr = "تحليل عميق · خطة Blaze",
            descriptionEn = "Highest-capability model for complex STEM reasoning, architecture, and deep coding.",
            descriptionAr = "أقوى نموذج للتحليل المعقد والبرمجة المتقدمة والرياضيات (قد يتطلب خطة Blaze).",
            requiresBillingNote = true
        )
    )

    fun resolveValidModel(modelId: String): SupportedGeminiModel =
        models.firstOrNull { it.id == modelId } ?: models.first()
}
