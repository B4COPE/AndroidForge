package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.AppLanguage
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.viewmodel.MainAppViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun GeneralSettingsScreen(
    mainViewModel: MainAppViewModel,
    onNavigateBack: () -> Unit,
    onOpenAppearance: () -> Unit,
    onOpenAiSettings: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenAccount: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val ttsVoices by mainViewModel.voiceOutputManager.availableVoices.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.generalSettings) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Navigation Hub
                SettingsLinkRow(Icons.Outlined.Palette, strings.appearanceSettings, onOpenAppearance, "nav_appearance")
                SettingsLinkRow(Icons.Outlined.AutoAwesome, strings.aiSettings, onOpenAiSettings, "nav_ai_settings")
                SettingsLinkRow(Icons.Outlined.Psychology, strings.memoryManagement, onOpenMemory, "nav_memory")
                SettingsLinkRow(Icons.Outlined.AccountCircle, strings.accountAndSync, onOpenAccount, "nav_account")
                SettingsLinkRow(Icons.Outlined.Shield, strings.privacyAndData, onOpenPrivacy, "nav_privacy")
                SettingsLinkRow(Icons.Outlined.Info, strings.aboutJames, onOpenAbout, "nav_about")

                // Language & Direction
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.languageTitle, style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppLanguage.entries.forEach { lang ->
                                FilterChip(
                                    selected = settings.appLanguage == lang,
                                    onClick = { mainViewModel.setAppLanguage(lang) },
                                    label = { Text(if (strings.isArabic) lang.labelAr else lang.labelEn) },
                                    modifier = Modifier.testTag("settings_lang_${lang.code}")
                                )
                            }
                        }
                    }
                }

                // Voice Settings
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.voiceSettingsTitle, style = MaterialTheme.typography.titleSmall)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Enable Voice Output (TTS)", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = settings.voiceOutputEnabled,
                                onCheckedChange = { mainViewModel.setVoiceOutputEnabled(it) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Auto-Speak in Voice Mode", style = MaterialTheme.typography.bodyMedium)
                            Switch(
                                checked = settings.autoSpeakInVoiceMode,
                                onCheckedChange = { mainViewModel.setAutoSpeakInVoiceMode(it) }
                            )
                        }

                        Text(
                            text = "Speech Rate: ${String.format("%.2fx", settings.speechRate)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = settings.speechRate,
                            onValueChange = { mainViewModel.setSpeechRate(it) },
                            valueRange = 0.5f..1.8f
                        )

                        Text("Speech Input Language", style = MaterialTheme.typography.bodySmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = settings.voiceInputLanguage.startsWith("en"),
                                onClick = { mainViewModel.setVoiceInputLanguage("en-US") },
                                label = { Text("English (US)") }
                            )
                            FilterChip(
                                selected = settings.voiceInputLanguage.startsWith("ar"),
                                onClick = { mainViewModel.setVoiceInputLanguage("ar-SA") },
                                label = { Text("العربية (AR)") }
                            )
                        }

                        if (ttsVoices.isNotEmpty()) {
                            Text("Installed TTS Voice", style = MaterialTheme.typography.bodySmall)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = settings.selectedTtsVoiceName.isBlank(),
                                    onClick = { mainViewModel.setSelectedTtsVoiceName("") },
                                    label = { Text("System Default") }
                                )
                                ttsVoices.take(6).forEach { voice ->
                                    FilterChip(
                                        selected = settings.selectedTtsVoiceName == voice.name,
                                        onClick = { mainViewModel.setSelectedTtsVoiceName(voice.name) },
                                        label = { Text(voice.displayName) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsLinkRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.weight(1f)
            )
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null)
        }
    }
}
