package com.example.ui.viewmodel

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppLanguage
import com.example.data.local.JamesSettings
import com.example.data.local.PreferencesRepository
import com.example.data.local.ResponseLength
import com.example.data.local.ResponseStyle
import com.example.data.model.Conversation
import com.example.data.model.LocalNote
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.data.remote.CloudSyncRepository
import com.example.data.remote.SyncSummary
import com.example.data.repository.JamesRepository
import com.example.security.CryptoManager
import com.example.ui.theme.FontSizeScale
import com.example.ui.theme.JamesAccent
import com.example.ui.theme.ThemeMode
import com.example.util.NetworkMonitor
import com.example.util.VoiceInputManager
import com.example.util.VoiceOutputManager
import com.example.util.signOutGoogle
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface SyncState {
    data object Idle : SyncState
    data object Syncing : SyncState
    data class Success(val summary: SyncSummary) : SyncState
    data class Error(val message: String) : SyncState
}

class MainAppViewModel(
    private val repository: JamesRepository,
    private val preferencesRepository: PreferencesRepository,
    private val cloudSyncRepository: CloudSyncRepository,
    val cryptoManager: CryptoManager,
    val networkMonitor: NetworkMonitor,
    val voiceInputManager: VoiceInputManager,
    val voiceOutputManager: VoiceOutputManager
) : ViewModel() {

    val settings: StateFlow<JamesSettings> = preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, JamesSettings())

    val conversations: StateFlow<List<Conversation>> = repository.observeConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memories: StateFlow<List<MemoryItem>> = repository.observeMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<LocalNote>> = repository.observeNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline

    val currentUser: StateFlow<FirebaseUser?> = callbackFlow {
        val auth = Firebase.auth
        trySend(auth.currentUser)
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, Firebase.auth.currentUser)

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private val _e2eeUnlocked = MutableStateFlow(cryptoManager.isE2eeUnlocked())
    val e2eeUnlocked: StateFlow<Boolean> = _e2eeUnlocked.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun completeOnboarding() {
        viewModelScope.launch { preferencesRepository.setOnboardingCompleted(true) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferencesRepository.setThemeMode(mode) }
    }

    fun setAccent(accent: JamesAccent) {
        viewModelScope.launch { preferencesRepository.setAccent(accent) }
    }

    fun setFontScale(scale: FontSizeScale) {
        viewModelScope.launch { preferencesRepository.setFontScale(scale) }
    }

    fun setAppLanguage(language: AppLanguage) {
        viewModelScope.launch { preferencesRepository.setAppLanguage(language) }
    }

    fun setPreferredResponseLanguage(lang: String) {
        viewModelScope.launch { preferencesRepository.setPreferredResponseLanguage(lang) }
    }

    fun setResponseLength(length: ResponseLength) {
        viewModelScope.launch { preferencesRepository.setResponseLength(length) }
    }

    fun setResponseStyle(style: ResponseStyle) {
        viewModelScope.launch { preferencesRepository.setResponseStyle(style) }
    }

    fun setCustomInstructions(text: String) {
        viewModelScope.launch { preferencesRepository.setCustomInstructions(text) }
    }

    fun setSelectedModel(modelId: String) {
        viewModelScope.launch { preferencesRepository.setSelectedModel(modelId) }
    }

    fun setTemperature(value: Float) {
        viewModelScope.launch { preferencesRepository.setTemperature(value) }
    }

    fun setTopP(value: Float) {
        viewModelScope.launch { preferencesRepository.setTopP(value) }
    }

    fun setContextTurnLimit(limit: Int) {
        viewModelScope.launch { preferencesRepository.setContextTurnLimit(limit) }
    }

    fun setAutoSummarizeContext(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setAutoSummarizeContext(enabled) }
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setMemoryEnabled(enabled) }
    }

    fun setVoiceOutputEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setVoiceOutputEnabled(enabled)
            if (!enabled) voiceOutputManager.stop()
        }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { preferencesRepository.setSpeechRate(rate) }
    }

    fun setSelectedTtsVoiceName(name: String) {
        viewModelScope.launch { preferencesRepository.setSelectedTtsVoiceName(name) }
    }

    fun setVoiceInputLanguage(langTag: String) {
        viewModelScope.launch { preferencesRepository.setVoiceInputLanguage(langTag) }
    }

    fun setAutoSpeakInVoiceMode(enabled: Boolean) {
        viewModelScope.launch { preferencesRepository.setAutoSpeakInVoiceMode(enabled) }
    }

    fun setCloudSyncEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setCloudSyncEnabled(enabled)
            if (enabled && currentUser.value != null) {
                syncNow()
            }
        }
    }

    fun renameConversation(id: String, title: String) {
        viewModelScope.launch { repository.renameConversation(id, title) }
    }

    fun togglePinConversation(id: String) {
        viewModelScope.launch { repository.togglePinConversation(id) }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch { repository.deleteConversation(id) }
    }

    fun deleteAllConversations() {
        viewModelScope.launch {
            repository.deleteAllConversations()
            _statusBanner.value = "All conversations cleared."
        }
    }

    fun addMemory(category: MemoryCategory, content: String) {
        if (content.isBlank()) return
        viewModelScope.launch { repository.addMemory(category, content) }
    }

    fun updateMemory(memory: MemoryItem) {
        viewModelScope.launch { repository.updateMemory(memory) }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch { repository.deleteMemory(id) }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            repository.deleteAllMemories()
            _statusBanner.value = "All memories cleared."
        }
    }

    fun saveNote(title: String, content: String, existingId: String? = null) {
        viewModelScope.launch { repository.saveNote(title, content, existingId) }
    }

    fun deleteNote(id: String) {
        viewModelScope.launch { repository.deleteNote(id) }
    }

    fun onSignedIn() {
        viewModelScope.launch {
            val user = Firebase.auth.currentUser ?: return@launch
            cloudSyncRepository.ensureUserProfile(user.displayName ?: "JAMES User", user.email)
            if (settings.value.cloudSyncEnabled) {
                syncNow()
            }
        }
    }

    fun signOut(context: Context) {
        val cm = CredentialManager.create(context)
        signOutGoogle(cm, viewModelScope) {
            cryptoManager.lockE2eeVault()
            _e2eeUnlocked.value = false
            viewModelScope.launch {
                preferencesRepository.setCloudSyncEnabled(false)
            }
            _syncState.value = SyncState.Idle
            _statusBanner.value = "Signed out. Switched to local-only encrypted mode."
        }
    }

    fun configureOrUnlockE2ee(passphrase: String) {
        if (passphrase.length < 6) {
            _statusBanner.value = "E2EE passphrase must be at least 6 characters."
            return
        }
        viewModelScope.launch {
            if (Firebase.auth.currentUser != null) {
                val res = cloudSyncRepository.configureOrVerifyE2eePassphrase(passphrase)
                res.onSuccess { ok ->
                    if (ok) {
                        _e2eeUnlocked.value = true
                        preferencesRepository.setE2eeEnabled(true)
                        _statusBanner.value = "E2EE Vault unlocked for cloud sync."
                    } else {
                        _e2eeUnlocked.value = false
                        _statusBanner.value = "Incorrect E2EE passphrase for this cloud account."
                    }
                }.onFailure { err ->
                    _statusBanner.value = err.localizedMessage ?: "Failed to verify E2EE vault."
                }
            } else {
                val salt = cryptoManager.generateRandomSaltBase64()
                cryptoManager.unlockE2eeVault(passphrase, salt)
                _e2eeUnlocked.value = true
                preferencesRepository.setE2eeEnabled(true)
                _statusBanner.value = "Local session E2EE key initialized."
            }
        }
    }

    fun lockE2eeVault() {
        cryptoManager.lockE2eeVault()
        _e2eeUnlocked.value = false
    }

    fun syncNow() {
        viewModelScope.launch {
            _syncState.value = SyncState.Syncing
            val res = repository.syncAllWithCloud()
            res.onSuccess { summary ->
                _syncState.value = SyncState.Success(summary)
                _statusBanner.value =
                    "Synced ${summary.pushedConversations + summary.pulledConversations} chats, " +
                        "${summary.pushedMemories + summary.pulledMemories} memories, " +
                        "${summary.pushedNotes + summary.pulledNotes} notes."
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Cloud sync failed."
                _syncState.value = SyncState.Error(msg)
                _statusBanner.value = msg
            }
        }
    }

    fun deleteCloudData() {
        viewModelScope.launch {
            val res = cloudSyncRepository.deleteAllCloudData()
            res.onSuccess {
                _statusBanner.value = "All cloud Firestore data deleted."
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Failed to delete cloud data."
            }
        }
    }

    suspend fun exportAllDataJson(): String = repository.exportAllDataAsJson()

    override fun onCleared() {
        super.onCleared()
        voiceInputManager.stopListening()
        voiceOutputManager.release()
        networkMonitor.release()
    }
}
