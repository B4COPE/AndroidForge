package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.AttachmentType
import com.example.data.model.PendingAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

object AttachmentProcessor {

    private const val MAX_INLINE_BYTES = 18L * 1024L * 1024L // < 20MB Firebase AI limit
    private const val MAX_TEXT_BYTES = 512L * 1024L

    suspend fun processUri(context: Context, uri: Uri): Result<PendingAttachment> =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                val mimeType = resolver.getType(uri) ?: inferMimeFromUri(uri)
                val (name, sizeBytes) = queryFileMetadata(context, uri)

                when {
                    mimeType.startsWith("image/") -> {
                        if (sizeBytes > MAX_INLINE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Image exceeds 18 MB limit (${formatFileSize(sizeBytes)}).")
                            )
                        }
                        val bitmap = decodeScaledBitmap(context, uri, maxDimension = 1600)
                            ?: return@withContext Result.failure(
                                IllegalStateException("Could not decode image file \"$name\".")
                            )
                        Result.success(
                            PendingAttachment(
                                id = "att_${UUID.randomUUID().toString().take(12)}",
                                uri = uri,
                                name = name,
                                mimeType = mimeType,
                                sizeBytes = if (sizeBytes > 0) sizeBytes else estimateBitmapSize(bitmap),
                                type = AttachmentType.IMAGE,
                                previewBitmap = bitmap
                            )
                        )
                    }

                    mimeType == "application/pdf" || name.endsWith(".pdf", ignoreCase = true) -> {
                        if (sizeBytes > MAX_INLINE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("PDF exceeds 18 MB inline limit (${formatFileSize(sizeBytes)}).")
                            )
                        }
                        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: return@withContext Result.failure(
                                IllegalStateException("Unable to read PDF file \"$name\".")
                            )
                        if (bytes.size > MAX_INLINE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("PDF exceeds 18 MB inline limit (${formatFileSize(bytes.size.toLong())}).")
                            )
                        }
                        val (previewBmp, pageCount) = renderPdfFirstPage(context, uri)
                        Result.success(
                            PendingAttachment(
                                id = "att_${UUID.randomUUID().toString().take(12)}",
                                uri = uri,
                                name = name,
                                mimeType = "application/pdf",
                                sizeBytes = bytes.size.toLong(),
                                type = AttachmentType.PDF,
                                previewBitmap = previewBmp,
                                pdfBytes = bytes,
                                pdfPageCount = pageCount
                            )
                        )
                    }

                    isSupportedTextDocument(mimeType, name) -> {
                        if (sizeBytes > MAX_TEXT_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Text file \"$name\" is larger than 512 KB (${formatFileSize(sizeBytes)}).")
                            )
                        }
                        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: return@withContext Result.failure(
                                IllegalStateException("Unable to read text file \"$name\".")
                            )
                        if (bytes.size > MAX_TEXT_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Text file exceeds 512 KB limit.")
                            )
                        }
                        val contentText = bytes.toString(Charsets.UTF_8)
                        Result.success(
                            PendingAttachment(
                                id = "att_${UUID.randomUUID().toString().take(12)}",
                                uri = uri,
                                name = name,
                                mimeType = mimeType.ifBlank { "text/plain" },
                                sizeBytes = bytes.size.toLong(),
                                type = AttachmentType.TEXT,
                                textContent = contentText
                            )
                        )
                    }

                    else -> {
                        Result.failure(
                            IllegalArgumentException(
                                "Unsupported file format ($mimeType). Supported: Images (PNG, JPG, WEBP), PDF, and text/code files (.txt, .md, .csv, .json, .kt, .py)."
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "Unknown size"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format("%.2f MB", mb)
            kb >= 1.0 -> String.format("%.1f KB", kb)
            else -> "$bytes B"
        }
    }

    private fun queryFileMetadata(context: Context, uri: Uri): Pair<String, Long> {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "attachment"
        var size = 0L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) {
                        cursor.getString(nameIdx)?.let { if (it.isNotBlank()) name = it }
                    }
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        size = cursor.getLong(sizeIdx)
                    }
                }
            }
        } catch (_: Exception) {
        }
        return name to size
    }

    private fun decodeScaledBitmap(context: Context, uri: Uri, maxDimension: Int): Bitmap? {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
        var sampleSize = 1
        while (options.outWidth / sampleSize > maxDimension || options.outHeight / sampleSize > maxDimension) {
            sampleSize *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOpts)
        }
    }

    private fun renderPdfFirstPage(context: Context, uri: Uri): Pair<Bitmap?, Int> {
        return try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return null to 0
            pfd.use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    val count = renderer.pageCount
                    if (count <= 0) return null to 0
                    renderer.openPage(0).use { page ->
                        val width = page.width.coerceAtMost(900)
                        val height = (page.height.toFloat() / page.width.coerceAtLeast(1) * width).toInt()
                            .coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp to count
                    }
                }
            }
        } catch (_: Exception) {
            null to 0
        }
    }

    private fun estimateBitmapSize(bmp: Bitmap): Long {
        val stream = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return stream.size().toLong()
    }

    private fun inferMimeFromUri(uri: Uri): String {
        val lower = uri.toString().lowercase()
        return when {
            lower.endsWith(".pdf") -> "application/pdf"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".webp") -> "image/webp"
            lower.endsWith(".md") -> "text/markdown"
            lower.endsWith(".csv") -> "text/csv"
            lower.endsWith(".json") -> "application/json"
            else -> "text/plain"
        }
    }

    private fun isSupportedTextDocument(mimeType: String, name: String): Boolean {
        if (mimeType.startsWith("text/")) return true
        if (mimeType in listOf("application/json", "application/xml", "application/javascript")) return true
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext in setOf(
            "txt", "md", "markdown", "csv", "json", "xml", "yaml", "yml",
            "kt", "kts", "java", "py", "js", "ts", "html", "css", "sql", "log", "sh"
        )
    }
}
