package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.AppLanguage
import com.example.ui.components.GoogleSignInButton
import com.example.ui.components.JamesLogoMark
import com.example.ui.i18n.LocalJamesStrings

private data class OnboardingPage(
    val icon: ImageVector,
    val titleEn: String,
    val titleAr: String,
    val bodyEn: String,
    val bodyAr: String
)

@Composable
fun OnboardingScreen(
    currentLanguage: AppLanguage,
    isSignedIn: Boolean,
    onSelectLanguage: (AppLanguage) -> Unit,
    onSignedIn: () -> Unit,
    onComplete: () -> Unit
) {
    val strings = LocalJamesStrings.current
    var page by remember { mutableIntStateOf(0) }
    var authFeedback by remember { mutableStateOf<String?>(null) }

    val pages = remember {
        listOf(
            OnboardingPage(
                icon = Icons.Rounded.AutoAwesome,
                titleEn = "Meet JAMES — Your Personal Intelligence",
                titleAr = "تعرّف على JAMES — مساعدك الشخصي الذكي",
                bodyEn = "Designed for clarity, focus, and deep reasoning. Powered securely via Firebase AI Logic with full Markdown, code syntax highlighting, and multimodal document understanding.",
                bodyAr = "مصمم للوضوح والتركيز والتحليل العميق. مدعوم بأمان عبر Firebase AI Logic مع دعم Markdown وتلوين الأكواد وفهم الصور والمستندات."
            ),
            OnboardingPage(
                icon = Icons.Rounded.Lock,
                titleEn = "Encrypted Local Vault & Controlled Memory",
                titleAr = "خزنة محلية مشفرة وذاكرة تحت تحكمك",
                bodyEn = "Your conversations, notes, and approved memories stay AES-256-GCM encrypted on your device. Works completely offline without an account—or sign in with Google for optional E2EE cloud sync.",
                bodyAr = "محادثاتك وملاحظاتك وذكرياتك تبقى مشفرة على جهازك. يعمل دون إنترنت وبدون حساب، أو سجّل الدخول عبر Google للمزامنة المشفرة."
            ),
            OnboardingPage(
                icon = Icons.Rounded.Mic,
                titleEn = "Bilingual Voice, Documents & Personalization",
                titleAr = "صوت ثنائي اللغة ومستندات وتخصيص كامل",
                bodyEn = "Speak naturally in English or Arabic (RTL), attach images, PDFs, or source files, and tailor JAMES's style, model, and custom instructions.",
                bodyAr = "تحدث بالعربية أو الإنجليزية، أرفق الصور وملفات PDF والنصوص، وخصّص أسلوب JAMES ونموذج الذكاء الاصطناعي."
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .testTag("onboarding_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top bar: Logo + Language quick switch + Skip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    JamesLogoMark(size = 32.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "JAMES",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                TextButton(
                    onClick = onComplete,
                    modifier = Modifier.testTag("onboarding_skip_button")
                ) {
                    Text(strings.onboardingSkip)
                }
            }

            // Scrollable Hero Artwork + Copy
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_james_onboarding_1795454309764),
                        contentDescription = "JAMES futuristic workspace",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                                )
                            )
                    )
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Icon(
                            imageVector = pages[page].icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp).size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Language quick toggle
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = currentLanguage == lang,
                            onClick = { onSelectLanguage(lang) },
                            label = { Text(if (strings.isArabic) lang.labelAr else lang.labelEn) },
                            modifier = Modifier.testTag("onboarding_lang_${lang.code}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                val current = pages[page]
                Text(
                    text = if (strings.isArabic) current.titleAr else current.titleEn,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (strings.isArabic) current.bodyAr else current.bodyEn,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Page indicators
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    pages.indices.forEach { idx ->
                        Box(
                            modifier = Modifier
                                .height(6.dp)
                                .width(if (idx == page) 28.dp else 8.dp)
                                .clip(CircleShape)
                                .background(
                                    if (idx == page) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.outline
                                )
                        )
                    }
                }
            }

            // Bottom Actions (always pinned and visible)
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (page == pages.lastIndex && !isSignedIn) {
                    GoogleSignInButton(
                        onAuthSuccess = {
                            onSignedIn()
                            onComplete()
                        },
                        onAuthError = { err -> authFeedback = err }
                    )
                    authFeedback?.let { msg ->
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }

                if (page < pages.lastIndex) {
                    Button(
                        onClick = { page++ },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("onboarding_next_button")
                    ) {
                        Text(strings.onboardingNext)
                    }
                } else {
                    OutlinedButton(
                        onClick = onComplete,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("onboarding_start_button")
                    ) {
                        Text(
                            if (isSignedIn) strings.onboardingGetStarted
                            else if (strings.isArabic) "المتابعة دون حساب (محلي)"
                            else "Continue Without Account (Local Mode)"
                        )
                    }
                }
            }
        }
    }
}
