package com.example.ui.navigation

import android.net.Uri
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AiSettingsScreen
import com.example.ui.screens.AppearanceScreen
import com.example.ui.screens.AttachmentPreviewScreen
import com.example.ui.screens.CloudMigrationScreen
import com.example.ui.screens.ControlCenterScreen
import com.example.ui.screens.ConversationHistoryScreen
import com.example.ui.screens.CouncilDashboardScreen
import com.example.ui.screens.DiagnosticsLogsScreen
import com.example.ui.screens.ExtensionsHubScreen
import com.example.ui.screens.GeneralSettingsScreen
import com.example.ui.screens.HomeChatScreen
import com.example.ui.screens.IndividualConversationScreen
import com.example.ui.screens.KnowledgeLearningScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PrivacyScreen
import com.example.ui.screens.PrivateVaultScreen
import com.example.ui.screens.ProvidersRuntimeScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VoiceModeScreen
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.EcosystemViewModel
import com.example.ui.viewmodel.MainAppViewModel

object JamesRoutes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val HISTORY = "history"
    const val CONVERSATION_PATTERN = "conversation/{conversationId}"
    const val VOICE = "voice"
    const val MEMORY = "memory"
    const val ACCOUNT = "account"
    const val AI_SETTINGS = "ai_settings"
    const val GENERAL_SETTINGS = "general_settings"
    const val APPEARANCE = "appearance"
    const val PRIVACY = "privacy"
    const val ATTACHMENT_PREVIEW = "attachment_preview"
    const val ABOUT = "about"
    // Expanded JAMES Ecosystem Routes
    const val CONTROL_CENTER = "control_center"
    const val COUNCIL_DASHBOARD = "council_dashboard"
    const val PROVIDERS_RUNTIME = "providers_runtime"
    const val KNOWLEDGE_LEARNING = "knowledge_learning"
    const val EXTENSIONS_HUB = "extensions_hub"
    const val CLOUD_MIGRATION = "cloud_migration"
    const val PRIVATE_VAULT = "private_vault"
    const val DIAGNOSTICS_LOGS = "diagnostics_logs"

    fun conversation(conversationId: String): String =
        "conversation/${Uri.encode(conversationId)}"
}

@Composable
fun JamesNavHost(
    chatViewModel: ChatViewModel,
    mainViewModel: MainAppViewModel,
    ecosystemViewModel: EcosystemViewModel,
    navController: NavHostController = rememberNavController()
) {
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val currentUser by mainViewModel.currentUser.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = JamesRoutes.SPLASH,
        enterTransition = { fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { fadeOut() }
    ) {
        // 1. Splash Screen
        composable(JamesRoutes.SPLASH) {
            SplashScreen(
                onboardingCompleted = settings.onboardingCompleted,
                onNavigateNext = { completed ->
                    val target = if (completed) JamesRoutes.HOME else JamesRoutes.ONBOARDING
                    navController.navigate(target) {
                        popUpTo(JamesRoutes.SPLASH) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 2. Onboarding Screen
        composable(JamesRoutes.ONBOARDING) {
            OnboardingScreen(
                currentLanguage = settings.appLanguage,
                isSignedIn = currentUser != null,
                onSelectLanguage = { mainViewModel.setAppLanguage(it) },
                onSignedIn = { mainViewModel.onSignedIn() },
                onComplete = {
                    mainViewModel.completeOnboarding()
                    navController.navigate(JamesRoutes.HOME) {
                        popUpTo(JamesRoutes.ONBOARDING) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 3. Main Home / Active Chat Screen
        composable(JamesRoutes.HOME) {
            HomeChatScreen(
                chatViewModel = chatViewModel,
                mainViewModel = mainViewModel,
                conversationIdArg = null,
                onOpenVoiceMode = { navController.navigate(JamesRoutes.VOICE) },
                onOpenHistory = { navController.navigate(JamesRoutes.HISTORY) },
                onOpenMemory = { navController.navigate(JamesRoutes.MEMORY) },
                onOpenAccount = { navController.navigate(JamesRoutes.ACCOUNT) },
                onOpenSettings = { navController.navigate(JamesRoutes.GENERAL_SETTINGS) },
                onOpenAiSettings = { navController.navigate(JamesRoutes.AI_SETTINGS) },
                onOpenPrivacy = { navController.navigate(JamesRoutes.PRIVACY) },
                onOpenAttachmentPreview = { navController.navigate(JamesRoutes.ATTACHMENT_PREVIEW) },
                onOpenAbout = { navController.navigate(JamesRoutes.ABOUT) },
                onOpenControlCenter = { navController.navigate(JamesRoutes.CONTROL_CENTER) },
                onOpenCouncil = { navController.navigate(JamesRoutes.COUNCIL_DASHBOARD) },
                onOpenPrivateVault = { navController.navigate(JamesRoutes.PRIVATE_VAULT) }
            )
        }

        // 4. Conversation History (+ Offline Notes)
        composable(JamesRoutes.HISTORY) {
            ConversationHistoryScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenConversation = { id ->
                    navController.navigate(JamesRoutes.conversation(id))
                },
                onNewConversation = {
                    chatViewModel.startNewConversation()
                    navController.navigate(JamesRoutes.HOME) {
                        popUpTo(JamesRoutes.HOME) { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
        }

        // 5. Individual Conversation Screen
        composable(
            route = JamesRoutes.CONVERSATION_PATTERN,
            arguments = listOf(
                navArgument("conversationId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val conversationId = backStackEntry.arguments?.getString("conversationId").orEmpty()
            IndividualConversationScreen(
                conversationId = conversationId,
                chatViewModel = chatViewModel,
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenVoiceMode = { navController.navigate(JamesRoutes.VOICE) },
                onOpenAiSettings = { navController.navigate(JamesRoutes.AI_SETTINGS) },
                onOpenAttachmentPreview = { navController.navigate(JamesRoutes.ATTACHMENT_PREVIEW) }
            )
        }

        // 6. Voice Interaction Screen
        composable(JamesRoutes.VOICE) {
            VoiceModeScreen(
                chatViewModel = chatViewModel,
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 7. Personal Memory Management Screen
        composable(JamesRoutes.MEMORY) {
            MemoryScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 8. Account / Profile / Cloud Sync Screen
        composable(JamesRoutes.ACCOUNT) {
            AccountScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 9. AI Settings Screen
        composable(JamesRoutes.AI_SETTINGS) {
            AiSettingsScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 10. General Settings Screen
        composable(JamesRoutes.GENERAL_SETTINGS) {
            GeneralSettingsScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenAppearance = { navController.navigate(JamesRoutes.APPEARANCE) },
                onOpenAiSettings = { navController.navigate(JamesRoutes.AI_SETTINGS) },
                onOpenMemory = { navController.navigate(JamesRoutes.MEMORY) },
                onOpenAccount = { navController.navigate(JamesRoutes.ACCOUNT) },
                onOpenPrivacy = { navController.navigate(JamesRoutes.PRIVACY) },
                onOpenAbout = { navController.navigate(JamesRoutes.ABOUT) }
            )
        }

        // 11. Appearance Settings Screen
        composable(JamesRoutes.APPEARANCE) {
            AppearanceScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 12. Privacy & Data Management Screen
        composable(JamesRoutes.PRIVACY) {
            PrivacyScreen(
                mainViewModel = mainViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenMemory = { navController.navigate(JamesRoutes.MEMORY) },
                onOpenAccount = { navController.navigate(JamesRoutes.ACCOUNT) }
            )
        }

        // 13. Attachment Preview Screen
        composable(JamesRoutes.ATTACHMENT_PREVIEW) {
            AttachmentPreviewScreen(
                chatViewModel = chatViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 14. About JAMES Screen
        composable(JamesRoutes.ABOUT) {
            AboutScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 15. JAMES Control Center (22 Subsystem Modules)
        composable(JamesRoutes.CONTROL_CENTER) {
            ControlCenterScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() },
                onOpenProvidersRuntime = { navController.navigate(JamesRoutes.PROVIDERS_RUNTIME) },
                onOpenCouncilDashboard = { navController.navigate(JamesRoutes.COUNCIL_DASHBOARD) },
                onOpenKnowledgeLearning = { navController.navigate(JamesRoutes.KNOWLEDGE_LEARNING) },
                onOpenExtensionsHub = { navController.navigate(JamesRoutes.EXTENSIONS_HUB) },
                onOpenCloudMigration = { navController.navigate(JamesRoutes.CLOUD_MIGRATION) },
                onOpenPrivateVault = { navController.navigate(JamesRoutes.PRIVATE_VAULT) },
                onOpenDiagnosticsLogs = { navController.navigate(JamesRoutes.DIAGNOSTICS_LOGS) },
                onOpenMemory = { navController.navigate(JamesRoutes.MEMORY) },
                onOpenGeneralSettings = { navController.navigate(JamesRoutes.GENERAL_SETTINGS) },
                onOpenAbout = { navController.navigate(JamesRoutes.ABOUT) }
            )
        }

        // 16. AI Council Dashboard
        composable(JamesRoutes.COUNCIL_DASHBOARD) {
            CouncilDashboardScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 17. Open-Weight Brain & AI Providers
        composable(JamesRoutes.PROVIDERS_RUNTIME) {
            ProvidersRuntimeScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 18. Knowledge & Continuous Learning
        composable(JamesRoutes.KNOWLEDGE_LEARNING) {
            KnowledgeLearningScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 19. Skills, MCP & Connectors Hub
        composable(JamesRoutes.EXTENSIONS_HUB) {
            ExtensionsHubScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 20. Cloud Backend, Hosting, Migration & Scheduler
        composable(JamesRoutes.CLOUD_MIGRATION) {
            CloudMigrationScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 21. Isolated Private Vault
        composable(JamesRoutes.PRIVATE_VAULT) {
            PrivateVaultScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        // 22. Diagnostics, Usage Telemetry & Audit Logs
        composable(JamesRoutes.DIAGNOSTICS_LOGS) {
            DiagnosticsLogsScreen(
                ecosystemViewModel = ecosystemViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
