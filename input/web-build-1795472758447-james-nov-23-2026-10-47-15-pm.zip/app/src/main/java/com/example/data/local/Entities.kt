package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val modelName: String,
    val lastMessagePreview: String,
    val messageCount: Int,
    val pinned: Boolean,
    val contextSummary: String = "",
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("conversationId"), Index("createdAtMillis")]
)
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val role: String,
    val content: String,
    val attachmentName: String? = null,
    val attachmentMimeType: String? = null,
    val attachmentUri: String? = null,
    val attachmentSizeBytes: Long = 0L,
    val modelName: String? = null,
    val isError: Boolean = false,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val category: String,
    val content: String,
    val enabled: Boolean,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

// === Database v2 Entities for JAMES Independent AI Ecosystem ===

@Entity(tableName = "knowledge_items", indices = [Index("checksumSha256")])
data class KnowledgeEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val category: String,
    val source: String,
    val sourceType: String,
    val acquiredAtMillis: Long,
    val lastVerifiedAtMillis: Long,
    val reliabilityScore: Float,
    val confidence: Float,
    val topicsCsv: String,
    val version: Int,
    val validationStatus: String,
    val chunkCount: Int,
    val checksumSha256: String
)

@Entity(tableName = "learning_experiences")
data class LearningExperienceEntity(
    @PrimaryKey val id: String,
    val taskSummary: String,
    val outcomeType: String,
    val rootCause: String,
    val lessonLearned: String,
    val relatedSkillId: String?,
    val createdAtMillis: Long
)

@Entity(tableName = "skills")
data class SkillEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val version: String,
    val category: String,
    val sourceType: String,
    val sourceUri: String,
    val skillMarkdown: String,
    val permissionsCsv: String,
    val dependenciesCsv: String,
    val enabled: Boolean,
    val inspected: Boolean,
    val inspectionNotes: String,
    val updatedAtMillis: Long
)

@Entity(tableName = "mcp_servers")
data class McpServerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val transport: String,
    val endpointUrl: String,
    val status: String,
    val discoveredToolsSummary: String,
    val enabledToolsCsv: String,
    val requireApprovalPerCall: Boolean,
    val lastConnectedMillis: Long,
    val logsText: String
)

@Entity(tableName = "connectors")
data class ConnectorEntity(
    @PrimaryKey val id: String,
    val providerKey: String,
    val displayName: String,
    val category: String,
    val endpointOrScope: String,
    val authMode: String,
    val isSupportedOfficially: Boolean,
    val enabled: Boolean,
    val status: String,
    val notes: String,
    val lastCheckedMillis: Long
)

@Entity(tableName = "ai_providers")
data class AiProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val providerType: String,
    val runtimeType: String,
    val endpointUrl: String,
    val modelId: String,
    val enabled: Boolean,
    val isDefaultPrimary: Boolean,
    val estimatedInputCostPer1M: Double,
    val estimatedOutputCostPer1M: Double,
    val totalRequests: Int,
    val totalEstimatedTokens: Long,
    val requestLimitPerDay: Int,
    val lastStatus: String,
    val lastTestedMillis: Long
)

@Entity(tableName = "council_sessions")
data class CouncilSessionEntity(
    @PrimaryKey val id: String,
    val topic: String,
    val mode: String,
    val status: String,
    val maxRounds: Int,
    val roundsCompleted: Int,
    val participantsSummary: String,
    val transcriptMarkdown: String,
    val agreementsText: String,
    val disagreementsText: String,
    val conclusionText: String,
    val estimatedTokensUsed: Long,
    val createdAtMillis: Long
)

@Entity(tableName = "improvement_proposals")
data class ImprovementProposalEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val title: String,
    val problemDescription: String,
    val proposedSolution: String,
    val expectedBenefits: String,
    val potentialRisks: String,
    val dependenciesText: String,
    val implementationPlan: String,
    val testPlan: String,
    val rollbackPlan: String,
    val approvalStatus: String,
    val createdAtMillis: Long
)

@Entity(tableName = "private_vault_items")
data class PrivateVaultEntity(
    @PrimaryKey val id: String,
    val title: String,
    val itemType: String,
    val encryptedPayload: String,
    val updatedAtMillis: Long
)

@Entity(tableName = "scheduled_jobs")
data class ScheduledJobEntity(
    @PrimaryKey val id: String,
    val name: String,
    val taskType: String,
    val intervalHours: Int,
    val enabled: Boolean,
    val maxBudgetTokens: Int,
    val lastRunMillis: Long,
    val lastStatus: String,
    val lastSummary: String
)

@Entity(tableName = "migration_records")
data class MigrationRecordEntity(
    @PrimaryKey val id: String,
    val sourceProvider: String,
    val targetProvider: String,
    val status: String,
    val totalFiles: Int,
    val transferredFiles: Int,
    val checksumManifestSha256: String,
    val reportSummary: String,
    val sourceDeleteApproved: Boolean,
    val createdAtMillis: Long
)

@Entity(tableName = "system_logs")
data class SystemLogEntity(
    @PrimaryKey val id: String,
    val level: String,
    val component: String,
    val message: String,
    val timestampMillis: Long
)
