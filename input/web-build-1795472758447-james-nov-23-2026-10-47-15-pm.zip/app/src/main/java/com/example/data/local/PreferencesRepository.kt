package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.RoutingPolicy
import com.example.ui.theme.FontSizeScale
import com.example.ui.theme.JamesAccent
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "james_settings")

enum class AppLanguage(val code: String, val labelEn: String, val labelAr: String) {
    ENGLISH("en", "English (LTR)", "الإنجليزية (LTR)"),
    ARABIC("ar", "العربية (RTL)", "العربية (RTL)");

    companion object {
        fun fromCode(code: String): AppLanguage = entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

enum class ResponseLength(val id: String, val labelEn: String, val labelAr: String) {
    CONCISE("concise", "Concise", "مختصر"),
    BALANCED("balanced", "Balanced", "متوازن"),
    DETAILED("detailed", "Detailed", "مفصّل");

    companion object {
        fun fromId(id: String): ResponseLength = entries.firstOrNull { it.id == id } ?: BALANCED
    }
}

enum class ResponseStyle(val id: String, val labelEn: String, val labelAr: String) {
    FORMAL("formal", "Formal", "رسمي"),
    NATURAL("natural", "Natural", "طبيعي"),
    CASUAL("casual", "Casual", "ودي");

    companion object {
        fun fromId(id: String): ResponseStyle = entries.firstOrNull { it.id == id } ?: NATURAL
    }
}

data class JamesSettings(
    val onboardingCompleted: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accent: JamesAccent = JamesAccent.CYAN,
    val fontScale: FontSizeScale = FontSizeScale.DEFAULT,
    val appLanguage: AppLanguage = AppLanguage.ENGLISH,
    val preferredResponseLanguage: String = "auto",
    val responseLength: ResponseLength = ResponseLength.BALANCED,
    val responseStyle: ResponseStyle = ResponseStyle.NATURAL,
    val customInstructions: String = "",
    val selectedModel: String = "gemini-3.8-flash",
    val temperature: Float = 0.7f,
    val topP: Float = 0.95f,
    val contextTurnLimit: Int = 20,
    val autoSummarizeContext: Boolean = true,
    val memoryEnabled: Boolean = true,
    val voiceOutputEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val selectedTtsVoiceName: String = "",
    val voiceInputLanguage: String = "en-US",
    val autoSpeakInVoiceMode: Boolean = true,
    val cloudSyncEnabled: Boolean = false,
    val e2eeEnabled: Boolean = false,
    // Expanded JAMES Ecosystem settings
    val routingPolicy: RoutingPolicy = RoutingPolicy.BALANCED_HYBRID,
    val backendBaseUrl: String = "",
    val useCloudBackendWhenAvailable: Boolean = false,
    val activeStorageProviderId: String = "LOCAL_CORE",
    val allowSkillScriptExecution: Boolean = false,
    val requireMcpToolConfirmation: Boolean = true,
    val vaultAutoLockMinutes: Int = 5,
    val councilMaxRounds: Int = 2,
    val councilMaxBudgetTokens: Int = 16000
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_ID = stringPreferencesKey("accent_id")
        val FONT_SCALE = stringPreferencesKey("font_scale")
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val RESPONSE_LANGUAGE = stringPreferencesKey("response_language")
        val RESPONSE_LENGTH = stringPreferencesKey("response_length")
        val RESPONSE_STYLE = stringPreferencesKey("response_style")
        val CUSTOM_INSTRUCTIONS = stringPreferencesKey("custom_instructions")
        val SELECTED_MODEL = stringPreferencesKey("selected_model")
        val TEMPERATURE = floatPreferencesKey("temperature")
        val TOP_P = floatPreferencesKey("top_p")
        val CONTEXT_TURN_LIMIT = intPreferencesKey("context_turn_limit")
        val AUTO_SUMMARIZE_CONTEXT = booleanPreferencesKey("auto_summarize_context")
        val MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        val VOICE_OUTPUT_ENABLED = booleanPreferencesKey("voice_output_enabled")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val TTS_VOICE_NAME = stringPreferencesKey("tts_voice_name")
        val VOICE_INPUT_LANG = stringPreferencesKey("voice_input_lang")
        val AUTO_SPEAK_VOICE_MODE = booleanPreferencesKey("auto_speak_voice_mode")
        val CLOUD_SYNC_ENABLED = booleanPreferencesKey("cloud_sync_enabled")
        val E2EE_ENABLED = booleanPreferencesKey("e2ee_enabled")
        // Expanded keys
        val ROUTING_POLICY = stringPreferencesKey("routing_policy")
        val BACKEND_BASE_URL = stringPreferencesKey("backend_base_url")
        val USE_CLOUD_BACKEND = booleanPreferencesKey("use_cloud_backend")
        val ACTIVE_STORAGE_PROVIDER = stringPreferencesKey("active_storage_provider")
        val ALLOW_SKILL_SCRIPTS = booleanPreferencesKey("allow_skill_scripts")
        val REQUIRE_MCP_CONFIRM = booleanPreferencesKey("require_mcp_confirm")
        val VAULT_AUTOLOCK_MIN = intPreferencesKey("vault_autolock_min")
        val COUNCIL_MAX_ROUNDS = intPreferencesKey("council_max_rounds")
        val COUNCIL_MAX_BUDGET = intPreferencesKey("council_max_budget")
    }

    val settingsFlow: Flow<JamesSettings> = context.dataStore.data.map { prefs ->
        JamesSettings(
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            themeMode = ThemeMode.fromId(prefs[Keys.THEME_MODE] ?: ThemeMode.DARK.id),
            accent = JamesAccent.fromId(prefs[Keys.ACCENT_ID] ?: JamesAccent.CYAN.id),
            fontScale = FontSizeScale.fromId(prefs[Keys.FONT_SCALE] ?: FontSizeScale.DEFAULT.id),
            appLanguage = AppLanguage.fromCode(prefs[Keys.APP_LANGUAGE] ?: AppLanguage.ENGLISH.code),
            preferredResponseLanguage = prefs[Keys.RESPONSE_LANGUAGE] ?: "auto",
            responseLength = ResponseLength.fromId(prefs[Keys.RESPONSE_LENGTH] ?: ResponseLength.BALANCED.id),
            responseStyle = ResponseStyle.fromId(prefs[Keys.RESPONSE_STYLE] ?: ResponseStyle.NATURAL.id),
            customInstructions = prefs[Keys.CUSTOM_INSTRUCTIONS] ?: "",
            selectedModel = prefs[Keys.SELECTED_MODEL] ?: "gemini-3.8-flash",
            temperature = prefs[Keys.TEMPERATURE] ?: 0.7f,
            topP = prefs[Keys.TOP_P] ?: 0.95f,
            contextTurnLimit = prefs[Keys.CONTEXT_TURN_LIMIT] ?: 20,
            autoSummarizeContext = prefs[Keys.AUTO_SUMMARIZE_CONTEXT] ?: true,
            memoryEnabled = prefs[Keys.MEMORY_ENABLED] ?: true,
            voiceOutputEnabled = prefs[Keys.VOICE_OUTPUT_ENABLED] ?: true,
            speechRate = prefs[Keys.SPEECH_RATE] ?: 1.0f,
            selectedTtsVoiceName = prefs[Keys.TTS_VOICE_NAME] ?: "",
            voiceInputLanguage = prefs[Keys.VOICE_INPUT_LANG] ?: "en-US",
            autoSpeakInVoiceMode = prefs[Keys.AUTO_SPEAK_VOICE_MODE] ?: true,
            cloudSyncEnabled = prefs[Keys.CLOUD_SYNC_ENABLED] ?: false,
            e2eeEnabled = prefs[Keys.E2EE_ENABLED] ?: false,
            routingPolicy = RoutingPolicy.fromId(prefs[Keys.ROUTING_POLICY] ?: RoutingPolicy.BALANCED_HYBRID.id),
            backendBaseUrl = prefs[Keys.BACKEND_BASE_URL] ?: "",
            useCloudBackendWhenAvailable = prefs[Keys.USE_CLOUD_BACKEND] ?: false,
            activeStorageProviderId = prefs[Keys.ACTIVE_STORAGE_PROVIDER] ?: "LOCAL_CORE",
            allowSkillScriptExecution = prefs[Keys.ALLOW_SKILL_SCRIPTS] ?: false,
            requireMcpToolConfirmation = prefs[Keys.REQUIRE_MCP_CONFIRM] ?: true,
            vaultAutoLockMinutes = prefs[Keys.VAULT_AUTOLOCK_MIN] ?: 5,
            councilMaxRounds = prefs[Keys.COUNCIL_MAX_ROUNDS] ?: 2,
            councilMaxBudgetTokens = prefs[Keys.COUNCIL_MAX_BUDGET] ?: 16000
        )
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.id }
    }

    suspend fun setAccent(accent: JamesAccent) {
        context.dataStore.edit { it[Keys.ACCENT_ID] = accent.id }
    }

    suspend fun setFontScale(scale: FontSizeScale) {
        context.dataStore.edit { it[Keys.FONT_SCALE] = scale.id }
    }

    suspend fun setAppLanguage(language: AppLanguage) {
        context.dataStore.edit {
            it[Keys.APP_LANGUAGE] = language.code
            it[Keys.VOICE_INPUT_LANG] = if (language == AppLanguage.ARABIC) "ar-SA" else "en-US"
        }
    }

    suspend fun setPreferredResponseLanguage(lang: String) {
        context.dataStore.edit { it[Keys.RESPONSE_LANGUAGE] = lang }
    }

    suspend fun setResponseLength(length: ResponseLength) {
        context.dataStore.edit { it[Keys.RESPONSE_LENGTH] = length.id }
    }

    suspend fun setResponseStyle(style: ResponseStyle) {
        context.dataStore.edit { it[Keys.RESPONSE_STYLE] = style.id }
    }

    suspend fun setCustomInstructions(instructions: String) {
        context.dataStore.edit { it[Keys.CUSTOM_INSTRUCTIONS] = instructions }
    }

    suspend fun setSelectedModel(modelId: String) {
        context.dataStore.edit { it[Keys.SELECTED_MODEL] = modelId }
    }

    suspend fun setTemperature(temp: Float) {
        context.dataStore.edit { it[Keys.TEMPERATURE] = temp.coerceIn(0f, 2f) }
    }

    suspend fun setTopP(topP: Float) {
        context.dataStore.edit { it[Keys.TOP_P] = topP.coerceIn(0.1f, 1f) }
    }

    suspend fun setContextTurnLimit(limit: Int) {
        context.dataStore.edit { it[Keys.CONTEXT_TURN_LIMIT] = limit.coerceIn(4, 50) }
    }

    suspend fun setAutoSummarizeContext(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SUMMARIZE_CONTEXT] = enabled }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MEMORY_ENABLED] = enabled }
    }

    suspend fun setVoiceOutputEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.VOICE_OUTPUT_ENABLED] = enabled }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.dataStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.5f, 2.0f) }
    }

    suspend fun setSelectedTtsVoiceName(name: String) {
        context.dataStore.edit { it[Keys.TTS_VOICE_NAME] = name }
    }

    suspend fun setVoiceInputLanguage(langTag: String) {
        context.dataStore.edit { it[Keys.VOICE_INPUT_LANG] = langTag }
    }

    suspend fun setAutoSpeakInVoiceMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_SPEAK_VOICE_MODE] = enabled }
    }

    suspend fun setCloudSyncEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CLOUD_SYNC_ENABLED] = enabled }
    }

    suspend fun setE2eeEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.E2EE_ENABLED] = enabled }
    }

    suspend fun setRoutingPolicy(policy: RoutingPolicy) {
        context.dataStore.edit { it[Keys.ROUTING_POLICY] = policy.id }
    }

    suspend fun setBackendConfig(baseUrl: String, enabled: Boolean) {
        context.dataStore.edit {
            it[Keys.BACKEND_BASE_URL] = baseUrl.trim()
            it[Keys.USE_CLOUD_BACKEND] = enabled
        }
    }

    suspend fun setActiveStorageProviderId(providerId: String) {
        context.dataStore.edit { it[Keys.ACTIVE_STORAGE_PROVIDER] = providerId }
    }

    suspend fun setAllowSkillScriptExecution(allowed: Boolean) {
        context.dataStore.edit { it[Keys.ALLOW_SKILL_SCRIPTS] = allowed }
    }

    suspend fun setRequireMcpToolConfirmation(required: Boolean) {
        context.dataStore.edit { it[Keys.REQUIRE_MCP_CONFIRM] = required }
    }

    suspend fun setVaultAutoLockMinutes(minutes: Int) {
        context.dataStore.edit { it[Keys.VAULT_AUTOLOCK_MIN] = minutes.coerceIn(1, 60) }
    }

    suspend fun setCouncilLimits(maxRounds: Int, maxBudgetTokens: Int) {
        context.dataStore.edit {
            it[Keys.COUNCIL_MAX_ROUNDS] = maxRounds.coerceIn(1, 4)
            it[Keys.COUNCIL_MAX_BUDGET] = maxBudgetTokens.coerceIn(2000, 100000)
        }
    }
}
