package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY pinned DESC, updatedAtMillis DESC")
    fun observeAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations ORDER BY pinned DESC, updatedAtMillis DESC")
    suspend fun getAllConversationsOnce(): List<ConversationEntity>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    fun observeConversation(id: String): Flow<ConversationEntity?>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    suspend fun getConversation(id: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertConversationIgnore(conversation: ConversationEntity): Long

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    suspend fun upsertConversation(conversation: ConversationEntity) {
        if (insertConversationIgnore(conversation) == -1L) {
            updateConversation(conversation)
        }
    }

    @Query("UPDATE conversations SET title = :title, updatedAtMillis = :updatedAt WHERE id = :id")
    suspend fun renameConversation(id: String, title: String, updatedAt: Long)

    @Query("UPDATE conversations SET pinned = :pinned, updatedAtMillis = :updatedAt WHERE id = :id")
    suspend fun setPinned(id: String, pinned: Boolean, updatedAt: Long)

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun deleteConversation(id: String)

    @Query("DELETE FROM conversations")
    suspend fun deleteAllConversations()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAtMillis ASC")
    fun observeMessages(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY createdAtMillis ASC")
    suspend fun getMessagesOnce(conversationId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE id = :id LIMIT 1")
    suspend fun getMessage(id: String): MessageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMessage(message: MessageEntity)

    @Update
    suspend fun updateMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteMessage(id: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId AND createdAtMillis > :afterMillis")
    suspend fun deleteMessagesAfter(conversationId: String, afterMillis: Long)
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY updatedAtMillis DESC")
    fun observeMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE enabled = 1 ORDER BY updatedAtMillis DESC")
    suspend fun getEnabledMemoriesOnce(): List<MemoryEntity>

    @Query("SELECT * FROM memories ORDER BY updatedAtMillis DESC")
    suspend fun getAllMemoriesOnce(): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMemory(memory: MemoryEntity)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemory(id: String)

    @Query("DELETE FROM memories")
    suspend fun deleteAllMemories()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC")
    fun observeNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC")
    suspend fun getAllNotesOnce(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNote(id: String)

    @Query("DELETE FROM notes")
    suspend fun deleteAllNotes()
}

@Dao
interface EcosystemDao {
    // Knowledge
    @Query("SELECT * FROM knowledge_items ORDER BY lastVerifiedAtMillis DESC")
    fun observeKnowledge(): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge_items ORDER BY lastVerifiedAtMillis DESC")
    suspend fun getKnowledgeOnce(): List<KnowledgeEntity>

    @Query("SELECT * FROM knowledge_items WHERE checksumSha256 = :checksum LIMIT 1")
    suspend fun findKnowledgeByChecksum(checksum: String): KnowledgeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertKnowledge(item: KnowledgeEntity)

    @Query("DELETE FROM knowledge_items WHERE id = :id")
    suspend fun deleteKnowledge(id: String)

    // Experiences
    @Query("SELECT * FROM learning_experiences ORDER BY createdAtMillis DESC")
    fun observeExperiences(): Flow<List<LearningExperienceEntity>>

    @Query("SELECT * FROM learning_experiences ORDER BY createdAtMillis DESC")
    suspend fun getExperiencesOnce(): List<LearningExperienceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExperience(exp: LearningExperienceEntity)

    // Skills
    @Query("SELECT * FROM skills ORDER BY updatedAtMillis DESC")
    fun observeSkills(): Flow<List<SkillEntity>>

    @Query("SELECT * FROM skills WHERE enabled = 1 ORDER BY updatedAtMillis DESC")
    suspend fun getEnabledSkillsOnce(): List<SkillEntity>

    @Query("SELECT * FROM skills ORDER BY updatedAtMillis DESC")
    suspend fun getAllSkillsOnce(): List<SkillEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSkill(skill: SkillEntity)

    @Query("DELETE FROM skills WHERE id = :id")
    suspend fun deleteSkill(id: String)

    // MCP Servers
    @Query("SELECT * FROM mcp_servers ORDER BY lastConnectedMillis DESC")
    fun observeMcpServers(): Flow<List<McpServerEntity>>

    @Query("SELECT * FROM mcp_servers ORDER BY lastConnectedMillis DESC")
    suspend fun getMcpServersOnce(): List<McpServerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMcpServer(server: McpServerEntity)

    @Query("DELETE FROM mcp_servers WHERE id = :id")
    suspend fun deleteMcpServer(id: String)

    // Connectors
    @Query("SELECT * FROM connectors ORDER BY displayName ASC")
    fun observeConnectors(): Flow<List<ConnectorEntity>>

    @Query("SELECT * FROM connectors")
    suspend fun getConnectorsOnce(): List<ConnectorEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConnector(connector: ConnectorEntity)

    // AI Providers
    @Query("SELECT * FROM ai_providers ORDER BY isDefaultPrimary DESC, name ASC")
    fun observeProviders(): Flow<List<AiProviderEntity>>

    @Query("SELECT * FROM ai_providers ORDER BY isDefaultPrimary DESC, name ASC")
    suspend fun getProvidersOnce(): List<AiProviderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProvider(provider: AiProviderEntity)

    @Query("UPDATE ai_providers SET isDefaultPrimary = 0")
    suspend fun clearDefaultPrimaryProviders()

    @Query("DELETE FROM ai_providers WHERE id = :id")
    suspend fun deleteProvider(id: String)

    // Council Sessions & Proposals
    @Query("SELECT * FROM council_sessions ORDER BY createdAtMillis DESC")
    fun observeCouncilSessions(): Flow<List<CouncilSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCouncilSession(session: CouncilSessionEntity)

    @Query("SELECT * FROM improvement_proposals ORDER BY createdAtMillis DESC")
    fun observeProposals(): Flow<List<ImprovementProposalEntity>>

    @Query("SELECT * FROM improvement_proposals ORDER BY createdAtMillis DESC")
    suspend fun getProposalsOnce(): List<ImprovementProposalEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProposal(proposal: ImprovementProposalEntity)

    // Private Vault
    @Query("SELECT * FROM private_vault_items ORDER BY updatedAtMillis DESC")
    fun observeVaultItems(): Flow<List<PrivateVaultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertVaultItem(item: PrivateVaultEntity)

    @Query("DELETE FROM private_vault_items WHERE id = :id")
    suspend fun deleteVaultItem(id: String)

    @Query("DELETE FROM private_vault_items")
    suspend fun clearVaultItems()

    // Scheduled Jobs
    @Query("SELECT * FROM scheduled_jobs ORDER BY name ASC")
    fun observeJobs(): Flow<List<ScheduledJobEntity>>

    @Query("SELECT * FROM scheduled_jobs")
    suspend fun getJobsOnce(): List<ScheduledJobEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJob(job: ScheduledJobEntity)

    // Migration Records
    @Query("SELECT * FROM migration_records ORDER BY createdAtMillis DESC")
    fun observeMigrations(): Flow<List<MigrationRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMigration(record: MigrationRecordEntity)

    // System Logs
    @Query("SELECT * FROM system_logs ORDER BY timestampMillis DESC LIMIT 200")
    fun observeLogs(): Flow<List<SystemLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: SystemLogEntity)

    @Query("DELETE FROM system_logs")
    suspend fun clearLogs()
}
