package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.GeminiModelCatalog
import com.example.data.model.AttachmentType
import com.example.data.model.Conversation
import com.example.ui.components.ChatMessageBubble
import com.example.ui.components.JamesLogoMark
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.GenerationStatus
import com.example.ui.viewmodel.MainAppViewModel
import com.example.util.AttachmentProcessor
import com.example.util.VoiceInputState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeChatScreen(
    chatViewModel: ChatViewModel,
    mainViewModel: MainAppViewModel,
    conversationIdArg: String?,
    onOpenVoiceMode: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenAccount: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAiSettings: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenAttachmentPreview: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenControlCenter: () -> Unit = {},
    onOpenCouncil: () -> Unit = {},
    onOpenPrivateVault: () -> Unit = {}
) {
    val strings = LocalJamesStrings.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val conversations by mainViewModel.conversations.collectAsStateWithLifecycle()
    val isOnline by mainViewModel.isOnline.collectAsStateWithLifecycle()
    val currentUser by mainViewModel.currentUser.collectAsStateWithLifecycle()

    LaunchedEffect(conversationIdArg) {
        if (!conversationIdArg.isNullOrBlank()) {
            chatViewModel.openConversation(conversationIdArg)
        }
    }

    var drawerSearch by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<Conversation?>(null) }
    var renameInput by remember { mutableStateOf("") }

    val filteredConversations = remember(conversations, drawerSearch) {
        if (drawerSearch.isBlank()) conversations
        else conversations.filter {
            it.title.contains(drawerSearch, ignoreCase = true) ||
                it.lastMessagePreview.contains(drawerSearch, ignoreCase = true)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.widthIn(max = 330.dp).fillMaxHeight(),
                drawerContainerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                ) {
                    // JAMES Identity Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                scope.launch { drawerState.close() }
                                onOpenAccount()
                            }
                            .padding(12.dp)
                            .testTag("drawer_profile_card")
                    ) {
                        JamesLogoMark(size = 38.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "JAMES",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = currentUser?.displayName
                                    ?: currentUser?.email
                                    ?: strings.signedOutLocalMode,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.Outlined.AccountCircle,
                            contentDescription = strings.accountAndSync,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // New Conversation CTA
                    Surface(
                        onClick = {
                            chatViewModel.startNewConversation()
                            scope.launch { drawerState.close() }
                        },
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("drawer_new_chat_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Add,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = strings.newConversation,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = drawerSearch,
                        onValueChange = { drawerSearch = it },
                        placeholder = { Text(strings.searchConversations, style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("drawer_search_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = strings.recentConversations,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val activeId by chatViewModel.activeConversationId.collectAsStateWithLifecycle()

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredConversations, key = { it.id }) { conv ->
                            var showMenu by remember { mutableStateOf(false) }
                            val selected = conv.id == activeId
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                                        else MaterialTheme.colorScheme.surface
                                    )
                                    .clickable {
                                        chatViewModel.openConversation(conv.id)
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                if (conv.pinned) {
                                    Icon(
                                        imageVector = Icons.Outlined.PushPin,
                                        contentDescription = "Pinned",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(15.dp).padding(end = 4.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = conv.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                        ),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (conv.lastMessagePreview.isNotBlank()) {
                                        Text(
                                            text = conv.lastMessagePreview,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Box {
                                    IconButton(
                                        onClick = { showMenu = true },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.MoreVert,
                                            contentDescription = "Options",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showMenu,
                                        onDismissRequest = { showMenu = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text(if (conv.pinned) strings.unpin else strings.pin) },
                                            leadingIcon = { Icon(Icons.Outlined.PushPin, null) },
                                            onClick = {
                                                showMenu = false
                                                mainViewModel.togglePinConversation(conv.id)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(strings.rename) },
                                            leadingIcon = { Icon(Icons.Outlined.Edit, null) },
                                            onClick = {
                                                showMenu = false
                                                renameTarget = conv
                                                renameInput = conv.title
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(strings.delete, color = MaterialTheme.colorScheme.error) },
                                            leadingIcon = { Icon(Icons.Outlined.Delete, null, tint = MaterialTheme.colorScheme.error) },
                                            onClick = {
                                                showMenu = false
                                                if (activeId == conv.id) chatViewModel.startNewConversation()
                                                mainViewModel.deleteConversation(conv.id)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    NavigationDrawerItem(
                        label = { Text(strings.controlCenter) },
                        icon = { Icon(Icons.Outlined.Hub, null, tint = MaterialTheme.colorScheme.primary) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenControlCenter()
                        },
                        modifier = Modifier.testTag("drawer_control_center_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.aiCouncil) },
                        icon = { Icon(Icons.Outlined.Forum, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenCouncil()
                        },
                        modifier = Modifier.testTag("drawer_council_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.privateVault) },
                        icon = { Icon(Icons.Outlined.Lock, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenPrivateVault()
                        },
                        modifier = Modifier.testTag("drawer_private_vault_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.conversationHistory) },
                        icon = { Icon(Icons.Outlined.History, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenHistory()
                        },
                        modifier = Modifier.testTag("drawer_history_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.memoryManagement) },
                        icon = { Icon(Icons.Outlined.Psychology, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenMemory()
                        },
                        modifier = Modifier.testTag("drawer_memory_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.privacyAndData) },
                        icon = { Icon(Icons.Outlined.Shield, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenPrivacy()
                        },
                        modifier = Modifier.testTag("drawer_privacy_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.generalSettings) },
                        icon = { Icon(Icons.Outlined.Settings, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenSettings()
                        },
                        modifier = Modifier.testTag("drawer_settings_item")
                    )
                    NavigationDrawerItem(
                        label = { Text(strings.aboutJames) },
                        icon = { Icon(Icons.Outlined.Info, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenAbout()
                        },
                        modifier = Modifier.testTag("drawer_about_item")
                    )
                }
            }
        }
    ) {
        ChatWorkspaceContent(
            chatViewModel = chatViewModel,
            mainViewModel = mainViewModel,
            isOnline = isOnline,
            selectedModelId = settings.selectedModel,
            voiceInputLanguage = settings.voiceInputLanguage,
            onOpenDrawer = { scope.launch { drawerState.open() } },
            onOpenVoiceMode = onOpenVoiceMode,
            onOpenAiSettings = onOpenAiSettings,
            onOpenAttachmentPreview = onOpenAttachmentPreview
        )
    }

    renameTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(strings.renameConversation) },
            text = {
                OutlinedTextField(
                    value = renameInput,
                    onValueChange = { renameInput = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        mainViewModel.renameConversation(target.id, renameInput)
                        renameTarget = null
                    }
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text(strings.cancel) }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatWorkspaceContent(
    chatViewModel: ChatViewModel,
    mainViewModel: MainAppViewModel,
    isOnline: Boolean,
    selectedModelId: String,
    voiceInputLanguage: String,
    onOpenDrawer: (() -> Unit)?,
    onNavigateBack: (() -> Unit)? = null,
    onOpenVoiceMode: () -> Unit,
    onOpenAiSettings: () -> Unit,
    onOpenAttachmentPreview: () -> Unit
) {
    val context = LocalContext.current
    val strings = LocalJamesStrings.current
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val activeConversation by chatViewModel.activeConversation.collectAsStateWithLifecycle()
    val messages by chatViewModel.messages.collectAsStateWithLifecycle()
    val streamingMessage by chatViewModel.streamingMessage.collectAsStateWithLifecycle()
    val generationStatus by chatViewModel.generationStatus.collectAsStateWithLifecycle()
    val composerText by chatViewModel.composerText.collectAsStateWithLifecycle()
    val pendingAttachment by chatViewModel.pendingAttachment.collectAsStateWithLifecycle()
    val isProcessingAttachment by chatViewModel.isProcessingAttachment.collectAsStateWithLifecycle()
    val attachmentError by chatViewModel.attachmentError.collectAsStateWithLifecycle()
    val editingMessage by chatViewModel.editingMessage.collectAsStateWithLifecycle()

    val ttsState by mainViewModel.voiceOutputManager.playbackState.collectAsStateWithLifecycle()
    val activeTtsId by mainViewModel.voiceOutputManager.activeMessageId.collectAsStateWithLifecycle()
    val voiceInputState by mainViewModel.voiceInputManager.state.collectAsStateWithLifecycle()
    val partialVoiceText by mainViewModel.voiceInputManager.partialText.collectAsStateWithLifecycle()

    var showAttachSheetMenu by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            chatViewModel.processAttachment(context, uri)
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            chatViewModel.processAttachment(context, uri)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            mainViewModel.voiceInputManager.startListening(voiceInputLanguage)
        }
    }

    // Apply recognized voice transcript into composer for user review before sending
    LaunchedEffect(voiceInputState) {
        if (voiceInputState is VoiceInputState.Result) {
            val recognized = (voiceInputState as VoiceInputState.Result).text
            val current = composerText.trim()
            chatViewModel.updateComposerText(
                if (current.isEmpty()) recognized else "$current $recognized"
            )
            mainViewModel.voiceInputManager.resetState()
        }
    }

    val combinedMessages = remember(messages, streamingMessage) {
        val stream = streamingMessage
        if (stream != null) messages + stream else messages
    }
    val lastAssistantId = remember(messages) {
        messages.lastOrNull { it.role == "assistant" && !it.isError }?.id
    }

    val listState = rememberLazyListState()
    LaunchedEffect(combinedMessages.size, streamingMessage?.content?.length) {
        if (combinedMessages.isNotEmpty()) {
            listState.animateScrollToItem(combinedMessages.lastIndex)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            CenterAlignedTopAppBar(
                navigationIcon = {
                    if (onOpenDrawer != null) {
                        IconButton(
                            onClick = onOpenDrawer,
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(Icons.Rounded.Menu, contentDescription = "Open menu")
                        }
                    } else if (onNavigateBack != null) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close")
                        }
                    }
                },
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = activeConversation?.title ?: "JAMES",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.clickable { onOpenAiSettings() }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isOnline) StatusSuccess else StatusWarning)
                            )
                            Text(
                                text = "${GeminiModelCatalog.resolveValidModel(selectedModelId).displayName} · ${if (isOnline) strings.onlineLabel else strings.offlineLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = onOpenVoiceMode,
                        modifier = Modifier.testTag("top_voice_mode_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = strings.voiceModeTitle,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { chatViewModel.startNewConversation() },
                        modifier = Modifier.testTag("top_new_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = strings.newConversation
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Honest Offline Banner
            if (!isOnline) {
                Surface(
                    color = StatusWarning.copy(alpha = 0.14f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.WifiOff,
                            contentDescription = null,
                            tint = StatusWarning,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = strings.offlineBannerTitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = StatusWarning
                            )
                            Text(
                                text = strings.offlineBannerBody,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Messages or Empty Welcome State
            Box(
                modifier = Modifier
                    .weight(1f)
                    .widthIn(max = 720.dp)
                    .fillMaxWidth()
            ) {
                if (combinedMessages.isEmpty()) {
                    EmptyChatWelcome(
                        onSelectStarter = { prompt ->
                            chatViewModel.updateComposerText(prompt)
                            chatViewModel.sendCurrentMessage()
                        },
                        onOpenVoiceMode = onOpenVoiceMode
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize().testTag("chat_message_list")
                    ) {
                        items(combinedMessages, key = { it.id }) { msg ->
                            ChatMessageBubble(
                                message = msg,
                                isLastAssistantMessage = msg.id == lastAssistantId,
                                ttsState = ttsState,
                                activeTtsMessageId = activeTtsId,
                                onCopy = {},
                                onEdit = { chatViewModel.beginEditMessage(it) },
                                onRegenerate = { chatViewModel.regenerateLastResponse(it) },
                                onDelete = { chatViewModel.deleteMessage(it) },
                                onSaveMemory = { chatViewModel.saveMessageAsMemory(it) },
                                onSpeak = {
                                    mainViewModel.voiceOutputManager.speak(
                                        text = it.content,
                                        messageId = it.id,
                                        speechRate = settings.speechRate,
                                        voiceName = settings.selectedTtsVoiceName,
                                        preferredLanguage = settings.preferredResponseLanguage
                                    )
                                },
                                onPauseSpeech = { mainViewModel.voiceOutputManager.pause() },
                                onResumeSpeech = { mainViewModel.voiceOutputManager.resume() },
                                onStopSpeech = { mainViewModel.voiceOutputManager.stop() }
                            )
                        }
                    }
                }
            }

            // Generation Status / Error / Stop Bar
            if (generationStatus is GenerationStatus.Generating) {
                Surface(
                    onClick = { chatViewModel.stopGeneration() },
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .testTag("stop_generation_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Stop,
                            contentDescription = strings.stopGenerating,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${strings.generating} · ${strings.stopGenerating}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            } else if (generationStatus is GenerationStatus.Error) {
                val errText = (generationStatus as GenerationStatus.Error).message
                Surface(
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = errText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { chatViewModel.dismissGenerationError() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Attachment Error Banner
            attachmentError?.let { err ->
                Surface(
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { chatViewModel.clearAttachmentError() },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Editing indicator
            editingMessage?.let {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (strings.isArabic) "تعديل الرسالة وإعادة الإرسال" else "Editing message — send to re-run from here",
                            style = MaterialTheme.typography.labelMedium
                        )
                        IconButton(
                            onClick = { chatViewModel.cancelEditMessage() },
                            modifier = Modifier.size(26.dp)
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = strings.cancel, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Pending Attachment Chip + Preview Trigger
            if (isProcessingAttachment) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (strings.isArabic) "جاري معالجة الملف..." else "Processing attachment...",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                pendingAttachment?.let { att ->
                    Surface(
                        onClick = onOpenAttachmentPreview,
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .widthIn(max = 720.dp)
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                            .testTag("pending_attachment_card")
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (att.previewBitmap != null) {
                                Image(
                                    bitmap = att.previewBitmap.asImageBitmap(),
                                    contentDescription = att.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Description,
                                    contentDescription = att.name,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(36.dp).padding(6.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = att.name,
                                    style = MaterialTheme.typography.labelLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${att.type.name} · ${AttachmentProcessor.formatFileSize(att.sizeBytes)} · Tap to preview",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = { chatViewModel.removePendingAttachment() },
                                modifier = Modifier.testTag("remove_attachment_button")
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = strings.removeAttachment)
                            }
                        }
                    }
                }
            }

            // Voice live partial preview
            if (voiceInputState is VoiceInputState.Listening) {
                Surface(
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = partialVoiceText.ifBlank { strings.listening },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { mainViewModel.voiceInputManager.stopListening() }) {
                            Text(strings.stopSpeech)
                        }
                    }
                }
            }

            // Message Composer
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                tonalElevation = 3.dp,
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant,
                        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Box {
                        IconButton(
                            onClick = { showAttachSheetMenu = true },
                            modifier = Modifier.testTag("attach_file_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AttachFile,
                                contentDescription = "Attach file"
                            )
                        }
                        DropdownMenu(
                            expanded = showAttachSheetMenu,
                            onDismissRequest = { showAttachSheetMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (strings.isArabic) "صورة (معرض الصور)" else "Image (Photo Picker)") },
                                leadingIcon = { Icon(Icons.Rounded.Image, null) },
                                onClick = {
                                    showAttachSheetMenu = false
                                    imagePickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (strings.isArabic) "مستند PDF أو نص/كود" else "PDF or Text / Code Document") },
                                leadingIcon = { Icon(Icons.Rounded.Description, null) },
                                onClick = {
                                    showAttachSheetMenu = false
                                    documentPickerLauncher.launch(
                                        arrayOf("application/pdf", "text/*", "application/json")
                                    )
                                }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = composerText,
                        onValueChange = { chatViewModel.updateComposerText(it) },
                        placeholder = { Text(strings.messagePlaceholder) },
                        maxLines = 5,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("message_composer_input")
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    // Voice Input Button
                    IconButton(
                        onClick = {
                            if (voiceInputState is VoiceInputState.Listening) {
                                mainViewModel.voiceInputManager.stopListening()
                            } else {
                                val hasMic = ContextCompat.checkSelfPermission(
                                    context,
                                    Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (hasMic) {
                                    mainViewModel.voiceInputManager.startListening(voiceInputLanguage)
                                } else {
                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            }
                        },
                        modifier = Modifier.testTag("voice_input_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = strings.tapMicToSpeak,
                            tint = if (voiceInputState is VoiceInputState.Listening) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }

                    // Send Button
                    val canSend = (composerText.isNotBlank() || pendingAttachment != null) &&
                        generationStatus !is GenerationStatus.Generating
                    Surface(
                        onClick = { if (canSend) chatViewModel.sendCurrentMessage() },
                        enabled = canSend,
                        shape = CircleShape,
                        color = if (canSend) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(48.dp).testTag("send_message_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.Send,
                                contentDescription = "Send",
                                tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChatWelcome(
    onSelectStarter: (String) -> Unit,
    onOpenVoiceMode: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val starters = remember(strings.isArabic) {
        if (strings.isArabic) {
            listOf(
                "لخّص أهم أولوياتي اليومية في جدول منظم",
                "اكتب دالة Kotlin آمنة مع معالجة الأخطاء",
                "ساعدني في صياغة رسالة بريد إلكتروني احترافية"
            )
        } else {
            listOf(
                "Create a structured weekly deep-work schedule table",
                "Write a clean Kotlin Flow repository example with error handling",
                "Help me analyze pros and cons of an architecture decision"
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        JamesLogoMark(size = 72.dp, animated = true)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "JAMES",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = strings.startPromptHint,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(22.dp))
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.widthIn(max = 460.dp).fillMaxWidth()
        ) {
            starters.forEachIndexed { idx, prompt ->
                Surface(
                    onClick = { onSelectStarter(prompt) },
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                        .testTag("starter_prompt_$idx")
                ) {
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                    )
                }
            }
            AssistChip(
                onClick = onOpenVoiceMode,
                leadingIcon = { Icon(Icons.Rounded.GraphicEq, contentDescription = null) },
                label = { Text(strings.voiceModeTitle) },
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp)
            )
        }
    }
}

@Composable
fun IndividualConversationScreen(
    conversationId: String,
    chatViewModel: ChatViewModel,
    mainViewModel: MainAppViewModel,
    onNavigateBack: () -> Unit,
    onOpenVoiceMode: () -> Unit,
    onOpenAiSettings: () -> Unit,
    onOpenAttachmentPreview: () -> Unit
) {
    val isOnline by mainViewModel.isOnline.collectAsStateWithLifecycle()
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()

    LaunchedEffect(conversationId) {
        chatViewModel.openConversation(conversationId)
    }

    ChatWorkspaceContent(
        chatViewModel = chatViewModel,
        mainViewModel = mainViewModel,
        isOnline = isOnline,
        selectedModelId = settings.selectedModel,
        voiceInputLanguage = settings.voiceInputLanguage,
        onOpenDrawer = null,
        onNavigateBack = onNavigateBack,
        onOpenVoiceMode = onOpenVoiceMode,
        onOpenAiSettings = onOpenAiSettings,
        onOpenAttachmentPreview = onOpenAttachmentPreview
    )
}
