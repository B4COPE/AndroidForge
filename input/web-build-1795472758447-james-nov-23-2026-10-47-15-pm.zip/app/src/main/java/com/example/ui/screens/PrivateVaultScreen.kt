package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.VaultItemType
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusSuccess
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PrivateVaultScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val strings = LocalJamesStrings.current

    val pinConfigured by ecosystemViewModel.vaultPinConfigured.collectAsStateWithLifecycle()
    val unlocked by ecosystemViewModel.vaultUnlocked.collectAsStateWithLifecycle()
    val vaultItems by ecosystemViewModel.privateVaultItems.collectAsStateWithLifecycle()
    val settings by ecosystemViewModel.settings.collectAsStateWithLifecycle()
    val banner by ecosystemViewModel.statusBanner.collectAsStateWithLifecycle()

    var pinInput by remember { mutableStateOf("") }
    var itemTitle by remember { mutableStateOf("") }
    var itemContent by remember { mutableStateOf("") }
    var itemType by remember { mutableStateOf(VaultItemType.NOTE) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.privateVault) },
                actions = {
                    if (unlocked) {
                        IconButton(onClick = { ecosystemViewModel.lockVault() }) {
                            Icon(Icons.Outlined.Lock, contentDescription = "Lock Vault")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 700.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("private_vault_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                banner?.let { msg ->
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { ecosystemViewModel.dismissBanner() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // Isolation & Security Policy Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = if (unlocked) Icons.Outlined.LockOpen else Icons.Outlined.Lock,
                                contentDescription = null,
                                tint = if (unlocked) StatusSuccess else MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = if (unlocked) "Private Vault Unlocked" else "Private Vault Locked & Isolated",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Text(
                            text = "Protected by dedicated Android Keystore AES-256-GCM key + PBKDF2-HMAC-SHA256 PIN/Biometrics. Items stored here are strictly isolated from standard chat history, learning cycles, and cloud uploads.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(1, 5, 15, 30).forEach { mins ->
                                FilterChip(
                                    selected = settings.vaultAutoLockMinutes == mins,
                                    onClick = { ecosystemViewModel.setVaultAutoLockMinutes(mins) },
                                    label = { Text("Auto-lock ${mins}m") }
                                )
                            }
                        }
                    }
                }

                if (!unlocked) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = if (pinConfigured) "Enter Vault PIN or Use Biometrics" else "Create Your Private Vault PIN (Min 4 chars)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            OutlinedTextField(
                                value = pinInput,
                                onValueChange = { pinInput = it },
                                label = { Text("Vault PIN") },
                                visualTransformation = PasswordVisualTransformation(),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("vault_pin_input")
                            )
                            Button(
                                onClick = {
                                    if (pinConfigured) ecosystemViewModel.unlockVaultWithPin(pinInput)
                                    else ecosystemViewModel.setupVaultPin(pinInput)
                                    pinInput = ""
                                },
                                modifier = Modifier.fillMaxWidth().testTag("vault_pin_submit")
                            ) {
                                Text(if (pinConfigured) "Unlock Private Vault" else "Set PIN & Initialize Vault")
                            }
                            if (pinConfigured && activity != null) {
                                OutlinedButton(
                                    onClick = { ecosystemViewModel.unlockVaultWithBiometrics(activity) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Outlined.Fingerprint, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Unlock with Fingerprint / Biometrics")
                                }
                            }
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Store Isolated Private Item", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                VaultItemType.entries.forEach { t ->
                                    FilterChip(selected = itemType == t, onClick = { itemType = t }, label = { Text(t.labelEn) })
                                }
                            }
                            OutlinedTextField(value = itemTitle, onValueChange = { itemTitle = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = itemContent, onValueChange = { itemContent = it }, label = { Text("Encrypted Content") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                            Button(
                                onClick = {
                                    ecosystemViewModel.addVaultItem(itemTitle, itemType, itemContent)
                                    itemTitle = ""
                                    itemContent = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Encrypt & Store in Private Vault")
                            }
                        }
                    }

                    Text("Vault Records (${vaultItems.size})", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    vaultItems.forEach { item ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("[${item.itemType.id}] ${item.title}", style = MaterialTheme.typography.titleSmall)
                                    Text(item.decryptedContent, style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton(onClick = { ecosystemViewModel.deleteVaultItem(item.id) }) {
                                    Icon(Icons.Outlined.Delete, contentDescription = "Delete")
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
