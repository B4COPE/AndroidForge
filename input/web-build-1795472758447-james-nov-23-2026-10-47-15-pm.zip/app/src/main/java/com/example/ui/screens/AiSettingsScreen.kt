package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ai.GeminiModelCatalog
import com.example.data.local.ResponseLength
import com.example.data.local.ResponseStyle
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.MainAppViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AiSettingsScreen(
    mainViewModel: MainAppViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    var instructionsDraft by remember(settings.customInstructions) {
        mutableStateOf(settings.customInstructions)
    }
    var savedToast by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.aiSettings) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Model Selection
                Text(
                    text = strings.modelSelection,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    GeminiModelCatalog.models.forEach { model ->
                        val selected = settings.selectedModel == model.id
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                            else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { mainViewModel.setSelectedModel(model.id) }
                                .testTag("model_option_${model.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selected,
                                    onClick = { mainViewModel.setSelectedModel(model.id) }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = model.displayName,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = if (strings.isArabic) model.tierLabelAr else model.tierLabelEn,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (model.requiresBillingNote) StatusWarning else MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (strings.isArabic) model.descriptionAr else model.descriptionEn,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                // Generation Parameters
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.generationParams, style = MaterialTheme.typography.titleSmall)

                        Text(
                            text = "Temperature: ${String.format("%.2f", settings.temperature)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = settings.temperature,
                            onValueChange = { mainViewModel.setTemperature(it) },
                            valueRange = 0.0f..1.5f
                        )

                        Text(
                            text = "Top-P: ${String.format("%.2f", settings.topP)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = settings.topP,
                            onValueChange = { mainViewModel.setTopP(it) },
                            valueRange = 0.1f..1.0f
                        )
                    }
                }

                // Context Management
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(strings.contextManagement, style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "Active Window Turns: ${settings.contextTurnLimit} messages",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Slider(
                            value = settings.contextTurnLimit.toFloat(),
                            onValueChange = { mainViewModel.setContextTurnLimit(it.toInt()) },
                            valueRange = 4f..48f
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Summarize Older Turns", style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "Compresses overflow history to avoid sending full huge threads.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = settings.autoSummarizeContext,
                                onCheckedChange = { mainViewModel.setAutoSummarizeContext(it) }
                            )
                        }
                    }
                }

                // Assistant Behavior
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(strings.responseLength, style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ResponseLength.entries.forEach { len ->
                                FilterChip(
                                    selected = settings.responseLength == len,
                                    onClick = { mainViewModel.setResponseLength(len) },
                                    label = { Text(if (strings.isArabic) len.labelAr else len.labelEn) }
                                )
                            }
                        }

                        Text(strings.responseStyle, style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ResponseStyle.entries.forEach { st ->
                                FilterChip(
                                    selected = settings.responseStyle == st,
                                    onClick = { mainViewModel.setResponseStyle(st) },
                                    label = { Text(if (strings.isArabic) st.labelAr else st.labelEn) }
                                )
                            }
                        }

                        Text("Preferred AI Response Language", style = MaterialTheme.typography.titleSmall)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("auto" to "Auto-match", "en" to "English", "ar" to "العربية").forEach { (id, label) ->
                                FilterChip(
                                    selected = settings.preferredResponseLanguage == id,
                                    onClick = { mainViewModel.setPreferredResponseLanguage(id) },
                                    label = { Text(label) }
                                )
                            }
                        }

                        Text(strings.customInstructions, style = MaterialTheme.typography.titleSmall)
                        OutlinedTextField(
                            value = instructionsDraft,
                            onValueChange = {
                                instructionsDraft = it
                                savedToast = false
                            },
                            placeholder = { Text("Example: Always format financial comparisons as tables...") },
                            minLines = 3,
                            maxLines = 6,
                            modifier = Modifier.fillMaxWidth().testTag("custom_instructions_input")
                        )
                        Button(
                            onClick = {
                                mainViewModel.setCustomInstructions(instructionsDraft)
                                savedToast = true
                            },
                            modifier = Modifier.align(Alignment.End).testTag("save_instructions_button")
                        ) {
                            Text(if (savedToast) "Saved ✓" else strings.save)
                        }
                    }
                }
            }
        }
    }
}
