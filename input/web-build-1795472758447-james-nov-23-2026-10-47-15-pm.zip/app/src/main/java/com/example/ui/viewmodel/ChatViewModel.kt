package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiAiService
import com.example.data.core.JamesCoreOrchestrator
import com.example.data.local.JamesSettings
import com.example.data.local.PreferencesRepository
import com.example.data.model.ChatMessage
import com.example.data.model.MemoryCategory
import com.example.data.model.PendingAttachment
import com.example.data.model.RoutingPolicy
import com.example.data.repository.JamesRepository
import com.example.util.AttachmentProcessor
import com.example.util.NetworkMonitor
import com.example.util.VoiceOutputManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface GenerationStatus {
    data object Idle : GenerationStatus
    data object Generating : GenerationStatus
    data class Error(val message: String) : GenerationStatus
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(
    private val repository: JamesRepository,
    private val aiService: GeminiAiService,
    private val preferencesRepository: PreferencesRepository,
    private val networkMonitor: NetworkMonitor,
    private val voiceOutputManager: VoiceOutputManager,
    private val jamesCoreOrchestrator: JamesCoreOrchestrator? = null
) : ViewModel() {

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    val activeConversation = _activeConversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.observeConversation(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val messages: StateFlow<List<ChatMessage>> = _activeConversationId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.observeMessages(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _streamingMessage = MutableStateFlow<ChatMessage?>(null)
    val streamingMessage: StateFlow<ChatMessage?> = _streamingMessage.asStateFlow()

    private val _generationStatus = MutableStateFlow<GenerationStatus>(GenerationStatus.Idle)
    val generationStatus: StateFlow<GenerationStatus> = _generationStatus.asStateFlow()

    private val _composerText = MutableStateFlow("")
    val composerText: StateFlow<String> = _composerText.asStateFlow()

    private val _pendingAttachment = MutableStateFlow<PendingAttachment?>(null)
    val pendingAttachment: StateFlow<PendingAttachment?> = _pendingAttachment.asStateFlow()

    private val _isProcessingAttachment = MutableStateFlow(false)
    val isProcessingAttachment: StateFlow<Boolean> = _isProcessingAttachment.asStateFlow()

    private val _attachmentError = MutableStateFlow<String?>(null)
    val attachmentError: StateFlow<String?> = _attachmentError.asStateFlow()

    private val _editingMessage = MutableStateFlow<ChatMessage?>(null)
    val editingMessage: StateFlow<ChatMessage?> = _editingMessage.asStateFlow()

    private var activeGenerationJob: Job? = null

    fun openConversation(conversationId: String) {
        if (_activeConversationId.value != conversationId) {
            stopGeneration()
            _activeConversationId.value = conversationId
            _generationStatus.value = GenerationStatus.Idle
        }
    }

    fun startNewConversation() {
        stopGeneration()
        _activeConversationId.value = null
        _composerText.value = ""
        _pendingAttachment.value = null
        _editingMessage.value = null
        _generationStatus.value = GenerationStatus.Idle
    }

    fun updateComposerText(text: String) {
        _composerText.value = text
    }

    fun clearAttachmentError() {
        _attachmentError.value = null
    }

    fun dismissGenerationError() {
        _generationStatus.value = GenerationStatus.Idle
    }

    fun removePendingAttachment() {
        _pendingAttachment.value = null
    }

    fun processAttachment(context: Context, uri: Uri) {
        viewModelScope.launch {
            _isProcessingAttachment.value = true
            _attachmentError.value = null
            val result = AttachmentProcessor.processUri(context, uri)
            result.onSuccess { processed ->
                _pendingAttachment.value = processed
            }.onFailure { err ->
                _attachmentError.value = err.localizedMessage ?: "Failed to load attachment."
            }
            _isProcessingAttachment.value = false
        }
    }

    fun beginEditMessage(message: ChatMessage) {
        _editingMessage.value = message
        _composerText.value = message.content
    }

    fun cancelEditMessage() {
        _editingMessage.value = null
        _composerText.value = ""
    }

    fun sendCurrentMessage(speakResponseOnComplete: Boolean = false) {
        val text = _composerText.value.trim()
        val attachment = _pendingAttachment.value
        if (text.isEmpty() && attachment == null) return

        val editing = _editingMessage.value
        _composerText.value = ""
        _pendingAttachment.value = null
        _editingMessage.value = null

        viewModelScope.launch {
            val settings = preferencesRepository.settingsFlow.first()
            val convId = _activeConversationId.value ?: run {
                val created = repository.createConversation(
                    title = text.ifBlank { attachment?.name ?: "New Conversation" }.take(42),
                    modelName = settings.selectedModel
                )
                _activeConversationId.value = created.id
                created.id
            }

            if (editing != null) {
                repository.deleteMessagesAfter(convId, editing.createdAtMillis - 1)
            }

            val now = System.currentTimeMillis()
            val userMsg = ChatMessage(
                id = "msg_${UUID.randomUUID().toString().replace("-", "").take(20)}",
                conversationId = convId,
                role = "user",
                content = text.ifBlank { "Analyze attached file: ${attachment?.name}" },
                attachmentName = attachment?.name,
                attachmentMimeType = attachment?.mimeType,
                attachmentUri = attachment?.uri?.toString(),
                attachmentSizeBytes = attachment?.sizeBytes ?: 0L,
                createdAtMillis = now,
                updatedAtMillis = now
            )
            repository.saveMessage(userMsg)
            runAiResponse(
                conversationId = convId,
                userPrompt = userMsg.content,
                attachment = attachment,
                settings = settings,
                speakOnComplete = speakResponseOnComplete
            )
        }
    }

    fun sendVoicePrompt(transcript: String, speakResponseOnComplete: Boolean = true) {
        if (transcript.isBlank()) return
        _composerText.value = transcript
        sendCurrentMessage(speakResponseOnComplete = speakResponseOnComplete)
    }

    fun regenerateLastResponse(assistantMessage: ChatMessage) {
        val convId = assistantMessage.conversationId
        viewModelScope.launch {
            val all = repository.getMessagesOnce(convId)
            val idx = all.indexOfFirst { it.id == assistantMessage.id }
            val precedingUser = if (idx > 0) {
                all.subList(0, idx).lastOrNull { it.role == "user" }
            } else {
                all.lastOrNull { it.role == "user" }
            } ?: return@launch

            repository.deleteMessagesAfter(convId, assistantMessage.createdAtMillis - 1)
            val settings = preferencesRepository.settingsFlow.first()
            runAiResponse(
                conversationId = convId,
                userPrompt = precedingUser.content,
                attachment = null,
                settings = settings,
                speakOnComplete = false
            )
        }
    }

    fun deleteMessage(message: ChatMessage) {
        viewModelScope.launch {
            repository.deleteMessage(message.conversationId, message.id)
        }
    }

    fun saveMessageAsMemory(message: ChatMessage, category: MemoryCategory = MemoryCategory.FACT) {
        viewModelScope.launch {
            repository.addMemory(category, message.content.take(800))
        }
    }

    fun stopGeneration() {
        val partial = _streamingMessage.value
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _streamingMessage.value = null
        _generationStatus.value = GenerationStatus.Idle

        if (partial != null && partial.content.isNotBlank()) {
            viewModelScope.launch {
                val finalized = partial.copy(
                    isStreaming = false,
                    updatedAtMillis = System.currentTimeMillis()
                )
                repository.saveMessage(finalized)
                repository.syncConversationIfEnabled(finalized.conversationId)
            }
        }
    }

    private fun runAiResponse(
        conversationId: String,
        userPrompt: String,
        attachment: PendingAttachment?,
        settings: JamesSettings,
        speakOnComplete: Boolean
    ) {
        activeGenerationJob?.cancel()

        val allowsLocalPrimary = jamesCoreOrchestrator != null &&
            (settings.routingPolicy == RoutingPolicy.PRIMARY_FIRST ||
                settings.routingPolicy == RoutingPolicy.BALANCED_HYBRID) &&
            attachment == null

        if (!networkMonitor.checkCurrentConnectivity() && !allowsLocalPrimary) {
            viewModelScope.launch {
                val now = System.currentTimeMillis()
                val offlineMsg = ChatMessage(
                    id = "msg_${UUID.randomUUID().toString().replace("-", "").take(20)}",
                    conversationId = conversationId,
                    role = "assistant",
                    content = "You are currently offline. Cloud Gemini AI generation requires an active internet connection (or configure a local Ollama/llama.cpp host in Control Center). Your conversation and message have been saved securely to your device.",
                    modelName = settings.selectedModel,
                    isError = true,
                    createdAtMillis = now,
                    updatedAtMillis = now
                )
                repository.saveMessage(offlineMsg)
                _generationStatus.value = GenerationStatus.Error(
                    "Offline: Connect to the internet or configure a local open-weight runtime."
                )
            }
            return
        }

        activeGenerationJob = viewModelScope.launch {
            _generationStatus.value = GenerationStatus.Generating
            val streamId = "msg_${UUID.randomUUID().toString().replace("-", "").take(20)}"
            val startedAt = System.currentTimeMillis()

            _streamingMessage.value = ChatMessage(
                id = streamId,
                conversationId = conversationId,
                role = "assistant",
                content = "",
                modelName = settings.selectedModel,
                isStreaming = true,
                createdAtMillis = startedAt,
                updatedAtMillis = startedAt
            )

            try {
                val allPrior = repository.getMessagesOnce(conversationId)
                    .filter { it.createdAtMillis < startedAt && !it.isError }
                val historyWithoutCurrentPrompt = if (allPrior.isNotEmpty() && allPrior.last().role == "user") {
                    allPrior.dropLast(1)
                } else {
                    allPrior
                }

                val conv = repository.getConversation(conversationId)
                var contextSummary = conv?.contextSummary.orEmpty()

                if (settings.autoSummarizeContext &&
                    historyWithoutCurrentPrompt.size > settings.contextTurnLimit &&
                    networkMonitor.checkCurrentConnectivity()
                ) {
                    val overflow = historyWithoutCurrentPrompt.dropLast(settings.contextTurnLimit)
                    contextSummary = aiService.summarizeOlderMessages(overflow, contextSummary)
                    repository.updateConversationMetadata(
                        conversationId = conversationId,
                        contextSummary = contextSummary
                    )
                }

                val memories = if (settings.memoryEnabled) {
                    repository.getEnabledMemoriesOnce()
                } else {
                    emptyList()
                }

                var latestText = ""
                var usedModelLabel = settings.selectedModel

                if (jamesCoreOrchestrator != null) {
                    jamesCoreOrchestrator.executeChatTurn(
                        historyMessages = historyWithoutCurrentPrompt,
                        userPrompt = userPrompt,
                        attachment = attachment,
                        settings = settings,
                        memories = memories,
                        priorSummary = contextSummary
                    ).collect { chunk ->
                        latestText = chunk.text
                        usedModelLabel = "${chunk.engineLabel} · ${chunk.modelId}"
                        _streamingMessage.value = _streamingMessage.value?.copy(
                            content = chunk.text,
                            modelName = usedModelLabel,
                            updatedAtMillis = System.currentTimeMillis()
                        )
                    }
                } else {
                    aiService.streamResponse(
                        historyMessages = historyWithoutCurrentPrompt,
                        userPrompt = userPrompt,
                        attachment = attachment,
                        settings = settings,
                        memories = memories,
                        priorSummary = contextSummary
                    ).collect { accumulated ->
                        latestText = accumulated
                        _streamingMessage.value = _streamingMessage.value?.copy(
                            content = accumulated,
                            updatedAtMillis = System.currentTimeMillis()
                        )
                    }
                }

                val finalMsg = ChatMessage(
                    id = streamId,
                    conversationId = conversationId,
                    role = "assistant",
                    content = latestText,
                    modelName = usedModelLabel,
                    isStreaming = false,
                    createdAtMillis = startedAt,
                    updatedAtMillis = System.currentTimeMillis()
                )
                _streamingMessage.value = null
                repository.saveMessage(finalMsg)
                repository.syncConversationIfEnabled(conversationId)
                _generationStatus.value = GenerationStatus.Idle

                if (speakOnComplete && settings.voiceOutputEnabled && settings.autoSpeakInVoiceMode) {
                    voiceOutputManager.speak(
                        text = latestText,
                        messageId = finalMsg.id,
                        speechRate = settings.speechRate,
                        voiceName = settings.selectedTtsVoiceName,
                        preferredLanguage = settings.preferredResponseLanguage
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI generation failed", e)
                _streamingMessage.value = null
                val errorText = e.localizedMessage ?: "Failed to generate response."
                val errMsg = ChatMessage(
                    id = streamId,
                    conversationId = conversationId,
                    role = "assistant",
                    content = errorText,
                    modelName = settings.selectedModel,
                    isError = true,
                    createdAtMillis = startedAt,
                    updatedAtMillis = startedAt
                )
                repository.saveMessage(errMsg)
                _generationStatus.value = GenerationStatus.Error(errorText)
            }
        }
    }

    companion object {
        private const val TAG = "ChatViewModel"
    }
}
