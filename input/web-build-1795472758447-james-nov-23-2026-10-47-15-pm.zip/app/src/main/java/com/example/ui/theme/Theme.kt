package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class ThemeMode(val id: String, val labelEn: String, val labelAr: String) {
    DARK("dark", "Dark", "داكن"),
    LIGHT("light", "Light", "فاتح"),
    SYSTEM("system", "System Default", "افتراضي النظام");

    companion object {
        fun fromId(id: String): ThemeMode = entries.firstOrNull { it.id == id } ?: DARK
    }
}

val JamesShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

data class JamesExtendedColors(
    val isDark: Boolean,
    val codeBackground: Color,
    val userBubble: Color,
    val assistantBubble: Color,
    val subtleBorder: Color,
    val glowAccent: Color
)

val LocalJamesColors = staticCompositionLocalOf {
    JamesExtendedColors(
        isDark = true,
        codeBackground = CodeBlockBackgroundDark,
        userBubble = ObsidianSurfaceContainerHigh,
        assistantBubble = ObsidianSurface,
        subtleBorder = ObsidianOutline,
        glowAccent = JamesAccent.CYAN.primaryDark
    )
}

fun jamesDarkColorScheme(accent: JamesAccent): ColorScheme = darkColorScheme(
    primary = accent.primaryDark,
    onPrimary = accent.onPrimaryDark,
    primaryContainer = accent.containerDark,
    onPrimaryContainer = accent.onContainerDark,
    secondary = accent.secondary,
    onSecondary = ObsidianVoid,
    secondaryContainer = ObsidianSurfaceContainerHigh,
    onSecondaryContainer = PlatinumText,
    tertiary = accent.secondary,
    background = ObsidianVoid,
    onBackground = PlatinumText,
    surface = ObsidianSurface,
    onSurface = PlatinumText,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = SlateMutedText,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceElevated,
    surfaceContainerHigh = ObsidianSurfaceContainerHigh,
    surfaceContainerHighest = Color(0xFF222D42),
    outline = ObsidianOutline,
    outlineVariant = ObsidianOutlineSubtle,
    error = StatusDanger,
    onError = Color.White
)

fun jamesLightColorScheme(accent: JamesAccent): ColorScheme = lightColorScheme(
    primary = accent.primaryLight,
    onPrimary = accent.onPrimaryLight,
    primaryContainer = accent.containerLight,
    onPrimaryContainer = accent.onContainerLight,
    secondary = accent.secondary,
    onSecondary = Color.White,
    secondaryContainer = AlabasterSurfaceElevated,
    onSecondaryContainer = InkPrimaryText,
    tertiary = accent.primaryLight,
    background = AlabasterBackground,
    onBackground = InkPrimaryText,
    surface = AlabasterSurface,
    onSurface = InkPrimaryText,
    surfaceVariant = AlabasterSurfaceElevated,
    onSurfaceVariant = InkMutedText,
    surfaceContainerLowest = AlabasterSurface,
    surfaceContainerLow = AlabasterBackground,
    surfaceContainer = AlabasterSurfaceElevated,
    surfaceContainerHigh = AlabasterSurfaceHigh,
    surfaceContainerHighest = Color(0xFFD5DEE9),
    outline = AlabasterOutline,
    outlineVariant = Color(0xFFE2E8F0),
    error = StatusDanger,
    onError = Color.White
)

@Composable
fun JamesTheme(
    themeMode: ThemeMode = ThemeMode.DARK,
    accent: JamesAccent = JamesAccent.CYAN,
    fontScale: FontSizeScale = FontSizeScale.DEFAULT,
    isArabic: Boolean = false,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (useDark) jamesDarkColorScheme(accent) else jamesLightColorScheme(accent)
    val typography = buildJamesTypography(scale = fontScale, isArabic = isArabic)
    val extended = if (useDark) {
        JamesExtendedColors(
            isDark = true,
            codeBackground = CodeBlockBackgroundDark,
            userBubble = accent.containerDark.copy(alpha = 0.72f),
            assistantBubble = ObsidianSurfaceElevated,
            subtleBorder = ObsidianOutline,
            glowAccent = accent.primaryDark
        )
    } else {
        JamesExtendedColors(
            isDark = false,
            codeBackground = CodeBlockBackgroundLight,
            userBubble = accent.containerLight,
            assistantBubble = AlabasterSurface,
            subtleBorder = AlabasterOutline,
            glowAccent = accent.primaryLight
        )
    }

    CompositionLocalProvider(LocalJamesColors provides extended) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = JamesShapes,
            content = content
        )
    }
}
