package com.example.data.repository

import com.example.data.local.ConversationDao
import com.example.data.local.ConversationEntity
import com.example.data.local.MemoryDao
import com.example.data.local.MemoryEntity
import com.example.data.local.MessageDao
import com.example.data.local.MessageEntity
import com.example.data.local.NoteDao
import com.example.data.local.NoteEntity
import com.example.data.local.PreferencesRepository
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.LocalNote
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.data.remote.CloudSyncRepository
import com.example.data.remote.SyncSummary
import com.example.security.CryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class JamesRepository(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val memoryDao: MemoryDao,
    private val noteDao: NoteDao,
    private val preferencesRepository: PreferencesRepository,
    private val cryptoManager: CryptoManager,
    private val cloudSyncRepository: CloudSyncRepository
) {
    fun observeConversations(): Flow<List<Conversation>> =
        conversationDao.observeAllConversations().map { entities ->
            entities.map { it.toDomain() }
        }

    fun observeConversation(id: String): Flow<Conversation?> =
        conversationDao.observeConversation(id).map { it?.toDomain() }

    fun observeMessages(conversationId: String): Flow<List<ChatMessage>> =
        messageDao.observeMessages(conversationId).map { list ->
            list.map { it.toDomain() }
        }

    fun observeMemories(): Flow<List<MemoryItem>> =
        memoryDao.observeMemories().map { list ->
            list.map { it.toDomain() }
        }

    fun observeNotes(): Flow<List<LocalNote>> =
        noteDao.observeNotes().map { list ->
            list.map { it.toDomain() }
        }

    suspend fun getConversation(id: String): Conversation? =
        conversationDao.getConversation(id)?.toDomain()

    suspend fun getMessagesOnce(conversationId: String): List<ChatMessage> =
        messageDao.getMessagesOnce(conversationId).map { it.toDomain() }

    suspend fun getEnabledMemoriesOnce(): List<MemoryItem> =
        memoryDao.getEnabledMemoriesOnce().map { it.toDomain() }

    suspend fun createConversation(
        title: String = "New Conversation",
        modelName: String
    ): Conversation {
        val now = System.currentTimeMillis()
        val conv = Conversation(
            id = "conv_${UUID.randomUUID().toString().replace("-", "").take(20)}",
            title = title,
            modelName = modelName,
            lastMessagePreview = "",
            messageCount = 0,
            pinned = false,
            contextSummary = "",
            createdAtMillis = now,
            updatedAtMillis = now
        )
        conversationDao.upsertConversation(conv.toEntity())
        return conv
    }

    suspend fun updateConversationMetadata(
        conversationId: String,
        title: String? = null,
        lastMessagePreview: String? = null,
        modelName: String? = null,
        contextSummary: String? = null
    ) {
        val existing = conversationDao.getConversation(conversationId)?.toDomain() ?: return
        val messages = messageDao.getMessagesOnce(conversationId)
        val updated = existing.copy(
            title = title ?: existing.title,
            lastMessagePreview = lastMessagePreview ?: existing.lastMessagePreview,
            modelName = modelName ?: existing.modelName,
            contextSummary = contextSummary ?: existing.contextSummary,
            messageCount = messages.size,
            updatedAtMillis = System.currentTimeMillis()
        )
        conversationDao.upsertConversation(updated.toEntity())
        syncConversationIfEnabled(updated.id)
    }

    suspend fun renameConversation(conversationId: String, newTitle: String) {
        val clean = newTitle.trim().ifBlank { return }
        val existing = conversationDao.getConversation(conversationId)?.toDomain() ?: return
        val updated = existing.copy(title = clean, updatedAtMillis = System.currentTimeMillis())
        conversationDao.upsertConversation(updated.toEntity())
        syncConversationIfEnabled(conversationId)
    }

    suspend fun togglePinConversation(conversationId: String) {
        val existing = conversationDao.getConversation(conversationId)?.toDomain() ?: return
        val updated = existing.copy(pinned = !existing.pinned, updatedAtMillis = System.currentTimeMillis())
        conversationDao.upsertConversation(updated.toEntity())
        syncConversationIfEnabled(conversationId)
    }

    suspend fun deleteConversation(conversationId: String) {
        conversationDao.deleteConversation(conversationId)
        if (isCloudSyncActive()) {
            cloudSyncRepository.deleteRemoteConversation(conversationId)
        }
    }

    suspend fun deleteAllConversations() {
        val all = conversationDao.getAllConversationsOnce()
        conversationDao.deleteAllConversations()
        if (isCloudSyncActive()) {
            all.forEach { cloudSyncRepository.deleteRemoteConversation(it.id) }
        }
    }

    suspend fun saveMessage(message: ChatMessage) {
        messageDao.upsertMessage(message.toEntity())
        val existingConv = conversationDao.getConversation(message.conversationId)?.toDomain()
        if (existingConv != null) {
            val allMsgs = messageDao.getMessagesOnce(message.conversationId)
            val preview = message.content.replace("\n", " ").trim().take(120)
            val updatedTitle = if (existingConv.title == "New Conversation" && message.role == "user" && message.content.isNotBlank()) {
                message.content.replace("\n", " ").trim().take(42)
            } else {
                existingConv.title
            }
            val updated = existingConv.copy(
                title = updatedTitle,
                lastMessagePreview = preview,
                messageCount = allMsgs.size,
                updatedAtMillis = System.currentTimeMillis()
            )
            conversationDao.upsertConversation(updated.toEntity())
        }
    }

    suspend fun deleteMessage(conversationId: String, messageId: String) {
        messageDao.deleteMessage(messageId)
        val remaining = messageDao.getMessagesOnce(conversationId).map { it.toDomain() }
        val existing = conversationDao.getConversation(conversationId)?.toDomain() ?: return
        val lastPreview = remaining.lastOrNull()?.content?.replace("\n", " ")?.trim()?.take(120).orEmpty()
        conversationDao.upsertConversation(
            existing.copy(
                lastMessagePreview = lastPreview,
                messageCount = remaining.size,
                updatedAtMillis = System.currentTimeMillis()
            ).toEntity()
        )
        syncConversationIfEnabled(conversationId)
    }

    suspend fun deleteMessagesAfter(conversationId: String, afterMillis: Long) {
        messageDao.deleteMessagesAfter(conversationId, afterMillis)
    }

    suspend fun syncConversationIfEnabled(conversationId: String) {
        if (!isCloudSyncActive()) return
        val conv = conversationDao.getConversation(conversationId)?.toDomain() ?: return
        val msgs = messageDao.getMessagesOnce(conversationId).map { it.toDomain() }
        cloudSyncRepository.pushConversation(conv, msgs)
    }

    suspend fun addMemory(category: MemoryCategory, content: String): MemoryItem {
        val now = System.currentTimeMillis()
        val item = MemoryItem(
            id = "mem_${UUID.randomUUID().toString().replace("-", "").take(20)}",
            category = category,
            content = content.trim(),
            enabled = true,
            createdAtMillis = now,
            updatedAtMillis = now
        )
        memoryDao.upsertMemory(item.toEntity())
        if (isCloudSyncActive()) {
            cloudSyncRepository.pushMemory(item)
        }
        return item
    }

    suspend fun updateMemory(memory: MemoryItem) {
        val updated = memory.copy(updatedAtMillis = System.currentTimeMillis())
        memoryDao.upsertMemory(updated.toEntity())
        if (isCloudSyncActive()) {
            cloudSyncRepository.pushMemory(updated)
        }
    }

    suspend fun deleteMemory(memoryId: String) {
        memoryDao.deleteMemory(memoryId)
        if (isCloudSyncActive()) {
            cloudSyncRepository.deleteRemoteMemory(memoryId)
        }
    }

    suspend fun deleteAllMemories() {
        val all = memoryDao.getAllMemoriesOnce()
        memoryDao.deleteAllMemories()
        if (isCloudSyncActive()) {
            all.forEach { cloudSyncRepository.deleteRemoteMemory(it.id) }
        }
    }

    suspend fun saveNote(title: String, content: String, existingId: String? = null): LocalNote {
        val now = System.currentTimeMillis()
        val note = LocalNote(
            id = existingId ?: "note_${UUID.randomUUID().toString().replace("-", "").take(20)}",
            title = title.trim().ifBlank { "Untitled Note" },
            content = content,
            createdAtMillis = now,
            updatedAtMillis = now
        )
        noteDao.upsertNote(note.toEntity())
        if (isCloudSyncActive()) {
            cloudSyncRepository.pushNote(note)
        }
        return note
    }

    suspend fun deleteNote(noteId: String) {
        noteDao.deleteNote(noteId)
        if (isCloudSyncActive()) {
            cloudSyncRepository.deleteRemoteNote(noteId)
        }
    }

    suspend fun syncAllWithCloud(): Result<SyncSummary> {
        if (Firebase.auth.currentUser == null) {
            return Result.failure(IllegalStateException("Sign in with Google to synchronize with Cloud Firestore."))
        }
        val user = Firebase.auth.currentUser
        cloudSyncRepository.ensureUserProfile(user?.displayName ?: "JAMES User", user?.email)

        var pushedConvs = 0
        var pulledConvs = 0
        var pushedMems = 0
        var pulledMems = 0
        var pushedNotes = 0
        var pulledNotes = 0

        // 1. Pull remote conversations & merge newer/missing locally
        val remoteConvs = cloudSyncRepository.pullConversations().getOrElse { return Result.failure(it) }
        val localConvs = conversationDao.getAllConversationsOnce().map { it.toDomain() }.associateBy { it.id }

        for ((rConv, rMsgs) in remoteConvs) {
            val lConv = localConvs[rConv.id]
            if (lConv == null || rConv.updatedAtMillis > lConv.updatedAtMillis) {
                conversationDao.upsertConversation(rConv.toEntity())
                for (msg in rMsgs) {
                    messageDao.upsertMessage(msg.toEntity())
                }
                pulledConvs++
            }
        }

        // Push local conversations newer or absent remotely
        val remoteConvMap = remoteConvs.associate { it.first.id to it.first }
        for (lConv in conversationDao.getAllConversationsOnce().map { it.toDomain() }) {
            val rConv = remoteConvMap[lConv.id]
            if (rConv == null || lConv.updatedAtMillis > rConv.updatedAtMillis) {
                val msgs = messageDao.getMessagesOnce(lConv.id).map { it.toDomain() }
                if (cloudSyncRepository.pushConversation(lConv, msgs).isSuccess) {
                    pushedConvs++
                }
            }
        }

        // 2. Sync memories
        val remoteMems = cloudSyncRepository.pullMemories().getOrElse { return Result.failure(it) }
        val localMems = memoryDao.getAllMemoriesOnce().map { it.toDomain() }.associateBy { it.id }
        for (rm in remoteMems) {
            val lm = localMems[rm.id]
            if (lm == null || rm.updatedAtMillis > lm.updatedAtMillis) {
                memoryDao.upsertMemory(rm.toEntity())
                pulledMems++
            }
        }
        val remoteMemMap = remoteMems.associateBy { it.id }
        for (lm in memoryDao.getAllMemoriesOnce().map { it.toDomain() }) {
            val rm = remoteMemMap[lm.id]
            if (rm == null || lm.updatedAtMillis > rm.updatedAtMillis) {
                if (cloudSyncRepository.pushMemory(lm).isSuccess) pushedMems++
            }
        }

        // 3. Sync notes
        val remoteNotes = cloudSyncRepository.pullNotes().getOrElse { return Result.failure(it) }
        val localNotes = noteDao.getAllNotesOnce().map { it.toDomain() }.associateBy { it.id }
        for (rn in remoteNotes) {
            val ln = localNotes[rn.id]
            if (ln == null || rn.updatedAtMillis > ln.updatedAtMillis) {
                noteDao.upsertNote(rn.toEntity())
                pulledNotes++
            }
        }
        val remoteNoteMap = remoteNotes.associateBy { it.id }
        for (ln in noteDao.getAllNotesOnce().map { it.toDomain() }) {
            val rn = remoteNoteMap[ln.id]
            if (rn == null || ln.updatedAtMillis > rn.updatedAtMillis) {
                if (cloudSyncRepository.pushNote(ln).isSuccess) pushedNotes++
            }
        }

        return Result.success(
            SyncSummary(
                pushedConversations = pushedConvs,
                pulledConversations = pulledConvs,
                pushedMemories = pushedMems,
                pulledMemories = pulledMems,
                pushedNotes = pushedNotes,
                pulledNotes = pulledNotes
            )
        )
    }

    suspend fun exportAllDataAsJson(): String {
        val convs = conversationDao.getAllConversationsOnce().map { it.toDomain() }
        val memories = memoryDao.getAllMemoriesOnce().map { it.toDomain() }
        val notes = noteDao.getAllNotesOnce().map { it.toDomain() }

        val convJsonArray = JSONArray()
        for (conv in convs) {
            val msgs = messageDao.getMessagesOnce(conv.id).map { it.toDomain() }
            val msgArray = JSONArray()
            msgs.forEach { m ->
                msgArray.put(JSONObject().apply {
                    put("id", m.id)
                    put("role", m.role)
                    put("content", m.content)
                    put("attachmentName", m.attachmentName)
                    put("modelName", m.modelName)
                    put("createdAtMillis", m.createdAtMillis)
                })
            }
            convJsonArray.put(JSONObject().apply {
                put("id", conv.id)
                put("title", conv.title)
                put("modelName", conv.modelName)
                put("pinned", conv.pinned)
                put("createdAtMillis", conv.createdAtMillis)
                put("updatedAtMillis", conv.updatedAtMillis)
                put("messages", msgArray)
            })
        }

        val memArray = JSONArray()
        memories.forEach { mem ->
            memArray.put(JSONObject().apply {
                put("id", mem.id)
                put("category", mem.category.id)
                put("content", mem.content)
                put("enabled", mem.enabled)
                put("updatedAtMillis", mem.updatedAtMillis)
            })
        }

        val noteArray = JSONArray()
        notes.forEach { note ->
            noteArray.put(JSONObject().apply {
                put("id", note.id)
                put("title", note.title)
                put("content", note.content)
                put("updatedAtMillis", note.updatedAtMillis)
            })
        }

        return JSONObject().apply {
            put("app", "JAMES")
            put("exportedAtMillis", System.currentTimeMillis())
            put("conversations", convJsonArray)
            put("memories", memArray)
            put("notes", noteArray)
        }.toString(2)
    }

    private suspend fun isCloudSyncActive(): Boolean {
        val settings = preferencesRepository.settingsFlow.first()
        return settings.cloudSyncEnabled && Firebase.auth.currentUser != null
    }

    private fun Conversation.toEntity(): ConversationEntity = ConversationEntity(
        id = id,
        title = cryptoManager.encryptLocal(title),
        modelName = modelName,
        lastMessagePreview = cryptoManager.encryptLocal(lastMessagePreview),
        messageCount = messageCount,
        pinned = pinned,
        contextSummary = cryptoManager.encryptLocal(contextSummary),
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun ConversationEntity.toDomain(): Conversation = Conversation(
        id = id,
        title = cryptoManager.decryptLocal(title),
        modelName = modelName,
        lastMessagePreview = cryptoManager.decryptLocal(lastMessagePreview),
        messageCount = messageCount,
        pinned = pinned,
        contextSummary = cryptoManager.decryptLocal(contextSummary),
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun ChatMessage.toEntity(): MessageEntity = MessageEntity(
        id = id,
        conversationId = conversationId,
        role = role,
        content = cryptoManager.encryptLocal(content),
        attachmentName = attachmentName,
        attachmentMimeType = attachmentMimeType,
        attachmentUri = attachmentUri,
        attachmentSizeBytes = attachmentSizeBytes,
        modelName = modelName,
        isError = isError,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun MessageEntity.toDomain(): ChatMessage = ChatMessage(
        id = id,
        conversationId = conversationId,
        role = role,
        content = cryptoManager.decryptLocal(content),
        attachmentName = attachmentName,
        attachmentMimeType = attachmentMimeType,
        attachmentUri = attachmentUri,
        attachmentSizeBytes = attachmentSizeBytes,
        modelName = modelName,
        isError = isError,
        isStreaming = false,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun MemoryItem.toEntity(): MemoryEntity = MemoryEntity(
        id = id,
        category = category.id,
        content = cryptoManager.encryptLocal(content),
        enabled = enabled,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun MemoryEntity.toDomain(): MemoryItem = MemoryItem(
        id = id,
        category = MemoryCategory.fromId(category),
        content = cryptoManager.decryptLocal(content),
        enabled = enabled,
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun LocalNote.toEntity(): NoteEntity = NoteEntity(
        id = id,
        title = cryptoManager.encryptLocal(title),
        content = cryptoManager.encryptLocal(content),
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )

    private fun NoteEntity.toDomain(): LocalNote = LocalNote(
        id = id,
        title = cryptoManager.decryptLocal(title),
        content = cryptoManager.decryptLocal(content),
        createdAtMillis = createdAtMillis,
        updatedAtMillis = updatedAtMillis
    )
}
