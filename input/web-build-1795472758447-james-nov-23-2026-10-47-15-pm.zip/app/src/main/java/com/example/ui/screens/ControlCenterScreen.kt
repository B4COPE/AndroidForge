package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BugReport
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.Extension
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ProposalApprovalStatus
import com.example.data.model.RoutingPolicy
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusSuccess
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ControlCenterScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit,
    onOpenProvidersRuntime: () -> Unit,
    onOpenCouncilDashboard: () -> Unit,
    onOpenKnowledgeLearning: () -> Unit,
    onOpenExtensionsHub: () -> Unit,
    onOpenCloudMigration: () -> Unit,
    onOpenPrivateVault: () -> Unit,
    onOpenDiagnosticsLogs: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenGeneralSettings: () -> Unit,
    onOpenAbout: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val settings by ecosystemViewModel.settings.collectAsStateWithLifecycle()
    val providers by ecosystemViewModel.providers.collectAsStateWithLifecycle()
    val knowledge by ecosystemViewModel.knowledgeItems.collectAsStateWithLifecycle()
    val proposals by ecosystemViewModel.proposals.collectAsStateWithLifecycle()
    val skills by ecosystemViewModel.skills.collectAsStateWithLifecycle()
    val vaultUnlocked by ecosystemViewModel.vaultUnlocked.collectAsStateWithLifecycle()

    val pendingProposals = proposals.count { it.approvalStatus == ProposalApprovalStatus.PENDING }
    val primaryProvider = providers.firstOrNull { it.isDefaultPrimary }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.controlCenter) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("control_center_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section 1: JAMES Core Status Summary
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "JAMES Independent Core — 22 Subsystem Modules",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Primary Brain: ${primaryProvider?.name ?: "Unset"} (${primaryProvider?.modelId ?: "-"}) · " +
                                "Knowledge: ${knowledge.size} · Skills: ${skills.count { it.enabled }} active · " +
                                "Pending Proposals: $pendingProposals · Private Vault: ${if (vaultUnlocked) "Unlocked" else "Locked"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Section 2 & 3: Active Routing Policy
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Core Routing Policy & Autonomy Mode",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            RoutingPolicy.entries.forEach { policy ->
                                FilterChip(
                                    selected = settings.routingPolicy == policy,
                                    onClick = { ecosystemViewModel.setRoutingPolicy(policy) },
                                    label = {
                                        Text(if (strings.isArabic) policy.labelAr else policy.labelEn)
                                    }
                                )
                            }
                        }
                        Text(
                            text = settings.routingPolicy.summaryEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Categorized Control Center Hubs covering all 22 required sections
                ControlHubTile(
                    icon = Icons.Outlined.Memory,
                    title = "Open-Weight Primary Brain, Inference Runtimes & AI Providers",
                    subtitle = "Gemma 3 / Qwen 2.5 / Llama 3.1 catalog, Ollama/llama.cpp/vLLM, OpenAI/Anthropic/DeepSeek keys, Usage & Fine-Tuning readiness",
                    badge = "${providers.count { it.enabled }} active",
                    testTag = "hub_providers_runtime",
                    onClick = onOpenProvidersRuntime
                )

                ControlHubTile(
                    icon = Icons.Outlined.Forum,
                    title = "AI Council Dashboard & Approval Center",
                    subtitle = "8-role multi-model deliberation, disagreements tracker, Improvement Proposals & human approve/reject/rollback",
                    badge = if (pendingProposals > 0) "$pendingProposals pending" else "Ready",
                    testTag = "hub_council_dashboard",
                    onClick = onOpenCouncilDashboard
                )

                ControlHubTile(
                    icon = Icons.Outlined.School,
                    title = "Knowledge Repository & Continuous Learning Engine",
                    subtitle = "Chunking, SHA-256 deduplication, TF-IDF retrieval, verification lifecycle & error/gap lesson synthesis",
                    badge = "${knowledge.size} items",
                    testTag = "hub_knowledge_learning",
                    onClick = onOpenKnowledgeLearning
                )

                ControlHubTile(
                    icon = Icons.Outlined.Extension,
                    title = "Skills Manager, MCP Servers & External Connectors",
                    subtitle = "SKILL.md security inspection, Streamable HTTP/SSE MCP discovery, approval gates & cloud service probes",
                    badge = "${skills.size} skills",
                    testTag = "hub_extensions",
                    onClick = onOpenExtensionsHub
                )

                ControlHubTile(
                    icon = Icons.Outlined.CloudSync,
                    title = "Cloud Core Hosting, Storage Targets, Migration & Scheduler",
                    subtitle = "OCI Always Free guide, independent Cloud Core URL, 13-step SHA-256 migration & bounded background jobs",
                    badge = if (settings.useCloudBackendWhenAvailable) "Backend ON" else "Standalone",
                    testTag = "hub_cloud_migration",
                    onClick = onOpenCloudMigration
                )

                ControlHubTile(
                    icon = Icons.Outlined.Lock,
                    title = "Private Vault & Security Center",
                    subtitle = "Isolated Android Keystore AES-256-GCM vault, PBKDF2 PIN & Biometric unlock, auto-lock timeout",
                    badge = if (vaultUnlocked) "Unlocked" else "Locked",
                    badgeHighlight = vaultUnlocked,
                    testTag = "hub_private_vault",
                    onClick = onOpenPrivateVault
                )

                ControlHubTile(
                    icon = Icons.Outlined.BugReport,
                    title = "Diagnostics, Cost Monitoring & Sanitized System Logs",
                    subtitle = "Live self-check across Room v2, Vault, Primary runtime & Backend plus secret-redacted audit logs",
                    badge = "Audit",
                    testTag = "hub_diagnostics_logs",
                    onClick = onOpenDiagnosticsLogs
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SmallQuickTile(
                        icon = Icons.Outlined.Psychology,
                        title = strings.memoryManagement,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenMemory
                    )
                    SmallQuickTile(
                        icon = Icons.Outlined.Settings,
                        title = strings.generalSettings,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenGeneralSettings
                    )
                    SmallQuickTile(
                        icon = Icons.Outlined.Info,
                        title = strings.aboutJames,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenAbout
                    )
                }

                // Ownership Card Reminder
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Outlined.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = "JAMES — Founded & developed by Abbas Adel Rahim (Cope / Mark). Independent open architecture.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun ControlHubTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String,
    badgeHighlight: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                Spacer(modifier = Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = (if (badgeHighlight) StatusSuccess else MaterialTheme.colorScheme.primary).copy(alpha = 0.14f)
            ) {
                Text(
                    text = badge,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (badgeHighlight) StatusSuccess else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null)
        }
    }
}

@Composable
private fun SmallQuickTile(
    icon: ImageVector,
    title: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.labelMedium, maxLines = 1)
        }
    }
}
