package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

enum class TtsPlaybackState {
    IDLE,
    SPEAKING,
    PAUSED
}

data class TtsVoiceOption(
    val name: String,
    val localeTag: String,
    val displayName: String
)

class VoiceOutputManager(context: Context) {
    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _playbackState = MutableStateFlow(TtsPlaybackState.IDLE)
    val playbackState: StateFlow<TtsPlaybackState> = _playbackState.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    private val _activeMessageId = MutableStateFlow<String?>(null)
    val activeMessageId: StateFlow<String?> = _activeMessageId.asStateFlow()

    private var currentChunks: List<String> = emptyList()
    private var currentChunkIndex: Int = 0
    private var currentRate: Float = 1.0f
    private var currentVoiceName: String = ""
    private var currentLanguageHint: String = "en"
    private var lastFullText: String = ""

    init {
        try {
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isInitialized = true
                    refreshVoices()
                    attachListener()
                }
            }
        } catch (_: Exception) {
            isInitialized = false
        }
    }

    private fun refreshVoices() {
        val engine = tts ?: return
        val voices = try {
            engine.voices
                ?.filter {
                    val lang = it.locale.language.lowercase()
                    lang == "en" || lang == "ar"
                }
                ?.sortedBy { it.locale.toLanguageTag() }
                ?.take(25)
                ?.map { v: Voice ->
                    TtsVoiceOption(
                        name = v.name,
                        localeTag = v.locale.toLanguageTag(),
                        displayName = "${v.locale.displayLanguage} (${v.locale.country.ifBlank { v.locale.language }}) · ${v.name.takeLast(14)}"
                    )
                }.orEmpty()
        } catch (_: Exception) {
            emptyList()
        }
        _availableVoices.value = voices
    }

    private fun attachListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _playbackState.value = TtsPlaybackState.SPEAKING
            }

            override fun onDone(utteranceId: String?) {
                if (_playbackState.value != TtsPlaybackState.SPEAKING) return
                val next = currentChunkIndex + 1
                if (next < currentChunks.size) {
                    currentChunkIndex = next
                    speakCurrentChunk()
                } else {
                    _playbackState.value = TtsPlaybackState.IDLE
                    currentChunkIndex = 0
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                _playbackState.value = TtsPlaybackState.IDLE
            }
        })
    }

    fun speak(
        text: String,
        messageId: String? = null,
        speechRate: Float = 1.0f,
        voiceName: String = "",
        preferredLanguage: String = "auto"
    ) {
        val clean = sanitizeForSpeech(text)
        if (clean.isBlank() || !isInitialized) return

        currentRate = speechRate.coerceIn(0.5f, 2.0f)
        currentVoiceName = voiceName
        currentLanguageHint = if (preferredLanguage == "auto") {
            if (containsArabic(clean)) "ar" else "en"
        } else {
            preferredLanguage
        }
        lastFullText = clean
        _activeMessageId.value = messageId

        currentChunks = splitIntoSentences(clean)
        currentChunkIndex = 0
        configureEngineLanguageAndVoice()
        _playbackState.value = TtsPlaybackState.SPEAKING
        speakCurrentChunk()
    }

    fun pause() {
        if (_playbackState.value == TtsPlaybackState.SPEAKING) {
            _playbackState.value = TtsPlaybackState.PAUSED
            tts?.stop()
        }
    }

    fun resume() {
        if (_playbackState.value == TtsPlaybackState.PAUSED && currentChunks.isNotEmpty()) {
            configureEngineLanguageAndVoice()
            _playbackState.value = TtsPlaybackState.SPEAKING
            speakCurrentChunk()
        }
    }

    fun replay() {
        if (lastFullText.isNotBlank()) {
            speak(
                text = lastFullText,
                messageId = _activeMessageId.value,
                speechRate = currentRate,
                voiceName = currentVoiceName,
                preferredLanguage = currentLanguageHint
            )
        }
    }

    fun stop() {
        _playbackState.value = TtsPlaybackState.IDLE
        _activeMessageId.value = null
        currentChunkIndex = 0
        tts?.stop()
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }

    private fun configureEngineLanguageAndVoice() {
        val engine = tts ?: return
        engine.setSpeechRate(currentRate)

        val targetLocale = if (currentLanguageHint.startsWith("ar")) {
            Locale.Builder().setLanguage("ar").setRegion("SA").build()
        } else {
            Locale.US
        }
        engine.language = targetLocale

        if (currentVoiceName.isNotBlank()) {
            val match = try {
                engine.voices?.firstOrNull { it.name == currentVoiceName }
            } catch (_: Exception) {
                null
            }
            if (match != null) {
                engine.voice = match
            }
        }
    }

    private fun speakCurrentChunk() {
        val engine = tts ?: return
        val chunk = currentChunks.getOrNull(currentChunkIndex) ?: return
        val utteranceId = "james_${UUID.randomUUID()}"
        engine.speak(chunk, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    private fun sanitizeForSpeech(raw: String): String {
        return raw
            .replace(Regex("```[\\s\\S]*?```"), " Code block omitted. ")
            .replace(Regex("[#*_`~|>]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun splitIntoSentences(text: String): List<String> {
        val parts = text.split(Regex("(?<=[.!?؟،])\\s+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        return if (parts.isEmpty()) listOf(text) else parts
    }

    private fun containsArabic(text: String): Boolean =
        text.any { it in '\u0600'..'\u06FF' }
}
