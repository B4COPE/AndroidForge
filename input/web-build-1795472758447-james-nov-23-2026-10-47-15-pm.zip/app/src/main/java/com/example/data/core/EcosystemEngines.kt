package com.example.data.core

import com.example.data.model.ConnectorIntegration
import com.example.data.model.ExperienceOutcomeType
import com.example.data.model.KnowledgeItem
import com.example.data.model.KnowledgeMatch
import com.example.data.model.LearningExperience
import com.example.data.model.McpServerConfig
import com.example.data.model.McpTransport
import com.example.data.model.MigrationRecord
import com.example.data.model.SkillPackage
import com.example.data.model.ValidationStatus
import com.example.data.repository.EcosystemRepository
import com.example.security.PrivateVaultManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.ln

/**
 * Chunking, SHA-256 deduplication, verification tracking, and TF-IDF semantic-keyword hybrid retrieval
 * for JAMES's persistent Knowledge Repository.
 */
object KnowledgeRetrievalEngine {

    private val STOP_WORDS = setOf(
        "the", "and", "for", "with", "that", "this", "from", "are", "was", "were",
        "have", "has", "will", "not", "but", "can", "into", "about", "what", "how",
        "when", "where", "which", "your", "their", "them", "they", "you", "من", "في", "على", "إلى", "عن"
    )

    fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(input.trim().toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun chunkText(text: String, maxChars: Int = 520, overlapChars: Int = 80): List<String> {
        val clean = text.trim()
        if (clean.isEmpty()) return emptyList()
        if (clean.length <= maxChars) return listOf(clean)
        val chunks = mutableListOf<String>()
        var start = 0
        val step = (maxChars - overlapChars).coerceAtLeast(100)
        while (start < clean.length) {
            val end = (start + maxChars).coerceAtMost(clean.length)
            chunks.add(clean.substring(start, end))
            if (end == clean.length) break
            start += step
        }
        return chunks
    }

    fun tokenize(text: String): List<String> {
        return text.lowercase()
            .split(Regex("[^\\p{L}\\p{Nd}_]+"))
            .filter { it.length >= 2 && it !in STOP_WORDS }
    }

    fun search(
        query: String,
        items: List<KnowledgeItem>,
        topK: Int = 4
    ): List<KnowledgeMatch> {
        val queryTokens = tokenize(query)
        if (queryTokens.isEmpty() || items.isEmpty()) return emptyList()

        val activeItems = items.filter { it.validationStatus != ValidationStatus.OUTDATED }
        if (activeItems.isEmpty()) return emptyList()

        val totalDocs = activeItems.size.toDouble()
        val docTokenMaps = activeItems.map { item ->
            val combined = "${item.title} ${item.topicsCsv.replace(",", " ")} ${item.content}"
            tokenize(combined)
        }

        val docFreq = mutableMapOf<String, Int>()
        queryTokens.distinct().forEach { term ->
            docFreq[term] = docTokenMaps.count { tokens -> term in tokens }
        }

        return activeItems.mapIndexedNotNull { idx, item ->
            val tokens = docTokenMaps[idx]
            if (tokens.isEmpty()) return@mapIndexedNotNull null
            val tfCounts = tokens.groupingBy { it }.eachCount()
            var tfidfScore = 0.0
            for (term in queryTokens) {
                val tf = (tfCounts[term] ?: 0).toDouble() / tokens.size.toDouble()
                if (tf > 0.0) {
                    val df = (docFreq[term] ?: 0) + 1
                    val idf = ln((totalDocs + 1.0) / df.toDouble()) + 1.0
                    tfidfScore += tf * idf
                }
            }
            if (item.title.contains(query.trim(), ignoreCase = true)) {
                tfidfScore += 0.45
            }
            if (tfidfScore <= 0.0) return@mapIndexedNotNull null

            val reliabilityWeight = 0.65 + (0.35 * item.reliabilityScore.coerceIn(0f, 1f))
            val finalScore = tfidfScore * reliabilityWeight
            val bestExcerpt = chunkText(item.content, 240, 40).maxByOrNull { chunk ->
                val chunkTokens = tokenize(chunk).toSet()
                queryTokens.count { it in chunkTokens }
            } ?: item.content.take(240)

            KnowledgeMatch(
                item = item,
                matchedExcerpt = bestExcerpt,
                score = finalScore
            )
        }
            .sortedByDescending { it.score }
            .take(topK)
    }
}

/**
 * Inspects SKILL.md manifests before activation to prevent prompt-injection,
 * destructive shell calls, secret harvesting, or undeclared network side effects.
 */
data class SkillInspectionReport(
    val safeToEnable: Boolean,
    val detectedFlags: List<String>,
    val extractedName: String?,
    val extractedDescription: String?,
    val extractedPermissions: List<String>,
    val summary: String
)

object SkillsInspector {
    private val DANGEROUS_PATTERNS = listOf(
        Regex("rm\\s+-rf|del\\s+/f|mkfs|dd\\s+if=", RegexOption.IGNORE_CASE) to "Destructive filesystem command",
        Regex("curl\\s+[^\\n]*\\|\\s*(sh|bash)|wget\\s+[^\\n]*\\|\\s*(sh|bash)", RegexOption.IGNORE_CASE) to "Remote pipe-to-shell execution",
        Regex("eval\\(|exec\\(|Runtime\\.getRuntime|ProcessBuilder", RegexOption.IGNORE_CASE) to "Arbitrary code/process execution",
        Regex("ignore\\s+previous\\s+instructions|system\\s+prompt|override\\s+safety", RegexOption.IGNORE_CASE) to "Prompt-injection instruction override",
        Regex("private_vault|ACCESS_KEY|SECRET_KEY|id_rsa|\\.env\\b", RegexOption.IGNORE_CASE) to "Sensitive secret/credential targeting"
    )

    fun inspectSkillMarkdown(markdown: String, allowScriptExecution: Boolean = false): SkillInspectionReport {
        val flags = mutableListOf<String>()
        DANGEROUS_PATTERNS.forEach { (regex, reason) ->
            if (regex.containsMatchIn(markdown)) {
                flags.add(reason)
            }
        }
        val mentionsScripts = Regex("```(bash|sh|python|powershell)", RegexOption.IGNORE_CASE).containsMatchIn(markdown)
        if (mentionsScripts && !allowScriptExecution) {
            flags.add("Contains executable script blocks while 'Allow Skill Script Execution' is disabled")
        }

        val nameLine = Regex("^#\\s+(?:SKILL:\\s*)?(.+)$", RegexOption.MULTILINE)
            .find(markdown)?.groupValues?.getOrNull(1)?.trim()
        val permsMatch = Regex("(?:permissions|scopes)\\s*:\\s*(.+)$", setOf(RegexOption.MULTILINE, RegexOption.IGNORE_CASE))
            .find(markdown)?.groupValues?.getOrNull(1)
            ?.split(",")?.map { it.trim() }?.filter { it.isNotBlank() }
            ?: emptyList()
        val firstParagraph = markdown.lines()
            .firstOrNull { line ->
                val t = line.trim()
                t.isNotBlank() && !t.startsWith("#") && !t.startsWith("---")
            }?.trim()?.take(180)

        val safe = flags.isEmpty()
        val summary = if (safe) {
            "Inspection passed: no injection or destructive execution patterns found."
        } else {
            "Flagged ${flags.size} security concern(s): ${flags.joinToString("; ")}"
        }
        return SkillInspectionReport(
            safeToEnable = safe,
            detectedFlags = flags,
            extractedName = nameLine,
            extractedDescription = firstParagraph,
            extractedPermissions = permsMatch,
            summary = summary
        )
    }

    fun wrapUntrustedToolOutput(sourceLabel: String, rawPayload: String): String {
        val clean = PrivateVaultManager.redactSecrets(rawPayload)
            .replace("```", "'''")
            .take(4000)
        return "[UNTRUSTED_EXTERNAL_DATA source=\"$sourceLabel\"]\n$clean\n[/UNTRUSTED_EXTERNAL_DATA]"
    }
}

/**
 * Real MCP (Model Context Protocol) HTTP / Streamable-HTTP & HTTP+SSE Client.
 * Honest architectural boundary: Android apps cannot execute arbitrary local Node/Python desktop STDIO
 * child processes safely; STDIO servers require a remote HTTPS/Streamable-HTTP bridge.
 */
class McpHttpClient(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun discoverTools(
        server: McpServerConfig,
        bearerToken: String? = null
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            if (server.transport == McpTransport.STDIO_BRIDGE &&
                !server.endpointUrl.startsWith("https://") &&
                !server.endpointUrl.startsWith("http://")
            ) {
                throw IllegalStateException(
                    "Desktop STDIO MCP servers cannot spawn directly inside Android sandbox. Point endpoint URL to a remote Streamable-HTTP/SSE MCP bridge."
                )
            }
            val url = server.endpointUrl.trim()
            require(url.startsWith("https://") || url.startsWith("http://")) {
                "Invalid MCP server URL. Must start with https:// (or local dev http://)."
            }

            val payload = JSONObject()
                .put("jsonrpc", "2.0")
                .put("id", "james-tools-${System.currentTimeMillis()}")
                .put("method", "tools/list")
                .put("params", JSONObject())

            val builder = Request.Builder()
                .url(url)
                .addHeader("Accept", "application/json, text/event-stream")
                .post(payload.toString().toRequestBody(jsonMediaType))
            if (!bearerToken.isNullOrBlank()) {
                builder.addHeader("Authorization", "Bearer $bearerToken")
            }

            httpClient.newCall(builder.build()).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException("MCP server HTTP ${resp.code}: ${raw.take(200)}")
                }
                val jsonPayload = extractJsonFromHttpOrSse(raw)
                val toolsArr = JSONObject(jsonPayload)
                    .optJSONObject("result")
                    ?.optJSONArray("tools")
                    ?: JSONArray()
                buildList {
                    for (i in 0 until toolsArr.length()) {
                        val t = toolsArr.optJSONObject(i) ?: continue
                        val name = t.optString("name").ifBlank { continue }
                        val desc = t.optString("description").take(80)
                        add(if (desc.isNotBlank()) "$name — $desc" else name)
                    }
                }
            }
        }
    }

    suspend fun invokeTool(
        server: McpServerConfig,
        toolName: String,
        argumentsJson: String,
        approvedByUser: Boolean,
        bearerToken: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            if (server.requireApprovalPerCall && !approvedByUser) {
                throw IllegalStateException("Explicit user confirmation is required before invoking MCP tool '$toolName'.")
            }
            val argsObj = if (argumentsJson.isBlank()) JSONObject() else JSONObject(argumentsJson)
            val payload = JSONObject()
                .put("jsonrpc", "2.0")
                .put("id", "james-call-${System.currentTimeMillis()}")
                .put("method", "tools/call")
                .put("params", JSONObject().put("name", toolName).put("arguments", argsObj))

            val builder = Request.Builder()
                .url(server.endpointUrl.trim())
                .addHeader("Accept", "application/json, text/event-stream")
                .post(payload.toString().toRequestBody(jsonMediaType))
            if (!bearerToken.isNullOrBlank()) {
                builder.addHeader("Authorization", "Bearer $bearerToken")
            }

            httpClient.newCall(builder.build()).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException("MCP call HTTP ${resp.code}: ${raw.take(200)}")
                }
                SkillsInspector.wrapUntrustedToolOutput("mcp:${server.name}/$toolName", raw)
            }
        }
    }

    private fun extractJsonFromHttpOrSse(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.startsWith("{")) return trimmed
        // Parse first SSE data line carrying JSON-RPC result
        val dataLines = trimmed.lines()
            .filter { it.startsWith("data:") }
            .map { it.removePrefix("data:").trim() }
            .filter { it.startsWith("{") }
        return dataLines.lastOrNull() ?: trimmed
    }
}

class CloudBackendClient(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun checkHealth(baseUrl: String, bearerToken: String? = null): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val url = "${baseUrl.trim().trimEnd('/')}/health"
                val builder = Request.Builder().url(url).get()
                if (!bearerToken.isNullOrBlank()) {
                    builder.addHeader("Authorization", "Bearer $bearerToken")
                }
                httpClient.newCall(builder.build()).execute().use { resp ->
                    val raw = resp.body?.string().orEmpty()
                    if (!resp.isSuccessful) {
                        throw IllegalStateException("Backend HTTP ${resp.code}: ${raw.take(180)}")
                    }
                    val obj = JSONObject(raw)
                    "Healthy (${obj.optString("service", "james-core")} · primary=${obj.optString("primaryModel", "configured")})"
                }
            }
        }

    suspend fun queryChat(
        baseUrl: String,
        bearerToken: String?,
        prompt: String,
        history: List<Pair<String, String>>,
        routingPolicy: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanBase = baseUrl.trim().trimEnd('/')
            require(cleanBase.startsWith("https://") || cleanBase.startsWith("http://")) {
                "Invalid JAMES Cloud Backend URL."
            }
            val arr = JSONArray().apply {
                history.takeLast(12).forEach { (r, c) ->
                    put(JSONObject().put("role", r).put("content", c))
                }
            }
            val body = JSONObject()
                .put("prompt", prompt)
                .put("history", arr)
                .put("routingPolicy", routingPolicy)

            val builder = Request.Builder()
                .url("$cleanBase/api/v1/chat")
                .post(body.toString().toRequestBody(jsonMediaType))
            if (!bearerToken.isNullOrBlank()) {
                builder.addHeader("Authorization", "Bearer $bearerToken")
            }
            httpClient.newCall(builder.build()).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Backend /api/v1/chat HTTP ${resp.code}: ${raw.take(200)}")
                }
                JSONObject(raw).optString("response").ifBlank {
                    throw IllegalStateException("Backend returned empty response.")
                }
            }
        }
    }
}

class ConnectorProbeClient(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()
) {
    suspend fun testConnector(
        connector: ConnectorIntegration,
        token: String?
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        if (!connector.isSupportedOfficially) {
            return@withContext false to "Unsupported: ${connector.providerKey} lacks an official public OAuth/REST sync API."
        }
        val url = connector.endpointOrScope.trim()
        if (url.isBlank() || (!url.startsWith("https://") && !url.startsWith("http://"))) {
            return@withContext false to "Configure a valid HTTPS endpoint URL first."
        }
        return@withContext try {
            val reqBuilder = Request.Builder().url(url).head()
            if (!token.isNullOrBlank()) {
                reqBuilder.addHeader("Authorization", "Bearer $token")
            }
            httpClient.newCall(reqBuilder.build()).execute().use { resp ->
                val ok = resp.code in 200..405
                ok to "HTTP ${resp.code} from ${connector.displayName}"
            }
        } catch (e: Exception) {
            false to "Probe failed: ${e.localizedMessage ?: "Unreachable"}"
        }
    }
}

/**
 * Executes JAMES's 13-step SHA-256 verified repository migration workflow on local staging snapshots
 * (and flags source deletion for mandatory separate secondary human approval).
 */
class RepositoryMigrationEngine(
    private val repository: EcosystemRepository
) {
    suspend fun executeVerifiedStagingMigration(
        stagingDir: File,
        sourceLabel: String,
        targetLabel: String,
        payloads: Map<String, String>
    ): MigrationRecord = withContext(Dispatchers.IO) {
        val migrationId = "mig_${UUID.randomUUID().toString().replace("-", "").take(10)}"
        val runFolder = File(stagingDir, "migration_$migrationId")
        val targetFolder = File(runFolder, "target_verified")
        targetFolder.mkdirs()

        // Step 1-3: Inventory & pre-transfer SHA-256 manifest
        val sourceChecksums = mutableMapOf<String, String>()
        payloads.forEach { (name, content) ->
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            sourceChecksums[safeName] = KnowledgeRetrievalEngine.sha256Hex(content)
        }
        val manifestText = sourceChecksums.entries.sortedBy { it.key }
            .joinToString("\n") { "${it.key}:${it.value}" }
        val manifestSha = KnowledgeRetrievalEngine.sha256Hex(manifestText)

        // Step 4-7: Write & re-read target checksums to verify byte integrity
        var verifiedCount = 0
        val mismatches = mutableListOf<String>()
        payloads.forEach { (name, content) ->
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val destFile = File(targetFolder, safeName)
            destFile.writeText(content, StandardCharsets.UTF_8)
            val actualHash = KnowledgeRetrievalEngine.sha256Hex(destFile.readText(StandardCharsets.UTF_8))
            if (actualHash == sourceChecksums[safeName]) {
                verifiedCount++
            } else {
                mismatches.add(safeName)
            }
        }

        // Step 8-12: Write manifest + status; keep source intact pending separate deletion approval
        File(runFolder, "manifest.sha256").writeText(manifestText, StandardCharsets.UTF_8)
        val status = if (mismatches.isEmpty()) "VERIFIED_AWAITING_DELETE_APPROVAL" else "ROLLED_BACK_MISMATCH"
        if (mismatches.isNotEmpty()) {
            targetFolder.deleteRecursively()
        }

        val record = MigrationRecord(
            id = migrationId,
            sourceProvider = sourceLabel,
            targetProvider = targetLabel,
            status = status,
            totalFiles = payloads.size,
            transferredFiles = verifiedCount,
            checksumManifestSha256 = manifestSha,
            reportSummary = if (mismatches.isEmpty()) {
                "Verified $verifiedCount/${payloads.size} files with SHA-256 manifest (${manifestSha.take(12)}). Original source remains untouched pending secondary human deletion approval."
            } else {
                "Checksum mismatch on ${mismatches.joinToString()}; rolled back target staging cleanly."
            },
            sourceDeleteApproved = false,
            createdAtMillis = System.currentTimeMillis()
        )
        repository.saveMigrationRecord(record)
        repository.addLog("INFO", "Migration", record.reportSummary)
        record
    }

    suspend fun rollbackMigration(record: MigrationRecord): MigrationRecord {
        val updated = record.copy(
            status = "ROLLED_BACK_BY_USER",
            reportSummary = "${record.reportSummary} | Rolled back by user at ${System.currentTimeMillis()}."
        )
        repository.saveMigrationRecord(updated)
        repository.addLog("WARN", "Migration", "Migration ${record.id} rolled back by user.")
        return updated
    }

    suspend fun approveSourceCleanup(record: MigrationRecord): MigrationRecord {
        require(record.status == "VERIFIED_AWAITING_DELETE_APPROVAL") {
            "Source cleanup requires VERIFIED_AWAITING_DELETE_APPROVAL status first."
        }
        val updated = record.copy(
            status = "COMPLETED_AND_SOURCE_ARCHIVED",
            sourceDeleteApproved = true,
            reportSummary = "${record.reportSummary} | Secondary approval granted for source archival."
        )
        repository.saveMigrationRecord(updated)
        repository.addLog("INFO", "Migration", "Secondary approval granted for migration ${record.id}.")
        return updated
    }
}

/**
 * Bounded Continuous Learning Analyzer: inspects recorded experiences, identifies recurring gaps/errors,
 * updates stale knowledge verification status, and saves synthesized lessons.
 */
class LearningOrchestrator(
    private val repository: EcosystemRepository
) {
    suspend fun recordInteractionOutcome(
        taskSummary: String,
        outcomeType: ExperienceOutcomeType,
        rootCause: String,
        lessonLearned: String,
        relatedSkillId: String? = null
    ): LearningExperience {
        val exp = LearningExperience(
            id = "exp_${UUID.randomUUID().toString().replace("-", "").take(12)}",
            taskSummary = PrivateVaultManager.redactSecrets(taskSummary).take(220),
            outcomeType = outcomeType,
            rootCause = PrivateVaultManager.redactSecrets(rootCause).take(300),
            lessonLearned = PrivateVaultManager.redactSecrets(lessonLearned).take(400),
            relatedSkillId = relatedSkillId,
            createdAtMillis = System.currentTimeMillis()
        )
        repository.saveExperience(exp)
        return exp
    }

    suspend fun runBoundedLearningCycle(maxBudgetTokens: Int = 2500): String {
        val experiences = repository.getExperiencesOnce()
        val knowledge = repository.getKnowledgeOnce()
        val now = System.currentTimeMillis()

        val errors = experiences.count { it.outcomeType == ExperienceOutcomeType.ERROR }
        val gaps = experiences.count { it.outcomeType == ExperienceOutcomeType.GAP }
        val staleThresholdMs = 30L * 24L * 3600_000L
        var flaggedOutdated = 0

        knowledge.forEach { item ->
            if (item.validationStatus == ValidationStatus.VERIFIED &&
                (now - item.lastVerifiedAtMillis) > staleThresholdMs
            ) {
                repository.saveKnowledgeItem(item.copy(validationStatus = ValidationStatus.OUTDATED))
                flaggedOutdated++
            }
        }

        val summary = buildString {
            append("Evaluated ${experiences.size} experience(s) ($errors error(s), $gaps knowledge gap(s)) ")
            append("within $maxBudgetTokens-token budget; flagged $flaggedOutdated stale knowledge entry(s).")
        }
        repository.addLog("INFO", "LearningEngine", summary)
        return summary
    }
}
