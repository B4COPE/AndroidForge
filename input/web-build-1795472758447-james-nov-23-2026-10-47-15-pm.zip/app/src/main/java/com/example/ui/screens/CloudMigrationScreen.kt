package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CloudHostingCatalog
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloudMigrationScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val settings by ecosystemViewModel.settings.collectAsStateWithLifecycle()
    val migrations by ecosystemViewModel.migrations.collectAsStateWithLifecycle()
    val scheduledJobs by ecosystemViewModel.scheduledJobs.collectAsStateWithLifecycle()
    val isBusy by ecosystemViewModel.isBusy.collectAsStateWithLifecycle()
    val banner by ecosystemViewModel.statusBanner.collectAsStateWithLifecycle()

    var backendUrlInput by remember(settings.backendBaseUrl) { mutableStateOf(settings.backendBaseUrl) }
    var backendTokenInput by remember { mutableStateOf("") }
    var backendEnabled by remember(settings.useCloudBackendWhenAvailable) { mutableStateOf(settings.useCloudBackendWhenAvailable) }
    var sourceTarget by remember { mutableStateOf("Local Android Room Repository") }
    var destTarget by remember { mutableStateOf("WebDAV / Nextcloud / OCI S3 Staging") }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.cloudAndMigration) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("cloud_migration_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (isBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                banner?.let { msg ->
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { ecosystemViewModel.dismissBanner() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // 1. JAMES Independent Cloud Core Backend Connection
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("JAMES Independent Cloud Core Backend", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(
                            "Deploy backend/ on Oracle Cloud Always Free ARM VM (24 GB RAM) or Docker, then connect Android over HTTPS.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = backendUrlInput,
                            onValueChange = { backendUrlInput = it },
                            label = { Text("Cloud Core Backend URL (https://... or http://10.0.2.2:8787)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = backendTokenInput,
                            onValueChange = { backendTokenInput = it },
                            label = { Text("Backend Bearer Auth Token (stored encrypted in Vault)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = backendEnabled, onCheckedChange = { backendEnabled = it })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Prefer Cloud Backend Delegation When Online", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(
                            onClick = {
                                ecosystemViewModel.saveAndTestBackend(backendUrlInput, backendTokenInput, backendEnabled)
                                backendTokenInput = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Save & Health-Check Cloud Backend") }
                    }
                }

                // 2. Cloud Hosting Technical Comparison
                Text("Always-Free & Cloud Hosting Architecture Matrix", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                CloudHostingCatalog.options.forEach { opt ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(opt.name, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                            Text("Compute: ${opt.cpuAndRam}", style = MaterialTheme.typography.bodySmall)
                            Text("Storage: ${opt.storageAndNetwork}", style = MaterialTheme.typography.bodySmall)
                            Text("Fit: ${opt.backgroundSuitability}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            Text("Caveat: ${opt.caveats}", style = MaterialTheme.typography.labelSmall, color = StatusWarning)
                        }
                    }
                }

                // 3. 13-Step SHA-256 Verified Migration Center
                Text("Cloud Migration Center (13-Step SHA-256 Verified)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = sourceTarget, onValueChange = { sourceTarget = it }, label = { Text("Source Repository") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = destTarget, onValueChange = { destTarget = it }, label = { Text("Destination Target") }, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = { ecosystemViewModel.runStagingMigration(sourceTarget, destTarget) },
                            enabled = !isBusy,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Verified, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run Checksum-Verified Migration Staging")
                        }
                    }
                }
                migrations.forEach { mig ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${mig.sourceProvider} -> ${mig.targetProvider}", style = MaterialTheme.typography.titleSmall)
                            Text("Status: ${mig.status} · Files: ${mig.transferredFiles}/${mig.totalFiles}", style = MaterialTheme.typography.labelSmall, color = StatusSuccess)
                            Text("Manifest SHA-256: ${mig.checksumManifestSha256.take(24)}...", style = MaterialTheme.typography.labelSmall)
                            Text(mig.reportSummary, style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (!mig.sourceDeleteApproved && mig.status == "VERIFIED_AWAITING_DELETE_APPROVAL") {
                                    Button(onClick = { ecosystemViewModel.approveMigrationSourceCleanup(mig) }) {
                                        Text("Secondary Approval: Archive Source")
                                    }
                                }
                                OutlinedButton(onClick = { ecosystemViewModel.rollbackMigration(mig) }) {
                                    Icon(Icons.Rounded.Replay, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Rollback")
                                }
                            }
                        }
                    }
                }

                // 4. Bounded Automation & Scheduler
                Text("Bounded Background Scheduler", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                scheduledJobs.forEach { job ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(job.name, style = MaterialTheme.typography.titleSmall)
                                    Text("Every ${job.intervalHours}h · Max ${job.maxBudgetTokens} tokens · Status: ${job.lastStatus}", style = MaterialTheme.typography.labelSmall)
                                }
                                Switch(checked = job.enabled, onCheckedChange = { ecosystemViewModel.toggleScheduledJob(job) })
                            }
                            Text(job.lastSummary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            OutlinedButton(onClick = { ecosystemViewModel.runScheduledJobNow(job) }) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Run Bounded Cycle Now")
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
