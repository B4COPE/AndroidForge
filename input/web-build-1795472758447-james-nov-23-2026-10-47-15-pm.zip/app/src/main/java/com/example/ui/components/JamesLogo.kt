package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun JamesLogoMark(
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    animated: Boolean = true
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val infiniteTransition = rememberInfiniteTransition(label = "james_orbit")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbit_angle"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.72f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    val effectiveAngle = if (animated) angle else 28f
    val effectivePulse = if (animated) pulse else 0.9f

    Box(
        modifier = modifier
            .size(size)
            .semantics { contentDescription = "JAMES emblem" },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val cx = w / 2f
            val cy = h / 2f
            val r = minOf(w, h) * 0.44f

            // Outer subtle orbital ring
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        primary.copy(alpha = 0.15f),
                        primary.copy(alpha = 0.85f),
                        secondary.copy(alpha = 0.4f),
                        primary.copy(alpha = 0.15f)
                    )
                ),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = w * 0.045f)
            )

            // Rotating orbital node
            rotate(effectiveAngle, pivot = Offset(cx, cy)) {
                drawCircle(
                    color = primary,
                    radius = w * 0.055f,
                    center = Offset(cx + r, cy)
                )
            }

            // Inner geometric J monogram
            val stroke = Stroke(
                width = w * 0.085f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
            val jPath = Path().apply {
                moveTo(cx - r * 0.25f, cy - r * 0.42f)
                lineTo(cx + r * 0.34f, cy - r * 0.42f)
                lineTo(cx + r * 0.16f, cy + r * 0.28f)
                lineTo(cx - r * 0.08f, cy + r * 0.48f)
                lineTo(cx - r * 0.36f, cy + r * 0.24f)
            }
            drawPath(
                path = jPath,
                brush = Brush.linearGradient(
                    colors = listOf(Color.White.copy(alpha = effectivePulse), primary)
                ),
                style = stroke
            )
        }
    }
}
