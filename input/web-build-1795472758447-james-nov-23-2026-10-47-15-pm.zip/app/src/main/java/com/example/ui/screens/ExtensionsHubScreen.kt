package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.McpTransport
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExtensionsHubScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val settings by ecosystemViewModel.settings.collectAsStateWithLifecycle()
    val skills by ecosystemViewModel.skills.collectAsStateWithLifecycle()
    val mcpServers by ecosystemViewModel.mcpServers.collectAsStateWithLifecycle()
    val connectors by ecosystemViewModel.connectors.collectAsStateWithLifecycle()
    val isBusy by ecosystemViewModel.isBusy.collectAsStateWithLifecycle()
    val banner by ecosystemViewModel.statusBanner.collectAsStateWithLifecycle()

    var skillName by remember { mutableStateOf("") }
    var skillMd by remember { mutableStateOf("") }
    var mcpName by remember { mutableStateOf("") }
    var mcpUrl by remember { mutableStateOf("") }
    var mcpToken by remember { mutableStateOf("") }
    var mcpTransport by remember { mutableStateOf(McpTransport.STREAMABLE_HTTP) }
    var mcpApprovalRequired by remember { mutableStateOf(true) }

    var connectorEndpointEdits by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var connectorTokenEdits by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.skillsAndMcp) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("extensions_hub_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (isBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                banner?.let { msg ->
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { ecosystemViewModel.dismissBanner() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // 1. Skills Manager (Distinct from MCP & Connectors)
                Text("1. Skills Manager (SKILL.md Inspected Capabilities)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Allow Skill Script Blocks (Strict Gate)", style = MaterialTheme.typography.labelLarge)
                                Text("Disabled by default. Executable shell/code skills are flagged if disabled.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Switch(
                                checked = settings.allowSkillScriptExecution,
                                onCheckedChange = { ecosystemViewModel.setAllowSkillScripts(it) }
                            )
                        }
                        OutlinedTextField(value = skillName, onValueChange = { skillName = it }, label = { Text("Skill Name") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = skillMd, onValueChange = { skillMd = it }, label = { Text("Paste SKILL.md content (inspected before enabling)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                ecosystemViewModel.importSkill(skillName, skillMd, "Custom")
                                skillName = ""
                                skillMd = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Inspect & Import SKILL.md")
                        }
                    }
                }
                skills.forEach { sk ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${sk.name} (v${sk.version})", style = MaterialTheme.typography.titleSmall)
                                Text(sk.description, style = MaterialTheme.typography.bodySmall)
                                Text(
                                    text = "${sk.inspectionNotes} · Perms: ${sk.permissionsCsv}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (sk.inspected) StatusSuccess else StatusWarning
                                )
                            }
                            Switch(checked = sk.enabled, onCheckedChange = { ecosystemViewModel.toggleSkill(sk) })
                        }
                    }
                }

                // 2. MCP Manager (Model Context Protocol — Distinct Standard Protocol)
                Text("2. MCP Client (Streamable HTTP / HTTP+SSE)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Note: Android devices cannot directly spawn desktop STDIO processes. Use Streamable HTTP / HTTP+SSE endpoints or a remote HTTPS STDIO bridge.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            McpTransport.entries.forEach { tr ->
                                FilterChip(selected = mcpTransport == tr, onClick = { mcpTransport = tr }, label = { Text(tr.label) })
                            }
                        }
                        OutlinedTextField(value = mcpName, onValueChange = { mcpName = it }, label = { Text("MCP Server Name") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = mcpUrl, onValueChange = { mcpUrl = it }, label = { Text("HTTPS Endpoint URL") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(
                            value = mcpToken,
                            onValueChange = { mcpToken = it },
                            label = { Text("Bearer Token (stored encrypted in Private Vault, optional)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = mcpApprovalRequired, onCheckedChange = { mcpApprovalRequired = it })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Require Explicit Confirmation Before Tool Call", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(
                            onClick = {
                                ecosystemViewModel.saveMcpServer(mcpName, mcpTransport, mcpUrl, mcpApprovalRequired, mcpToken)
                                mcpName = ""
                                mcpUrl = ""
                                mcpToken = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Add MCP Server") }
                    }
                }
                mcpServers.forEach { srv ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${srv.name} · ${srv.transport.label}", style = MaterialTheme.typography.titleSmall)
                            Text("URL: ${srv.endpointUrl} · Status: ${srv.status}", style = MaterialTheme.typography.bodySmall)
                            Text("Tools: ${srv.discoveredToolsSummary}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            OutlinedButton(onClick = { ecosystemViewModel.discoverMcpTools(srv) }) {
                                Icon(Icons.Rounded.Search, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Discover Tools (tools/list)")
                            }
                        }
                    }
                }

                // 3. Cloud & Developer Connectors (Distinct from Skills & MCP)
                Text("3. Cloud Storage & Service Connectors", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                connectors.forEach { conn ->
                    val endpointVal = connectorEndpointEdits[conn.id] ?: conn.endpointOrScope
                    val tokenVal = connectorTokenEdits[conn.id] ?: ""
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (conn.isSupportedOfficially) MaterialTheme.colorScheme.outlineVariant else StatusWarning.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(conn.displayName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                                Text(
                                    text = if (conn.isSupportedOfficially) conn.authMode else "Officially Unsupported",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (conn.isSupportedOfficially) MaterialTheme.colorScheme.primary else StatusWarning
                                )
                            }
                            Text(conn.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Status: ${conn.status}", style = MaterialTheme.typography.labelSmall)
                            if (conn.isSupportedOfficially) {
                                OutlinedTextField(
                                    value = endpointVal,
                                    onValueChange = { connectorEndpointEdits = connectorEndpointEdits + (conn.id to it) },
                                    label = { Text("Endpoint URL") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = tokenVal,
                                    onValueChange = { connectorTokenEdits = connectorTokenEdits + (conn.id to it) },
                                    label = { Text("OAuth / PAT Token (saved encrypted)") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedButton(onClick = {
                                    ecosystemViewModel.testConnector(conn, endpointVal, tokenVal)
                                    connectorTokenEdits = connectorTokenEdits - conn.id
                                }) { Text("Save & Probe Connector") }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
