package com.example.data.ai

import android.util.Log
import com.example.data.local.JamesSettings
import com.example.data.local.ResponseLength
import com.example.data.local.ResponseStyle
import com.example.data.model.AttachmentType
import com.example.data.model.ChatMessage
import com.example.data.model.MemoryItem
import com.example.data.model.PendingAttachment
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

class GeminiAiService {

    private fun buildModel(
        settings: JamesSettings,
        memories: List<MemoryItem>,
        priorSummary: String
    ): GenerativeModel {
        val modelSpec = GeminiModelCatalog.resolveValidModel(settings.selectedModel)
        val systemText = buildSystemInstruction(settings, memories, priorSummary)
        val config = generationConfig {
            temperature = settings.temperature.coerceIn(0f, 2f)
            topP = settings.topP.coerceIn(0.1f, 1f)
        }
        return Firebase.ai.generativeModel(
            modelName = modelSpec.id,
            generationConfig = config,
            systemInstruction = content { text(systemText) }
        )
    }

    private fun buildSystemInstruction(
        settings: JamesSettings,
        memories: List<MemoryItem>,
        priorSummary: String
    ): String {
        val sb = StringBuilder()
        sb.appendLine("You are JAMES, an independent, intelligent, minimalist, and trustworthy personal AI assistant.")
        sb.appendLine("Core Principles:")
        sb.appendLine("- Understand full conversational context and user intent.")
        sb.appendLine("- Be accurate, transparent, and honest. Never invent facts, files, or capabilities.")
        sb.appendLine("- Clearly distinguish confirmed facts from assumptions or estimates.")
        sb.appendLine("- Never claim to remember personal facts unless they appear in the Confirmed User Memories section below or in this conversation.")
        sb.appendLine("- Never claim to have inspected an attachment if no attachment data was provided.")
        sb.appendLine("- Format structured answers cleanly using Markdown headings, lists, tables, and fenced code blocks with language tags.")

        sb.appendLine()
        sb.appendLine("Communication Preferences:")
        when (settings.responseLength) {
            ResponseLength.CONCISE -> sb.appendLine("- Response Length: Concise and high-signal. Avoid fluff.")
            ResponseLength.BALANCED -> sb.appendLine("- Response Length: Balanced — clear and thorough without unnecessary verbosity.")
            ResponseLength.DETAILED -> sb.appendLine("- Response Length: Detailed and comprehensive, with examples and step-by-step clarity.")
        }
        when (settings.responseStyle) {
            ResponseStyle.FORMAL -> sb.appendLine("- Tone: Formal, executive, and precise.")
            ResponseStyle.NATURAL -> sb.appendLine("- Tone: Natural, calm, intelligent, and professional.")
            ResponseStyle.CASUAL -> sb.appendLine("- Tone: Warm, conversational, and approachable while remaining sharp.")
        }
        when (settings.preferredResponseLanguage) {
            "ar" -> sb.appendLine("- Preferred Language: Always respond in clear Modern Standard Arabic unless asked otherwise.")
            "en" -> sb.appendLine("- Preferred Language: Always respond in English unless asked otherwise.")
            else -> sb.appendLine("- Preferred Language: Match the language of the user's message (English, Arabic, etc.).")
        }

        if (settings.customInstructions.isNotBlank()) {
            sb.appendLine()
            sb.appendLine("User Custom Instructions:")
            sb.appendLine(settings.customInstructions.trim().take(2000))
        }

        if (settings.memoryEnabled && memories.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("Confirmed User Memories (user-approved):")
            memories.take(40).forEach { mem ->
                sb.appendLine("- [${mem.category.labelEn}] ${mem.content}")
            }
        }

        if (priorSummary.isNotBlank()) {
            sb.appendLine()
            sb.appendLine("Summary of Earlier Turns in This Conversation:")
            sb.appendLine(priorSummary)
        }

        return sb.toString()
    }

    fun streamResponse(
        historyMessages: List<ChatMessage>,
        userPrompt: String,
        attachment: PendingAttachment?,
        settings: JamesSettings,
        memories: List<MemoryItem>,
        priorSummary: String
    ): Flow<String> = flow {
        val model = buildModel(settings, memories, priorSummary)

        // Trim conversation window to configured turn limit so long threads remain fast & bounded
        val windowed = historyMessages
            .filter { !it.isError && it.content.isNotBlank() }
            .takeLast(settings.contextTurnLimit.coerceIn(4, 50))

        val sdkHistory = mutableListOf<Content>()
        for (msg in windowed) {
            val role = if (msg.role == "user") "user" else "model"
            // Ensure alternating or valid sequence; append attachment notice if present
            val textBody = if (msg.attachmentName != null) {
                "[Attached file: ${msg.attachmentName}]\n${msg.content}"
            } else {
                msg.content
            }
            sdkHistory.add(content(role) { text(textBody) })
        }

        val userContent = content("user") {
            if (attachment != null) {
                when (attachment.type) {
                    AttachmentType.IMAGE -> {
                        attachment.previewBitmap?.let { bmp ->
                            image(bmp)
                        }
                    }
                    AttachmentType.PDF -> {
                        val bytes = attachment.pdfBytes
                        if (bytes != null && bytes.isNotEmpty()) {
                            inlineData(bytes, "application/pdf")
                        }
                    }
                    AttachmentType.TEXT -> {
                        val docText = attachment.textContent.orEmpty()
                        if (docText.isNotBlank()) {
                            text("Attached document (${attachment.name}):\n```\n${docText.take(45_000)}\n```\n")
                        }
                    }
                }
            }
            text(userPrompt.ifBlank { "Please analyze the attached file." })
        }

        val chat = model.startChat(history = sdkHistory)
        val accumulated = StringBuilder()

        try {
            withTimeout(AI_TIMEOUT_MS) {
                chat.sendMessageStream(userContent).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("The AI model returned an empty response. Please try again.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI generation timed out after 60s", e)
            throw IllegalStateException("Response timed out after 60 seconds. Check your connection or try a shorter prompt.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI Logic generation error", e)
            throw mapFriendlyAiError(e)
        }
    }

    /**
     * Compacts older conversation turns into a concise memory-safe summary string
     * when a thread exceeds the context window limit.
     */
    suspend fun summarizeOlderMessages(
        olderMessages: List<ChatMessage>,
        existingSummary: String
    ): String {
        if (olderMessages.isEmpty()) return existingSummary
        val model by lazy {
            Firebase.ai.generativeModel(modelName = "gemini-3.5-flash-lite")
        }
        val transcript = buildString {
            if (existingSummary.isNotBlank()) {
                appendLine("Previous summary: $existingSummary")
            }
            olderMessages.takeLast(20).forEach { msg ->
                appendLine("${msg.role.uppercase()}: ${msg.content.take(500)}")
            }
        }
        return try {
            withTimeout(30_000L) {
                val resp = model.generateContent(
                    "Summarize the key facts, decisions, and open context from this conversation segment in 4-6 concise bullet points:\n\n$transcript"
                )
                resp.text?.trim().orEmpty().ifBlank { existingSummary }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Context summarization skipped: ${e.message}")
            existingSummary
        }
    }

    private fun mapFriendlyAiError(e: Exception): Exception {
        val raw = e.localizedMessage ?: e.toString()
        val lower = raw.lowercase()
        val message = when {
            "403" in lower || "app check" in lower || "attestation" in lower ->
                "App Check attestation failed (HTTP 403). Ensure Firebase App Check is provisioned and play/device integrity is available. ($raw)"
            "429" in lower || "quota" in lower || "resource_exhausted" in lower ->
                "Free-tier AI quota limit reached or rate limited. Please wait a moment and try again, or switch to Gemini 3.5 Flash-Lite in AI Settings."
            "billing" in lower || "permission" in lower ->
                "The selected model may require Firebase Blaze billing or additional project permissions. Try Gemini 3.8 Flash in AI Settings. ($raw)"
            "network" in lower || "unable to resolve host" in lower || "failed to connect" in lower ->
                "Unable to reach AI servers. Please verify your internet connection."
            else -> raw
        }
        return IllegalStateException(message, e)
    }

    companion object {
        private const val TAG = "GeminiAiService"
        private const val AI_TIMEOUT_MS = 60_000L
    }
}
