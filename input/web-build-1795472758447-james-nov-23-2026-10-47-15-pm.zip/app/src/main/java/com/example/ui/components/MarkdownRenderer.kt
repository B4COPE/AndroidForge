package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJamesColors
import kotlinx.coroutines.delay

private sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class BulletItem(val text: String) : MdBlock
    data class NumberedItem(val number: String, val text: String) : MdBlock
    data class Blockquote(val text: String) : MdBlock
    data class CodeBlock(val language: String, val code: String) : MdBlock
    data class TableBlock(val headers: List<String>, val rows: List<List<String>>) : MdBlock
    data object Divider : MdBlock
}

@Composable
fun MarkdownTextContent(
    markdown: String,
    textColor: Color = MaterialTheme.colorScheme.onSurface,
    modifier: Modifier = Modifier
) {
    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }
    val primary = MaterialTheme.colorScheme.primary
    val jamesColors = LocalJamesColors.current

    SelectionContainer(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            blocks.forEach { block ->
                when (block) {
                    is MdBlock.Heading -> {
                        val style = when (block.level) {
                            1 -> MaterialTheme.typography.titleLarge
                            2 -> MaterialTheme.typography.titleMedium
                            else -> MaterialTheme.typography.titleSmall
                        }
                        Text(
                            text = parseInlineMarkdown(block.text, primary, jamesColors.codeBackground),
                            style = style.copy(fontWeight = FontWeight.Bold),
                            color = textColor
                        )
                    }

                    is MdBlock.Paragraph -> {
                        Text(
                            text = parseInlineMarkdown(block.text, primary, jamesColors.codeBackground),
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor
                        )
                    }

                    is MdBlock.BulletItem -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = "•",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                color = primary,
                                modifier = Modifier.padding(end = 8.dp, start = 4.dp)
                            )
                            Text(
                                text = parseInlineMarkdown(block.text, primary, jamesColors.codeBackground),
                                style = MaterialTheme.typography.bodyLarge,
                                color = textColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    is MdBlock.NumberedItem -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = "${block.number}.",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = primary,
                                modifier = Modifier.padding(end = 8.dp, start = 2.dp)
                            )
                            Text(
                                text = parseInlineMarkdown(block.text, primary, jamesColors.codeBackground),
                                style = MaterialTheme.typography.bodyLarge,
                                color = textColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    is MdBlock.Blockquote -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min)
                                .clip(RoundedCornerShape(8.dp))
                                .background(primary.copy(alpha = 0.08f))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(20.dp)
                                    .background(primary, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = parseInlineMarkdown(block.text, primary, jamesColors.codeBackground),
                                style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                                color = textColor.copy(alpha = 0.9f)
                            )
                        }
                    }

                    is MdBlock.CodeBlock -> {
                        CodeBlockCard(language = block.language, code = block.code)
                    }

                    is MdBlock.TableBlock -> {
                        MarkdownTable(headers = block.headers, rows = block.rows, textColor = textColor)
                    }

                    MdBlock.Divider -> {
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeBlockCard(language: String, code: String) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    val jamesColors = LocalJamesColors.current
    val highlighted = remember(code, language) { highlightCodeSyntax(code, language) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1800)
            copied = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(jamesColors.codeBackground)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White.copy(alpha = 0.05f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = language.ifBlank { "code" }.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(
                onClick = {
                    clipboard.setText(AnnotatedString(code))
                    copied = true
                },
                modifier = Modifier
                    .size(32.dp)
                    .testTag("copy_code_button")
            ) {
                Icon(
                    imageVector = if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                    contentDescription = if (copied) "Copied code" else "Copy code",
                    tint = if (copied) MaterialTheme.colorScheme.primary else Color(0xFFCBD5E1),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = highlighted,
                fontFamily = JetBrainsMonoFontFamily,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun MarkdownTable(
    headers: List<String>,
    rows: List<List<String>>,
    textColor: Color
) {
    val borderColor = MaterialTheme.colorScheme.outline
    val headerBg = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, borderColor, RoundedCornerShape(10.dp))
        ) {
            Row(modifier = Modifier.background(headerBg)) {
                headers.forEach { header ->
                    Text(
                        text = header,
                        style = MaterialTheme.typography.labelLarge,
                        color = textColor,
                        modifier = Modifier
                            .widthIn(min = 100.dp, max = 220.dp)
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }
            rows.forEachIndexed { idx, row ->
                HorizontalDivider(color = borderColor.copy(alpha = 0.6f))
                Row(
                    modifier = Modifier.background(
                        if (idx % 2 == 1) Color.White.copy(alpha = 0.02f) else Color.Transparent
                    )
                ) {
                    headers.indices.forEach { colIdx ->
                        val cell = row.getOrElse(colIdx) { "" }
                        Text(
                            text = cell,
                            style = MaterialTheme.typography.bodyMedium,
                            color = textColor,
                            modifier = Modifier
                                .widthIn(min = 100.dp, max = 220.dp)
                                .padding(horizontal = 10.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun parseMarkdownBlocks(input: String): List<MdBlock> {
    val lines = input.replace("\r\n", "\n").split("\n")
    val blocks = mutableListOf<MdBlock>()
    var i = 0

    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()

        if (trimmed.isEmpty()) {
            i++
            continue
        }

        // Fenced code block
        if (trimmed.startsWith("```")) {
            val lang = trimmed.removePrefix("```").trim()
            val codeLines = mutableListOf<String>()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                codeLines.add(lines[i])
                i++
            }
            if (i < lines.size) i++ // consume closing fence
            blocks.add(MdBlock.CodeBlock(lang, codeLines.joinToString("\n")))
            continue
        }

        // Divider
        if (trimmed == "---" || trimmed == "***" || trimmed == "___") {
            blocks.add(MdBlock.Divider)
            i++
            continue
        }

        // Headings
        val headingMatch = Regex("^(#{1,4})\\s+(.+)$").find(trimmed)
        if (headingMatch != null) {
            val level = headingMatch.groupValues[1].length
            val text = headingMatch.groupValues[2]
            blocks.add(MdBlock.Heading(level, text))
            i++
            continue
        }

        // Markdown table
        if (trimmed.startsWith("|") && i + 1 < lines.size &&
            lines[i + 1].trim().matches(Regex("^\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)+\\|?$"))
        ) {
            val headers = splitTableRow(trimmed)
            i += 2
            val rows = mutableListOf<List<String>>()
            while (i < lines.size && lines[i].trim().startsWith("|")) {
                rows.add(splitTableRow(lines[i].trim()))
                i++
            }
            blocks.add(MdBlock.TableBlock(headers, rows))
            continue
        }

        // Blockquote
        if (trimmed.startsWith(">")) {
            val quoteLines = mutableListOf<String>()
            while (i < lines.size && lines[i].trim().startsWith(">")) {
                quoteLines.add(lines[i].trim().removePrefix(">").trimStart())
                i++
            }
            blocks.add(MdBlock.Blockquote(quoteLines.joinToString("\n")))
            continue
        }

        // Bullet list
        if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
            blocks.add(MdBlock.BulletItem(trimmed.drop(2).trimStart()))
            i++
            continue
        }

        // Numbered list
        val numMatch = Regex("^(\\d+)\\.\\s+(.+)$").find(trimmed)
        if (numMatch != null) {
            blocks.add(MdBlock.NumberedItem(numMatch.groupValues[1], numMatch.groupValues[2]))
            i++
            continue
        }

        // Paragraph (accumulate consecutive plain lines)
        val paraLines = mutableListOf<String>()
        while (i < lines.size) {
            val cur = lines[i].trim()
            if (cur.isEmpty() ||
                cur.startsWith("```") ||
                cur.startsWith("#") ||
                cur.startsWith(">") ||
                cur.startsWith("- ") ||
                cur.startsWith("* ") ||
                cur.startsWith("|") ||
                cur == "---" ||
                Regex("^\\d+\\.\\s+.*").matches(cur)
            ) {
                break
            }
            paraLines.add(lines[i])
            i++
        }
        if (paraLines.isNotEmpty()) {
            blocks.add(MdBlock.Paragraph(paraLines.joinToString("\n")))
        } else {
            blocks.add(MdBlock.Paragraph(line))
            i++
        }
    }

    return blocks
}

private fun splitTableRow(row: String): List<String> =
    row.trim().trim('|').split("|").map { it.trim() }

private fun parseInlineMarkdown(
    text: String,
    accentColor: Color,
    codeBg: Color
): AnnotatedString {
    return buildAnnotatedString {
        var idx = 0
        while (idx < text.length) {
            when {
                text.startsWith("**", idx) -> {
                    val end = text.indexOf("**", idx + 2)
                    if (end != -1) {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(text.substring(idx + 2, end))
                        }
                        idx = end + 2
                    } else {
                        append("**")
                        idx += 2
                    }
                }
                text.startsWith("`", idx) -> {
                    val end = text.indexOf('`', idx + 1)
                    if (end != -1) {
                        withStyle(
                            SpanStyle(
                                fontFamily = JetBrainsMonoFontFamily,
                                color = accentColor,
                                background = codeBg.copy(alpha = 0.65f)
                            )
                        ) {
                            append(" ${text.substring(idx + 1, end)} ")
                        }
                        idx = end + 1
                    } else {
                        append('`')
                        idx++
                    }
                }
                text.startsWith("*", idx) && !text.startsWith("**", idx) -> {
                    val end = text.indexOf('*', idx + 1)
                    if (end != -1 && end > idx + 1) {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append(text.substring(idx + 1, end))
                        }
                        idx = end + 1
                    } else {
                        append('*')
                        idx++
                    }
                }
                text.startsWith("~~", idx) -> {
                    val end = text.indexOf("~~", idx + 2)
                    if (end != -1) {
                        withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) {
                            append(text.substring(idx + 2, end))
                        }
                        idx = end + 2
                    } else {
                        append("~~")
                        idx += 2
                    }
                }
                else -> {
                    append(text[idx])
                    idx++
                }
            }
        }
    }
}

private fun highlightCodeSyntax(code: String, language: String): AnnotatedString {
    val keywords = setOf(
        "fun", "val", "var", "class", "interface", "object", "data", "sealed", "enum",
        "if", "else", "when", "for", "while", "return", "import", "package", "private",
        "public", "internal", "override", "suspend", "launch", "async", "try", "catch",
        "finally", "throw", "true", "false", "null", "def", "from", "const", "let",
        "function", "export", "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE"
    )
    val baseColor = Color(0xFFE2E8F0)
    val keywordColor = Color(0xFF38BDF8)
    val stringColor = Color(0xFF34D399)
    val commentColor = Color(0xFF64748B)
    val numberColor = Color(0xFFFBBF24)
    val annotationColor = Color(0xFFC084FC)

    return buildAnnotatedString {
        val lines = code.split("\n")
        lines.forEachIndexed { lineIdx, line ->
            val trimmed = line.trimStart()
            if (trimmed.startsWith("//") || (trimmed.startsWith("#") && language.lowercase() in listOf("python", "py", "bash", "sh", "yaml"))) {
                withStyle(SpanStyle(color = commentColor, fontStyle = FontStyle.Italic)) {
                    append(line)
                }
            } else {
                var i = 0
                while (i < line.length) {
                    val ch = line[i]
                    when {
                        ch == '"' || ch == '\'' -> {
                            val quote = ch
                            var j = i + 1
                            while (j < line.length && line[j] != quote) {
                                if (line[j] == '\\' && j + 1 < line.length) j++
                                j++
                            }
                            val end = if (j < line.length) j + 1 else line.length
                            withStyle(SpanStyle(color = stringColor)) {
                                append(line.substring(i, end))
                            }
                            i = end
                        }
                        ch == '@' -> {
                            var j = i + 1
                            while (j < line.length && (line[j].isLetterOrDigit() || line[j] == '_')) j++
                            withStyle(SpanStyle(color = annotationColor)) {
                                append(line.substring(i, j))
                            }
                            i = j
                        }
                        ch.isDigit() -> {
                            var j = i
                            while (j < line.length && (line[j].isDigit() || line[j] == '.')) j++
                            withStyle(SpanStyle(color = numberColor)) {
                                append(line.substring(i, j))
                            }
                            i = j
                        }
                        ch.isLetter() || ch == '_' -> {
                            var j = i
                            while (j < line.length && (line[j].isLetterOrDigit() || line[j] == '_')) j++
                            val word = line.substring(i, j)
                            val color = if (word in keywords) keywordColor else baseColor
                            val weight = if (word in keywords) FontWeight.SemiBold else FontWeight.Normal
                            withStyle(SpanStyle(color = color, fontWeight = weight)) {
                                append(word)
                            }
                            i = j
                        }
                        else -> {
                            withStyle(SpanStyle(color = baseColor)) {
                                append(ch)
                            }
                            i++
                        }
                    }
                }
            }
            if (lineIdx < lines.lastIndex) append("\n")
        }
    }
}
