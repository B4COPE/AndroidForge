package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ModelRuntimeType
import com.example.data.model.OpenWeightModelCatalog
import com.example.data.model.ProviderType
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.EcosystemViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProvidersRuntimeScreen(
    ecosystemViewModel: EcosystemViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val providers by ecosystemViewModel.providers.collectAsStateWithLifecycle()
    val isBusy by ecosystemViewModel.isBusy.collectAsStateWithLifecycle()
    val banner by ecosystemViewModel.statusBanner.collectAsStateWithLifecycle()

    var editingId by remember { mutableStateOf<String?>(null) }
    var nameInput by remember { mutableStateOf("") }
    var providerType by remember { mutableStateOf(ProviderType.JAMES_PRIMARY_OPEN_WEIGHT) }
    var runtimeType by remember { mutableStateOf(ModelRuntimeType.OLLAMA) }
    var endpointInput by remember { mutableStateOf(ProviderType.JAMES_PRIMARY_OPEN_WEIGHT.defaultEndpoint) }
    var modelInput by remember { mutableStateOf("gemma3:12b-it") }
    var apiKeyInput by remember { mutableStateOf("") }
    var makePrimary by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.providersAndModels) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("providers_runtime_screen"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (isBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                banner?.let { msg ->
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            IconButton(onClick = { ecosystemViewModel.dismissBanner() }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }

                // Recommended Open-Weight Models Catalog with Explicit License Comparison
                Text("Independent Open-Weight Model Catalog", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                OpenWeightModelCatalog.models.forEach { spec ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(spec.displayName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = (if (spec.isOsiOpenSource) StatusSuccess else StatusWarning).copy(alpha = 0.16f)
                                ) {
                                    Text(
                                        text = spec.licenseName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (spec.isOsiOpenSource) StatusSuccess else StatusWarning,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Text(spec.licenseNotes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Quantization: ${spec.recommendedQuantization} · RAM/VRAM >= ${spec.minRamOrVramGb} GB · Runtimes: ${spec.supportedRuntimes}", style = MaterialTheme.typography.bodySmall)
                            Text("Arabic: ${spec.arabicQuality} | Fine-Tuning: ${spec.fineTuningNotes}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                // Configured Providers List (Open-Weight + Collaborator APIs + Firebase)
                Text("Configured Providers & Credential Status", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                providers.forEach { prov ->
                    val costEstimate = (prov.totalEstimatedTokens / 1_000_000.0) * (prov.estimatedInputCostPer1M + prov.estimatedOutputCostPer1M) * 0.5
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                1.dp,
                                if (prov.isDefaultPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                RoundedCornerShape(14.dp)
                            )
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(prov.name, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                                    Text("${prov.runtimeType.label} · Model: ${prov.modelId}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                Switch(
                                    checked = prov.enabled,
                                    onCheckedChange = { ecosystemViewModel.toggleProviderEnabled(prov) }
                                )
                            }
                            Text("Endpoint: ${prov.endpointUrl.ifBlank { "Default" }}", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "Status: ${prov.lastStatus} · Requests: ${prov.totalRequests}/${prov.requestLimitPerDay} · Tokens: ${prov.totalEstimatedTokens} (~$${"%.4f".format(costEstimate)})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (prov.providerType.isCommercialApi && prov.providerType != ProviderType.FIREBASE_AI_LOGIC) {
                                Text(
                                    text = "Encrypted API Key: ${ecosystemViewModel.maskedProviderCredential(prov.id)}",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { ecosystemViewModel.testProviderConnection(prov) }) {
                                    Icon(Icons.Rounded.NetworkCheck, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Test")
                                }
                                OutlinedButton(onClick = { ecosystemViewModel.setProviderPrimary(prov.id) }) {
                                    Icon(Icons.Rounded.Star, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (prov.isDefaultPrimary) "Primary" else "Set Primary")
                                }
                                OutlinedButton(onClick = {
                                    editingId = prov.id
                                    nameInput = prov.name
                                    providerType = prov.providerType
                                    runtimeType = prov.runtimeType
                                    endpointInput = prov.endpointUrl
                                    modelInput = prov.modelId
                                    apiKeyInput = ""
                                    makePrimary = prov.isDefaultPrimary
                                }) {
                                    Text("Edit / Key")
                                }
                            }
                        }
                    }
                }

                // Add or Edit Provider Form
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (editingId != null) "Update Provider / Encrypted Credential" else "Add Custom Provider or Runtime",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            ProviderType.entries.forEach { t ->
                                FilterChip(
                                    selected = providerType == t,
                                    onClick = {
                                        providerType = t
                                        if (endpointInput.isBlank() || editingId == null) endpointInput = t.defaultEndpoint
                                        runtimeType = when (t) {
                                            ProviderType.JAMES_PRIMARY_OPEN_WEIGHT -> ModelRuntimeType.OLLAMA
                                            ProviderType.FIREBASE_AI_LOGIC -> ModelRuntimeType.FIREBASE_SDK
                                            else -> ModelRuntimeType.CLOUD_API
                                        }
                                    },
                                    label = { Text(t.label) }
                                )
                            }
                        }
                        if (providerType == ProviderType.JAMES_PRIMARY_OPEN_WEIGHT) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(ModelRuntimeType.OLLAMA, ModelRuntimeType.LLAMACPP, ModelRuntimeType.VLLM).forEach { rt ->
                                    FilterChip(
                                        selected = runtimeType == rt,
                                        onClick = { runtimeType = rt },
                                        label = { Text(rt.label) }
                                    )
                                }
                            }
                        }
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = { nameInput = it },
                            label = { Text("Display Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = endpointInput,
                            onValueChange = { endpointInput = it },
                            label = { Text("Endpoint URL (e.g. https://your-oci-host or http://10.0.2.2:11434)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = modelInput,
                            onValueChange = { modelInput = it },
                            label = { Text("Model ID (e.g. gemma3:12b-it, qwen2.5:14b-instruct, gpt-4.1-mini)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = { apiKeyInput = it },
                            label = { Text("API Key / Bearer Token (stored encrypted in Private Vault, optional)") },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(checked = makePrimary, onCheckedChange = { makePrimary = it })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Set as Default Primary Provider", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(
                            onClick = {
                                ecosystemViewModel.addOrUpdateProvider(
                                    existingId = editingId,
                                    name = nameInput,
                                    providerType = providerType,
                                    runtimeType = runtimeType,
                                    endpointUrl = endpointInput,
                                    modelId = modelInput,
                                    enabled = true,
                                    isPrimary = makePrimary,
                                    apiKeyInput = apiKeyInput
                                )
                                editingId = null
                                apiKeyInput = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (editingId != null) "Save Provider Update" else "Add Provider")
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
