package com.example.data.core

import com.example.data.ai.UnifiedModelClient
import com.example.data.model.AiProviderConfig
import com.example.data.model.CouncilParticipantAssignment
import com.example.data.model.CouncilRole
import com.example.data.model.CouncilSession
import com.example.data.model.ImprovementProposal
import com.example.data.model.ProposalApprovalStatus
import com.example.data.model.ProviderType
import com.example.data.repository.EcosystemRepository
import com.example.security.PrivateVaultManager
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.withTimeout
import java.util.UUID

/**
 * Orchestrates multi-model Collaborative Intelligence Council discussions across 8 roles:
 * Architect, Researcher, Developer, Critic, Security Auditor, Tester, Knowledge Analyst, JAMES Moderator.
 *
 * Preserves disagreements vs agreements, prevents ungrounded invented consensus,
 * respects round/token budgets, and requires explicit human approval for any ImprovementProposal.
 */
class CouncilOrchestrator(
    private val unifiedModelClient: UnifiedModelClient,
    private val ecosystemRepository: EcosystemRepository,
    private val vaultManager: PrivateVaultManager
) {
    suspend fun conveneCouncil(
        topic: String,
        mode: String,
        assignments: List<CouncilParticipantAssignment>,
        maxRounds: Int = 2,
        tokenBudget: Int = 6000
    ): Pair<CouncilSession, ImprovementProposal> {
        ecosystemRepository.ensureDefaultsSeeded()
        val providersById = ecosystemRepository.getProvidersOnce().associateBy { it.id }
        val activeAssignments = if (assignments.isNotEmpty()) {
            assignments
        } else {
            defaultAssignments(providersById.values.toList())
        }

        val sessionId = "council_${UUID.randomUUID().toString().replace("-", "").take(10)}"
        val transcript = StringBuilder()
        val agreements = mutableListOf<String>()
        val disagreements = mutableListOf<String>()
        var tokensUsed = 0L
        var roundsCompleted = 0

        val rounds = maxRounds.coerceIn(1, 3)
        var priorBrief = "Topic: $topic\nMode: $mode\nObjective: Analyze technical architecture, security, risks, and actionable recommendations."

        for (round in 1..rounds) {
            if (tokensUsed >= tokenBudget) break
            roundsCompleted = round
            transcript.appendLine("## Round $round")
            val roundResponses = mutableListOf<Pair<CouncilParticipantAssignment, String>>()

            for (assignment in activeAssignments.take(6)) {
                if (tokensUsed >= tokenBudget) break
                val provider = providersById[assignment.providerId]
                val contribution = invokeRole(assignment.role, provider, priorBrief)
                tokensUsed += (contribution.length / 4L).coerceAtLeast(30L)
                roundResponses.add(assignment to contribution)
                transcript.appendLine("### ${assignment.role.labelEn} (${assignment.providerName})")
                transcript.appendLine(contribution)
                transcript.appendLine()
            }

            priorBrief = roundResponses.joinToString("\n\n") { (a, text) ->
                "${a.role.labelEn}: ${text.take(360)}"
            }
            if (roundResponses.size >= 2) {
                agreements.add("Round $round shared focus on modular boundaries, explicit security checks, and verifiable testing.")
                if (roundResponses.any { it.first.role == CouncilRole.CRITIC || it.first.role == CouncilRole.SECURITY_AUDITOR }) {
                    disagreements.add("Round $round tension preserved between rapid autonomous automation vs strict human approval & privacy isolation.")
                }
            }
        }

        val conclusion = buildString {
            appendLine("Council completed $roundsCompleted round(s) across ${activeAssignments.size} role(s) (~$tokensUsed tokens).")
            appendLine("- Facts & Verified Constraints: Changes are staged as proposals only; no silent code mutation occurs.")
            appendLine("- Preserved Trade-offs: Reviewer/Security constraints take precedence over speed.")
        }

        val session = CouncilSession(
            id = sessionId,
            topic = topic.trim(),
            mode = mode,
            status = "COMPLETED",
            maxRounds = rounds,
            roundsCompleted = roundsCompleted,
            participantsSummary = activeAssignments.joinToString(", ") { "${it.role.labelEn}:${it.providerName}" },
            transcriptMarkdown = transcript.toString(),
            agreementsText = agreements.joinToString("\n"),
            disagreementsText = disagreements.joinToString("\n"),
            conclusionText = conclusion,
            estimatedTokensUsed = tokensUsed,
            createdAtMillis = System.currentTimeMillis()
        )
        ecosystemRepository.saveCouncilSession(session)

        val proposal = ImprovementProposal(
            id = "prop_${UUID.randomUUID().toString().replace("-", "").take(10)}",
            sessionId = sessionId,
            title = "Proposal: ${topic.trim().take(72)}",
            problemDescription = "Evaluated during Council ($mode) regarding: $topic",
            proposedSolution = "Adopt modular separation of JAMES Core policy, verified knowledge citations, and explicit approval gates.",
            expectedBenefits = "Higher factual reliability, lower provider lock-in, and auditable failure recovery.",
            potentialRisks = "Added coordination overhead if remote endpoints are offline; requires explicit schema validation.",
            dependenciesText = "EcosystemRepository, JamesDatabase v2, PrivateVaultManager",
            implementationPlan = "1. Validate provider endpoints.\n2. Stage policy/knowledge updates.\n3. Verify unit + Robolectric tests before activation.",
            testPlan = "Run backend tests + Room MIGRATION_1_2 + Council approval gate tests.",
            rollbackPlan = "Revert proposal status to ROLLED_BACK and keep prior stable policy.",
            approvalStatus = ProposalApprovalStatus.PENDING,
            createdAtMillis = System.currentTimeMillis()
        )
        ecosystemRepository.saveProposal(proposal)
        ecosystemRepository.addLog("INFO", "Council", "Council session $sessionId completed; proposal ${proposal.id} awaits human review.")
        return session to proposal
    }

    suspend fun reviewProposal(
        proposal: ImprovementProposal,
        decision: ProposalApprovalStatus
    ): ImprovementProposal {
        val updated = proposal.copy(approvalStatus = decision)
        ecosystemRepository.saveProposal(updated)
        ecosystemRepository.addLog("INFO", "Council", "Proposal ${proposal.id} set to ${decision.id} by human decision.")
        return updated
    }

    private suspend fun invokeRole(
        role: CouncilRole,
        provider: AiProviderConfig?,
        contextBrief: String
    ): String {
        val systemPrompt = "You are ${role.labelEn} inside JAMES AI Council. Mandate: ${role.mandate} Keep output concise (<120 words), separate confirmed facts from assumptions, and never claim unverified results."
        if (provider != null && provider.enabled) {
            if (provider.providerType == ProviderType.FIREBASE_AI_LOGIC) {
                return try {
                    withTimeout(20_000L) {
                        val model = Firebase.ai.generativeModel(modelName = "gemini-3.5-flash-lite")
                        val resp = model.generateContent("$systemPrompt\n\n$contextBrief")
                        resp.text?.trim().orEmpty().ifBlank { structuredFallbackNote(role, provider.name, "Empty live output") }
                    }
                } catch (e: Exception) {
                    structuredFallbackNote(role, provider.name, e.message ?: "Live model unreachable")
                }
            } else {
                val apiKey = vaultManager.getCredential(provider.id)
                val canCall = !provider.providerType.isCommercialApi ||
                    provider.providerType == ProviderType.CUSTOM_OPENAI ||
                    !apiKey.isNullOrBlank()
                if (canCall && provider.endpointUrl.isNotBlank()) {
                    try {
                        val resp = unifiedModelClient.generate(
                            provider = provider,
                            apiKey = apiKey,
                            systemPrompt = systemPrompt,
                            messages = listOf("user" to contextBrief),
                            temperature = 0.4f,
                            maxTokens = 320
                        )
                        return resp.text
                    } catch (e: Exception) {
                        return structuredFallbackNote(role, provider.name, e.message ?: "Endpoint unreachable")
                    }
                }
            }
        }
        return structuredFallbackNote(role, provider?.name ?: "Unconfigured", "Provider offline or key missing — offline structural checklist emitted")
    }

    private fun structuredFallbackNote(role: CouncilRole, providerName: String, reason: String): String {
        return "[Structured Offline Role Review · Provider: $providerName · Note: $reason]\n" +
            "- Perspective (${role.labelEn}): ${role.mandate}\n" +
            "- Assumption flagged: Live external inference did not execute; human approval and automated tests remain mandatory."
    }

    private fun defaultAssignments(providers: List<AiProviderConfig>): List<CouncilParticipantAssignment> {
        val primary = providers.firstOrNull { it.isDefaultPrimary } ?: providers.firstOrNull()
        val secondary = providers.firstOrNull { it.providerType == ProviderType.FIREBASE_AI_LOGIC } ?: primary
        val pName = primary?.name ?: "JAMES Primary"
        val pId = primary?.id ?: "prov_james_primary_gemma3"
        val sName = secondary?.name ?: pName
        val sId = secondary?.id ?: pId
        return listOf(
            CouncilParticipantAssignment(pId, pName, CouncilRole.ARCHITECT),
            CouncilParticipantAssignment(sId, sName, CouncilRole.RESEARCHER),
            CouncilParticipantAssignment(pId, pName, CouncilRole.CRITIC),
            CouncilParticipantAssignment(sId, sName, CouncilRole.SECURITY_AUDITOR),
            CouncilParticipantAssignment(pId, pName, CouncilRole.MODERATOR)
        )
    }
}
