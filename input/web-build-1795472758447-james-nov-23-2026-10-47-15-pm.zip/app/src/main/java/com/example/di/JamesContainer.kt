package com.example.di

import android.content.Context
import com.example.data.ai.GeminiAiService
import com.example.data.ai.UnifiedModelClient
import com.example.data.core.CloudBackendClient
import com.example.data.core.ConnectorProbeClient
import com.example.data.core.CouncilOrchestrator
import com.example.data.core.JamesCoreOrchestrator
import com.example.data.core.LearningOrchestrator
import com.example.data.core.McpHttpClient
import com.example.data.core.RepositoryMigrationEngine
import com.example.data.local.JamesDatabase
import com.example.data.local.PreferencesRepository
import com.example.data.remote.CloudSyncRepository
import com.example.data.repository.EcosystemRepository
import com.example.data.repository.JamesRepository
import com.example.security.CryptoManager
import com.example.security.PrivateVaultManager
import com.example.util.NetworkMonitor
import com.example.util.VoiceInputManager
import com.example.util.VoiceOutputManager

class JamesContainer(context: Context) {
    private val appContext = context.applicationContext

    val cryptoManager = CryptoManager()
    val privateVaultManager = PrivateVaultManager(appContext)
    val database = JamesDatabase.getInstance(appContext)
    val preferencesRepository = PreferencesRepository(appContext)
    val cloudSyncRepository = CloudSyncRepository(appContext, cryptoManager)
    val repository = JamesRepository(
        conversationDao = database.conversationDao(),
        messageDao = database.messageDao(),
        memoryDao = database.memoryDao(),
        noteDao = database.noteDao(),
        preferencesRepository = preferencesRepository,
        cryptoManager = cryptoManager,
        cloudSyncRepository = cloudSyncRepository
    )

    val aiService = GeminiAiService()
    val unifiedModelClient = UnifiedModelClient()
    val cloudBackendClient = CloudBackendClient()
    val mcpHttpClient = McpHttpClient()
    val connectorProbeClient = ConnectorProbeClient()

    val ecosystemRepository = EcosystemRepository(
        dao = database.ecosystemDao(),
        vaultManager = privateVaultManager
    )
    val learningOrchestrator = LearningOrchestrator(ecosystemRepository)
    val migrationEngine = RepositoryMigrationEngine(ecosystemRepository)
    val jamesCoreOrchestrator = JamesCoreOrchestrator(
        geminiAiService = aiService,
        unifiedModelClient = unifiedModelClient,
        cloudBackendClient = cloudBackendClient,
        ecosystemRepository = ecosystemRepository,
        learningOrchestrator = learningOrchestrator,
        vaultManager = privateVaultManager
    )
    val councilOrchestrator = CouncilOrchestrator(
        unifiedModelClient = unifiedModelClient,
        ecosystemRepository = ecosystemRepository,
        vaultManager = privateVaultManager
    )

    val networkMonitor = NetworkMonitor(appContext)
    val voiceInputManager = VoiceInputManager(appContext)
    val voiceOutputManager = VoiceOutputManager(appContext)
    val stagingFilesDir = appContext.filesDir
}
