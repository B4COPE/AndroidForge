package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val SpaceGroteskFontFamily = FontFamily(
    Font(R.font.space_grotesk, FontWeight.Normal),
    Font(R.font.space_grotesk, FontWeight.Medium),
    Font(R.font.space_grotesk, FontWeight.SemiBold),
    Font(R.font.space_grotesk, FontWeight.Bold)
)

val PlusJakartaSansFontFamily = FontFamily(
    Font(R.font.plus_jakarta_sans, FontWeight.Normal),
    Font(R.font.plus_jakarta_sans, FontWeight.Medium),
    Font(R.font.plus_jakarta_sans, FontWeight.SemiBold),
    Font(R.font.plus_jakarta_sans, FontWeight.Bold)
)

val JetBrainsMonoFontFamily = FontFamily(
    Font(R.font.jetbrains_mono, FontWeight.Normal),
    Font(R.font.jetbrains_mono, FontWeight.Medium)
)

val CairoFontFamily = FontFamily(
    Font(R.font.cairo, FontWeight.Normal),
    Font(R.font.cairo, FontWeight.Medium),
    Font(R.font.cairo, FontWeight.SemiBold),
    Font(R.font.cairo, FontWeight.Bold)
)

enum class FontSizeScale(
    val id: String,
    val multiplier: Float,
    val labelEn: String,
    val labelAr: String
) {
    COMPACT("compact", 0.90f, "Compact", "مضغوط"),
    DEFAULT("default", 1.00f, "Default", "افتراضي"),
    LARGE("large", 1.15f, "Large", "كبير"),
    EXTRA_LARGE("xlarge", 1.30f, "Extra Large", "كبير جداً");

    companion object {
        fun fromId(id: String): FontSizeScale = entries.firstOrNull { it.id == id } ?: DEFAULT
    }
}

fun buildJamesTypography(
    scale: FontSizeScale = FontSizeScale.DEFAULT,
    isArabic: Boolean = false
): Typography {
    val m = scale.multiplier
    val displayFamily = if (isArabic) CairoFontFamily else SpaceGroteskFontFamily
    val bodyFamily = if (isArabic) CairoFontFamily else PlusJakartaSansFontFamily

    return Typography(
        displayLarge = TextStyle(
            fontFamily = displayFamily,
            fontWeight = FontWeight.Bold,
            fontSize = (36f * m).sp,
            lineHeight = (44f * m).sp,
            letterSpacing = (-0.5f).sp
        ),
        headlineLarge = TextStyle(
            fontFamily = displayFamily,
            fontWeight = FontWeight.Bold,
            fontSize = (28f * m).sp,
            lineHeight = (36f * m).sp,
            letterSpacing = (-0.3f).sp
        ),
        headlineMedium = TextStyle(
            fontFamily = displayFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (22f * m).sp,
            lineHeight = (28f * m).sp
        ),
        titleLarge = TextStyle(
            fontFamily = displayFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (20f * m).sp,
            lineHeight = (26f * m).sp
        ),
        titleMedium = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (16f * m).sp,
            lineHeight = (22f * m).sp
        ),
        titleSmall = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (14f * m).sp,
            lineHeight = (20f * m).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Normal,
            fontSize = (15.5f * m).sp,
            lineHeight = (23f * m).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Normal,
            fontSize = (14f * m).sp,
            lineHeight = (20f * m).sp
        ),
        bodySmall = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Normal,
            fontSize = (12f * m).sp,
            lineHeight = (17f * m).sp
        ),
        labelLarge = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = (14f * m).sp,
            lineHeight = (18f * m).sp
        ),
        labelMedium = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (12f * m).sp,
            lineHeight = (16f * m).sp
        ),
        labelSmall = TextStyle(
            fontFamily = JetBrainsMonoFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (11f * m).sp,
            lineHeight = (14f * m).sp
        )
    )
}
