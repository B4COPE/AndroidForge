package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian & Platinum Dark Palette (Default JAMES Brand)
val ObsidianVoid = Color(0xFF070A10)
val ObsidianSurface = Color(0xFF0E131D)
val ObsidianSurfaceElevated = Color(0xFF151C2A)
val ObsidianSurfaceContainerHigh = Color(0xFF1C2536)
val ObsidianOutline = Color(0xFF283347)
val ObsidianOutlineSubtle = Color(0xFF1B2332)

val PlatinumText = Color(0xFFF1F5F9)
val SlateMutedText = Color(0xFF94A3B8)
val SlateDimText = Color(0xFF64748B)

// Light Mode Palette (Clean Architectural Alabaster)
val AlabasterBackground = Color(0xFFF6F8FB)
val AlabasterSurface = Color(0xFFFFFFFF)
val AlabasterSurfaceElevated = Color(0xFFEEF2F7)
val AlabasterSurfaceHigh = Color(0xFFE2E8F0)
val AlabasterOutline = Color(0xFFCBD5E1)
val InkPrimaryText = Color(0xFF0F172A)
val InkMutedText = Color(0xFF475569)

// Selectable Accent Colors
enum class JamesAccent(
    val id: String,
    val labelEn: String,
    val labelAr: String,
    val primaryDark: Color,
    val onPrimaryDark: Color,
    val containerDark: Color,
    val onContainerDark: Color,
    val primaryLight: Color,
    val onPrimaryLight: Color,
    val containerLight: Color,
    val onContainerLight: Color,
    val secondary: Color
) {
    CYAN(
        id = "cyan",
        labelEn = "Electric Cyan",
        labelAr = "سماوي كهربائي",
        primaryDark = Color(0xFF00E5FF),
        onPrimaryDark = Color(0xFF002026),
        containerDark = Color(0xFF083344),
        onContainerDark = Color(0xFFA5F3FC),
        primaryLight = Color(0xFF0284C7),
        onPrimaryLight = Color(0xFFFFFFFF),
        containerLight = Color(0xFFE0F2FE),
        onContainerLight = Color(0xFF0C4A6E),
        secondary = Color(0xFF38BDF8)
    ),
    SAPPHIRE(
        id = "sapphire",
        labelEn = "Sapphire Cobalt",
        labelAr = "ياقوتي أزرق",
        primaryDark = Color(0xFF60A5FA),
        onPrimaryDark = Color(0xFF081B33),
        containerDark = Color(0xFF1E3A8A),
        onContainerDark = Color(0xFFDBEAFE),
        primaryLight = Color(0xFF2563EB),
        onPrimaryLight = Color(0xFFFFFFFF),
        containerLight = Color(0xFFDBEAFE),
        onContainerLight = Color(0xFF1E3A8A),
        secondary = Color(0xFF818CF8)
    ),
    EMERALD(
        id = "emerald",
        labelEn = "Emerald Matrix",
        labelAr = "زمردي",
        primaryDark = Color(0xFF34D399),
        onPrimaryDark = Color(0xFF022C22),
        containerDark = Color(0xFF064E3B),
        onContainerDark = Color(0xFFD1FAE5),
        primaryLight = Color(0xFF059669),
        onPrimaryLight = Color(0xFFFFFFFF),
        containerLight = Color(0xFFD1FAE5),
        onContainerLight = Color(0xFF064E3B),
        secondary = Color(0xFF2DD4BF)
    ),
    AMBER(
        id = "amber",
        labelEn = "Amber Gold",
        labelAr = "كهرماني ذهبي",
        primaryDark = Color(0xFFFBBF24),
        onPrimaryDark = Color(0xFF291800),
        containerDark = Color(0xFF78350F),
        onContainerDark = Color(0xFFFEF3C7),
        primaryLight = Color(0xFFD97706),
        onPrimaryLight = Color(0xFFFFFFFF),
        containerLight = Color(0xFFFEF3C7),
        onContainerLight = Color(0xFF78350F),
        secondary = Color(0xFFF59E0B)
    ),
    VIOLET(
        id = "violet",
        labelEn = "Violet Pulse",
        labelAr = "بنفسجي",
        primaryDark = Color(0xFFA78BFA),
        onPrimaryDark = Color(0xFF1E103B),
        containerDark = Color(0xFF4C1D95),
        onContainerDark = Color(0xFFEDE9FE),
        primaryLight = Color(0xFF7C3AED),
        onPrimaryLight = Color(0xFFFFFFFF),
        containerLight = Color(0xFFEDE9FE),
        onContainerLight = Color(0xFF4C1D95),
        secondary = Color(0xFFC084FC)
    );

    companion object {
        fun fromId(id: String): JamesAccent = entries.firstOrNull { it.id == id } ?: CYAN
    }
}

// Semantic status colors
val StatusSuccess = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusDanger = Color(0xFFEF4444)
val CodeBlockBackgroundDark = Color(0xFF0A0E17)
val CodeBlockBackgroundLight = Color(0xFF111827)
