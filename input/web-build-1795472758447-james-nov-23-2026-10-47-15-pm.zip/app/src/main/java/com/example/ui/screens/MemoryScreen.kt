package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.viewmodel.MainAppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(
    mainViewModel: MainAppViewModel,
    onNavigateBack: () -> Unit
) {
    val strings = LocalJamesStrings.current
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val memories by mainViewModel.memories.collectAsStateWithLifecycle()

    var selectedFilter by remember { mutableStateOf<MemoryCategory?>(null) }
    var showEditorDialog by remember { mutableStateOf(false) }
    var editingTarget by remember { mutableStateOf<MemoryItem?>(null) }
    var editorCategory by remember { mutableStateOf(MemoryCategory.PREFERENCE) }
    var editorContent by remember { mutableStateOf("") }
    var showClearDialog by remember { mutableStateOf(false) }

    val filteredMemories = remember(memories, selectedFilter) {
        val cat = selectedFilter
        if (cat == null) memories else memories.filter { it.category == cat }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(strings.memoryManagement) },
                actions = {
                    if (memories.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearDialog = true },
                            modifier = Modifier.testTag("clear_all_memories_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteSweep,
                                contentDescription = strings.clearAllMemories,
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    editingTarget = null
                    editorCategory = MemoryCategory.PREFERENCE
                    editorContent = ""
                    showEditorDialog = true
                },
                modifier = Modifier.navigationBarsPadding().testTag("add_memory_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.addMemory)
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 720.dp)
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                // Master Memory Toggle + Privacy Note
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = strings.memoryEnabledLabel,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = if (settings.memoryEnabled) {
                                        if (strings.isArabic) "يتذكر JAMES فقط الحقائق التي توافق عليها هنا."
                                        else "JAMES recalls only user-approved memories stored here."
                                    } else {
                                        strings.memoryDisabledHint
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = settings.memoryEnabled,
                                onCheckedChange = { mainViewModel.setMemoryEnabled(it) },
                                modifier = Modifier.testTag("memory_master_switch")
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Encrypted at rest (AES-256-GCM) · Separate from chat logs",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                // Category filter chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 4.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { selectedFilter = null },
                        label = { Text(if (strings.isArabic) "الكل (${memories.size})" else "All (${memories.size})") }
                    )
                    MemoryCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedFilter == cat,
                            onClick = { selectedFilter = cat },
                            label = { Text(if (strings.isArabic) cat.labelAr else cat.labelEn) }
                        )
                    }
                }

                if (filteredMemories.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Rounded.Psychology,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                modifier = Modifier.size(52.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = strings.noMemoriesYet,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredMemories, key = { it.id }) { mem ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = (if (strings.isArabic) mem.category.labelAr else mem.category.labelEn).uppercase(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = mem.content,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = if (mem.enabled) MaterialTheme.colorScheme.onSurface
                                            else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = mem.enabled,
                                        onCheckedChange = { checked ->
                                            mainViewModel.updateMemory(mem.copy(enabled = checked))
                                        }
                                    )
                                    IconButton(
                                        onClick = {
                                            editingTarget = mem
                                            editorCategory = mem.category
                                            editorContent = mem.content
                                            showEditorDialog = true
                                        }
                                    ) {
                                        Icon(Icons.Outlined.Edit, contentDescription = strings.editMemory)
                                    }
                                    IconButton(onClick = { mainViewModel.deleteMemory(mem.id) }) {
                                        Icon(Icons.Outlined.Delete, contentDescription = strings.delete, tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditorDialog) {
        AlertDialog(
            onDismissRequest = { showEditorDialog = false },
            title = { Text(if (editingTarget == null) strings.addMemory else strings.editMemory) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    ) {
                        MemoryCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = editorCategory == cat,
                                onClick = { editorCategory = cat },
                                label = { Text(if (strings.isArabic) cat.labelAr else cat.labelEn) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = editorContent,
                        onValueChange = { editorContent = it },
                        placeholder = {
                            Text(
                                if (strings.isArabic) "مثال: أفضل ردوداً مختصرة بلغة Kotlin"
                                else "Example: I prefer concise Kotlin examples with coroutines."
                            )
                        },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth().testTag("memory_content_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val existing = editingTarget
                        if (existing == null) {
                            mainViewModel.addMemory(editorCategory, editorContent)
                        } else {
                            mainViewModel.updateMemory(
                                existing.copy(category = editorCategory, content = editorContent.trim())
                            )
                        }
                        showEditorDialog = false
                    },
                    enabled = editorContent.isNotBlank(),
                    modifier = Modifier.testTag("memory_save_button")
                ) { Text(strings.save) }
            },
            dismissButton = {
                TextButton(onClick = { showEditorDialog = false }) { Text(strings.cancel) }
            }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text(strings.clearAllMemories) },
            text = {
                Text(
                    if (strings.isArabic) "هل تريد مسح جميع الذكريات المحفوظة نهائياً؟"
                    else "Permanently delete all stored personal memories?"
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        mainViewModel.clearAllMemories()
                        showClearDialog = false
                    }
                ) { Text(strings.delete, color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text(strings.cancel) }
            }
        )
    }
}
