package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.LocalNote
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.security.CryptoManager
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await

data class SyncSummary(
    val pushedConversations: Int = 0,
    val pulledConversations: Int = 0,
    val pushedMemories: Int = 0,
    val pulledMemories: Int = 0,
    val pushedNotes: Int = 0,
    val pulledNotes: Int = 0
)

class CloudSyncRepository private constructor(
    private val cryptoManager: CryptoManager,
    dbProvider: () -> FirebaseFirestore,
    authProvider: () -> FirebaseAuth
) {
    private val db: FirebaseFirestore by lazy(dbProvider)
    private val auth: FirebaseAuth by lazy(authProvider)

    constructor(
        db: FirebaseFirestore,
        cryptoManager: CryptoManager,
        auth: FirebaseAuth = Firebase.auth
    ) : this(
        cryptoManager = cryptoManager,
        dbProvider = { db },
        authProvider = { auth }
    )

    constructor(context: Context, cryptoManager: CryptoManager) : this(
        cryptoManager = cryptoManager,
        dbProvider = {
            FirebaseFirestore.getInstance(
                context.applicationContext.getString(R.string.firestore_database_id)
            )
        },
        authProvider = { Firebase.auth }
    )

    private fun requireUserId(): String {
        val uid = auth.currentUser?.uid
        check(!uid.isNullOrBlank()) {
            "User must be signed in with Google before accessing Cloud Sync."
        }
        return uid
    }

    suspend fun ensureUserProfile(
        displayName: String,
        email: String?
    ): Result<UserSyncProfile> {
        var path = "users"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid)
            path = docRef.path
            val existing = docRef.get().await()
            if (existing.exists()) {
                val profile = existing.toObject(
                    UserSyncProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserSyncProfile(userId = uid, displayName = displayName.take(100), email = email?.take(200))
                Result.success(profile)
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to displayName.ifBlank { "JAMES User" }.take(100),
                    "email" to email?.take(200),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
                val created = docRef.get().await().toObject(
                    UserSyncProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserSyncProfile(userId = uid, displayName = displayName.take(100), email = email)
                Result.success(created)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun getUserProfile(): Result<UserSyncProfile?> {
        var path = "users"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("users").document(uid)
            path = docRef.path
            val snap = docRef.get().await()
            val profile = if (snap.exists()) {
                snap.toObject(
                    UserSyncProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            } else null
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun configureOrVerifyE2eePassphrase(passphrase: String): Result<Boolean> {
        var path = "users"
        return try {
            val uid = requireUserId()
            val user = auth.currentUser
            ensureUserProfile(user?.displayName ?: "JAMES User", user?.email).getOrThrow()
            val docRef = db.collection("users").document(uid)
            path = docRef.path
            val snap = docRef.get().await()
            val existingProfile = snap.toObject(
                UserSyncProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            val existingSalt = existingProfile?.e2eeSalt
            val existingVerifier = existingProfile?.e2eeVerifier

            if (!existingSalt.isNullOrBlank() && !existingVerifier.isNullOrBlank()) {
                val ok = cryptoManager.verifyPassphraseWithToken(
                    passphrase = passphrase,
                    saltBase64 = existingSalt,
                    verifierToken = existingVerifier
                )
                Result.success(ok)
            } else {
                val salt = cryptoManager.generateRandomSaltBase64()
                val key = cryptoManager.unlockE2eeVault(passphrase, salt)
                val verifier = cryptoManager.createVerifierToken(key)
                docRef.update(
                    mapOf(
                        "e2eeSalt" to salt,
                        "e2eeVerifier" to verifier,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                Result.success(true)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun pushConversation(conversation: Conversation, messages: List<ChatMessage>): Result<Unit> {
        var path = "users/conversations"
        return try {
            val uid = requireUserId()
            val safeConvId = sanitizeDocId(conversation.id)
            val convRef = db.collection("users").document(uid)
                .collection("conversations").document(safeConvId)
            path = convRef.path

            val (encTitle, titleEncrypted) = cryptoManager.encryptForCloud(conversation.title.take(280))
            val (encPreview, previewEncrypted) = cryptoManager.encryptForCloud(conversation.lastMessagePreview.take(550))
            val isEncrypted = titleEncrypted && previewEncrypted

            val existingConv = convRef.get().await()
            if (existingConv.exists()) {
                convRef.update(
                    mapOf(
                        "title" to encTitle.take(300),
                        "modelName" to conversation.modelName.take(64),
                        "lastMessagePreview" to encPreview.take(600),
                        "messageCount" to messages.size,
                        "pinned" to conversation.pinned,
                        "encrypted" to isEncrypted,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                convRef.set(
                    mapOf(
                        "userId" to uid,
                        "title" to encTitle.take(300),
                        "modelName" to conversation.modelName.take(64),
                        "lastMessagePreview" to encPreview.take(600),
                        "messageCount" to messages.size,
                        "pinned" to conversation.pinned,
                        "encrypted" to isEncrypted,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }

            for (msg in messages) {
                val safeMsgId = sanitizeDocId(msg.id)
                val msgRef = convRef.collection("messages").document(safeMsgId)
                path = msgRef.path
                val (encContent, msgEncrypted) = cryptoManager.encryptForCloud(msg.content.take(100_000))
                val existingMsg = msgRef.get().await()
                if (existingMsg.exists()) {
                    val updateMap = mutableMapOf<String, Any?>(
                        "content" to encContent.take(120_000),
                        "encrypted" to msgEncrypted,
                        "attachmentSummary" to msg.attachmentName?.take(600),
                        "modelName" to msg.modelName?.take(64),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    msgRef.update(updateMap).await()
                } else {
                    val createMap = mapOf(
                        "userId" to uid,
                        "conversationId" to safeConvId,
                        "role" to if (msg.role == "user") "user" else "assistant",
                        "content" to encContent.take(120_000),
                        "encrypted" to msgEncrypted,
                        "attachmentSummary" to msg.attachmentName?.take(600),
                        "modelName" to msg.modelName?.take(64),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    ).filterValues { it != null }
                    msgRef.set(createMap).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun pullConversations(): Result<List<Pair<Conversation, List<ChatMessage>>>> {
        var path = "users/conversations"
        return try {
            val uid = requireUserId()
            val convCol = db.collection("users").document(uid).collection("conversations")
            path = convCol.path
            val convSnapshots = convCol.get().await()
            val results = mutableListOf<Pair<Conversation, List<ChatMessage>>>()

            for (doc in convSnapshots.documents) {
                val remoteConv = doc.toObject(
                    RemoteConversation::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: continue
                val msgCol = doc.reference.collection("messages")
                path = msgCol.path
                val msgSnapshots = msgCol.get().await()
                val messages = msgSnapshots.documents.mapNotNull { mDoc ->
                    val rm = mDoc.toObject(
                        RemoteMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: return@mapNotNull null
                    val decryptedContent = cryptoManager.decryptFromCloud(rm.content, rm.encrypted)
                    ChatMessage(
                        id = rm.id,
                        conversationId = remoteConv.id,
                        role = rm.role,
                        content = decryptedContent,
                        attachmentName = rm.attachmentSummary,
                        modelName = rm.modelName,
                        createdAtMillis = rm.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                        updatedAtMillis = rm.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
                    )
                }.sortedBy { it.createdAtMillis }

                val decTitle = cryptoManager.decryptFromCloud(remoteConv.title, remoteConv.encrypted)
                val decPreview = cryptoManager.decryptFromCloud(remoteConv.lastMessagePreview, remoteConv.encrypted)
                val conv = Conversation(
                    id = remoteConv.id,
                    title = decTitle,
                    modelName = remoteConv.modelName,
                    lastMessagePreview = decPreview,
                    messageCount = messages.size.coerceAtLeast(remoteConv.messageCount.toInt()),
                    pinned = remoteConv.pinned,
                    contextSummary = "",
                    createdAtMillis = remoteConv.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                    updatedAtMillis = remoteConv.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
                )
                results.add(conv to messages)
            }
            Result.success(results)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun deleteRemoteConversation(conversationId: String): Result<Unit> {
        var path = "users/conversations"
        return try {
            val uid = requireUserId()
            val safeId = sanitizeDocId(conversationId)
            val convRef = db.collection("users").document(uid)
                .collection("conversations").document(safeId)
            path = convRef.path
            val msgs = convRef.collection("messages").get().await()
            for (m in msgs.documents) {
                m.reference.delete().await()
            }
            convRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun pushMemory(memory: MemoryItem): Result<Unit> {
        var path = "users/memories"
        return try {
            val uid = requireUserId()
            val safeId = sanitizeDocId(memory.id)
            val memRef = db.collection("users").document(uid)
                .collection("memories").document(safeId)
            path = memRef.path
            val (encContent, isEncrypted) = cryptoManager.encryptForCloud(memory.content.take(5500))
            val existing = memRef.get().await()
            if (existing.exists()) {
                memRef.update(
                    mapOf(
                        "category" to memory.category.id,
                        "content" to encContent.take(6000),
                        "encrypted" to isEncrypted,
                        "enabled" to memory.enabled,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                memRef.set(
                    mapOf(
                        "userId" to uid,
                        "category" to memory.category.id,
                        "content" to encContent.take(6000),
                        "encrypted" to isEncrypted,
                        "enabled" to memory.enabled,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun pullMemories(): Result<List<MemoryItem>> {
        var path = "users/memories"
        return try {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("memories")
            path = col.path
            val snaps = col.get().await()
            val list = snaps.documents.mapNotNull { doc ->
                val rm = doc.toObject(
                    RemoteMemory::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: return@mapNotNull null
                MemoryItem(
                    id = rm.id,
                    category = MemoryCategory.fromId(rm.category),
                    content = cryptoManager.decryptFromCloud(rm.content, rm.encrypted),
                    enabled = rm.enabled,
                    createdAtMillis = rm.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                    updatedAtMillis = rm.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
                )
            }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun deleteRemoteMemory(memoryId: String): Result<Unit> {
        var path = "users/memories"
        return try {
            val uid = requireUserId()
            val safeId = sanitizeDocId(memoryId)
            val memRef = db.collection("users").document(uid)
                .collection("memories").document(safeId)
            path = memRef.path
            memRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun pushNote(note: LocalNote): Result<Unit> {
        var path = "users/notes"
        return try {
            val uid = requireUserId()
            val safeId = sanitizeDocId(note.id)
            val noteRef = db.collection("users").document(uid)
                .collection("notes").document(safeId)
            path = noteRef.path
            val (encTitle, titleEnc) = cryptoManager.encryptForCloud(note.title.take(280))
            val (encBody, bodyEnc) = cryptoManager.encryptForCloud(note.content.take(70_000))
            val isEncrypted = titleEnc && bodyEnc
            val existing = noteRef.get().await()
            if (existing.exists()) {
                noteRef.update(
                    mapOf(
                        "title" to encTitle.take(300),
                        "content" to encBody.take(80_000),
                        "encrypted" to isEncrypted,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                noteRef.set(
                    mapOf(
                        "userId" to uid,
                        "title" to encTitle.take(300),
                        "content" to encBody.take(80_000),
                        "encrypted" to isEncrypted,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun pullNotes(): Result<List<LocalNote>> {
        var path = "users/notes"
        return try {
            val uid = requireUserId()
            val col = db.collection("users").document(uid).collection("notes")
            path = col.path
            val snaps = col.get().await()
            val list = snaps.documents.mapNotNull { doc ->
                val rn = doc.toObject(
                    RemoteNote::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: return@mapNotNull null
                LocalNote(
                    id = rn.id,
                    title = cryptoManager.decryptFromCloud(rn.title, rn.encrypted),
                    content = cryptoManager.decryptFromCloud(rn.content, rn.encrypted),
                    createdAtMillis = rn.createdAt?.toDate()?.time ?: System.currentTimeMillis(),
                    updatedAtMillis = rn.updatedAt?.toDate()?.time ?: System.currentTimeMillis()
                )
            }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun deleteRemoteNote(noteId: String): Result<Unit> {
        var path = "users/notes"
        return try {
            val uid = requireUserId()
            val safeId = sanitizeDocId(noteId)
            val noteRef = db.collection("users").document(uid)
                .collection("notes").document(safeId)
            path = noteRef.path
            noteRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteAllCloudData(): Result<Unit> {
        var path = "users"
        return try {
            val uid = requireUserId()
            val userRef = db.collection("users").document(uid)
            path = userRef.path

            val convs = userRef.collection("conversations").get().await()
            for (conv in convs.documents) {
                val msgs = conv.reference.collection("messages").get().await()
                for (msg in msgs.documents) {
                    msg.reference.delete().await()
                }
                conv.reference.delete().await()
            }

            val mems = userRef.collection("memories").get().await()
            for (mem in mems.documents) {
                mem.reference.delete().await()
            }

            val notes = userRef.collection("notes").get().await()
            for (note in notes.documents) {
                note.reference.delete().await()
            }

            userRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun sanitizeDocId(raw: String): String {
        val cleaned = raw.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        return cleaned.ifBlank { "doc_${System.currentTimeMillis()}" }.take(120)
    }
}
