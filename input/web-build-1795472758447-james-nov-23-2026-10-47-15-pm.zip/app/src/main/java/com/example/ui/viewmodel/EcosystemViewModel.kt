package com.example.ui.viewmodel

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.core.CloudBackendClient
import com.example.data.core.ConnectorProbeClient
import com.example.data.core.CouncilOrchestrator
import com.example.data.core.KnowledgeRetrievalEngine
import com.example.data.core.LearningOrchestrator
import com.example.data.core.McpHttpClient
import com.example.data.core.RepositoryMigrationEngine
import com.example.data.core.SkillsInspector
import com.example.data.ai.UnifiedModelClient
import com.example.data.local.JamesSettings
import com.example.data.local.PreferencesRepository
import com.example.data.model.AiProviderConfig
import com.example.data.model.ConnectorIntegration
import com.example.data.model.CouncilParticipantAssignment
import com.example.data.model.CouncilRole
import com.example.data.model.CouncilSession
import com.example.data.model.ExperienceOutcomeType
import com.example.data.model.ImprovementProposal
import com.example.data.model.KnowledgeItem
import com.example.data.model.KnowledgeMatch
import com.example.data.model.LearningExperience
import com.example.data.model.McpServerConfig
import com.example.data.model.McpTransport
import com.example.data.model.MigrationRecord
import com.example.data.model.ModelRuntimeType
import com.example.data.model.PrivateVaultItem
import com.example.data.model.ProposalApprovalStatus
import com.example.data.model.ProviderType
import com.example.data.model.RoutingPolicy
import com.example.data.model.ScheduledJobConfig
import com.example.data.model.SkillPackage
import com.example.data.model.SystemLogEntry
import com.example.data.model.ValidationStatus
import com.example.data.model.VaultItemType
import com.example.data.repository.EcosystemRepository
import com.example.security.PrivateVaultManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

class EcosystemViewModel(
    private val ecosystemRepository: EcosystemRepository,
    private val preferencesRepository: PreferencesRepository,
    private val unifiedModelClient: UnifiedModelClient,
    private val cloudBackendClient: CloudBackendClient,
    private val mcpHttpClient: McpHttpClient,
    private val connectorProbeClient: ConnectorProbeClient,
    private val councilOrchestrator: CouncilOrchestrator,
    private val learningOrchestrator: LearningOrchestrator,
    private val migrationEngine: RepositoryMigrationEngine,
    private val vaultManager: PrivateVaultManager,
    private val stagingFilesDir: File
) : ViewModel() {

    val settings: StateFlow<JamesSettings> = preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), JamesSettings())

    val providers: StateFlow<List<AiProviderConfig>> = ecosystemRepository.providersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val knowledgeItems: StateFlow<List<KnowledgeItem>> = ecosystemRepository.knowledgeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val experiences: StateFlow<List<LearningExperience>> = ecosystemRepository.experiencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val skills: StateFlow<List<SkillPackage>> = ecosystemRepository.skillsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mcpServers: StateFlow<List<McpServerConfig>> = ecosystemRepository.mcpServersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val connectors: StateFlow<List<ConnectorIntegration>> = ecosystemRepository.connectorsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val councilSessions: StateFlow<List<CouncilSession>> = ecosystemRepository.councilSessionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val proposals: StateFlow<List<ImprovementProposal>> = ecosystemRepository.proposalsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val privateVaultItems: StateFlow<List<PrivateVaultItem>> = ecosystemRepository.privateVaultFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scheduledJobs: StateFlow<List<ScheduledJobConfig>> = ecosystemRepository.scheduledJobsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val migrations: StateFlow<List<MigrationRecord>> = ecosystemRepository.migrationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val systemLogs: StateFlow<List<SystemLogEntry>> = ecosystemRepository.logsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    private val _knowledgeMatches = MutableStateFlow<List<KnowledgeMatch>>(emptyList())
    val knowledgeMatches: StateFlow<List<KnowledgeMatch>> = _knowledgeMatches.asStateFlow()

    private val _vaultPinConfigured = MutableStateFlow(vaultManager.isPinConfigured())
    val vaultPinConfigured: StateFlow<Boolean> = _vaultPinConfigured.asStateFlow()

    private val _vaultUnlocked = MutableStateFlow(vaultManager.isVaultUnlocked())
    val vaultUnlocked: StateFlow<Boolean> = _vaultUnlocked.asStateFlow()

    private val _diagnosticsReport = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val diagnosticsReport: StateFlow<List<Pair<String, String>>> = _diagnosticsReport.asStateFlow()

    init {
        viewModelScope.launch {
            ecosystemRepository.ensureDefaultsSeeded()
            refreshVaultState()
        }
    }

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun refreshVaultState() {
        val currentSettings = settings.value
        _vaultPinConfigured.value = vaultManager.isPinConfigured()
        _vaultUnlocked.value = vaultManager.isVaultUnlocked(currentSettings.vaultAutoLockMinutes)
    }

    // ---- Routing & Core Policies ----
    fun setRoutingPolicy(policy: RoutingPolicy) {
        viewModelScope.launch {
            preferencesRepository.setRoutingPolicy(policy)
            ecosystemRepository.addLog("INFO", "Policy", "Routing policy set to ${policy.labelEn}")
            _statusBanner.value = "Routing policy updated to ${policy.labelEn}"
        }
    }

    // ---- AI Providers & Open-Weight Runtime ----
    fun addOrUpdateProvider(
        existingId: String?,
        name: String,
        providerType: ProviderType,
        runtimeType: ModelRuntimeType,
        endpointUrl: String,
        modelId: String,
        enabled: Boolean,
        isPrimary: Boolean,
        apiKeyInput: String
    ) {
        viewModelScope.launch {
            val id = existingId ?: "prov_${UUID.randomUUID().toString().replace("-", "").take(10)}"
            val existing = providers.value.firstOrNull { it.id == id }
            val config = AiProviderConfig(
                id = id,
                name = name.trim().ifBlank { providerType.label },
                providerType = providerType,
                runtimeType = runtimeType,
                endpointUrl = endpointUrl.trim().ifBlank { providerType.defaultEndpoint },
                modelId = modelId.trim().ifBlank { "gemma3:12b-it" },
                enabled = enabled,
                isDefaultPrimary = isPrimary,
                estimatedInputCostPer1M = existing?.estimatedInputCostPer1M ?: if (providerType.isCommercialApi) 0.5 else 0.0,
                estimatedOutputCostPer1M = existing?.estimatedOutputCostPer1M ?: if (providerType.isCommercialApi) 1.5 else 0.0,
                totalRequests = existing?.totalRequests ?: 0,
                totalEstimatedTokens = existing?.totalEstimatedTokens ?: 0L,
                requestLimitPerDay = existing?.requestLimitPerDay ?: 500,
                lastStatus = if (apiKeyInput.isNotBlank()) "Key updated in Private Vault" else existing?.lastStatus ?: "Configured"
            )
            if (apiKeyInput.isNotBlank()) {
                vaultManager.storeCredential(id, apiKeyInput)
            }
            ecosystemRepository.saveProvider(config)
            ecosystemRepository.addLog("INFO", "Providers", "Saved provider ${config.name} (${config.modelId}).")
            _statusBanner.value = "Saved ${config.name}"
        }
    }

    fun setProviderPrimary(providerId: String) {
        viewModelScope.launch {
            ecosystemRepository.setDefaultPrimaryProvider(providerId)
            _statusBanner.value = "Primary model updated."
        }
    }

    fun toggleProviderEnabled(provider: AiProviderConfig) {
        viewModelScope.launch {
            ecosystemRepository.saveProvider(provider.copy(enabled = !provider.enabled))
        }
    }

    fun testProviderConnection(provider: AiProviderConfig) {
        viewModelScope.launch {
            _isBusy.value = true
            val key = vaultManager.getCredential(provider.id)
            val probe = unifiedModelClient.testConnection(provider, key)
            ecosystemRepository.saveProvider(
                provider.copy(
                    lastStatus = probe.statusMessage,
                    lastTestedMillis = System.currentTimeMillis()
                )
            )
            ecosystemRepository.addLog(
                if (probe.reachable) "INFO" else "WARN",
                "Providers",
                "Probe ${provider.name}: ${probe.statusMessage}"
            )
            _statusBanner.value = "${provider.name}: ${probe.statusMessage}"
            _isBusy.value = false
        }
    }

    fun hasProviderCredential(providerId: String): Boolean = vaultManager.hasCredential(providerId)
    fun maskedProviderCredential(providerId: String): String = vaultManager.getMaskedCredentialHint(providerId)

    // ---- AI Council ----
    fun runCouncilDiscussion(topic: String, mode: String, roleProviderMap: Map<CouncilRole, String>) {
        if (topic.isBlank()) {
            _statusBanner.value = "Enter a topic for JAMES AI Council."
            return
        }
        viewModelScope.launch {
            _isBusy.value = true
            val allProviders = ecosystemRepository.getProvidersOnce()
            val assignments = roleProviderMap.mapNotNull { (role, providerId) ->
                val prov = allProviders.firstOrNull { it.id == providerId } ?: return@mapNotNull null
                CouncilParticipantAssignment(prov.id, prov.name, role)
            }
            val currentSettings = settings.value
            val (_, proposal) = councilOrchestrator.conveneCouncil(
                topic = topic,
                mode = mode,
                assignments = assignments,
                maxRounds = currentSettings.councilMaxRounds,
                tokenBudget = currentSettings.councilMaxBudgetTokens
            )
            _statusBanner.value = "Council finished. Proposal '${proposal.title}' awaits human approval."
            _isBusy.value = false
        }
    }

    fun decideProposal(proposal: ImprovementProposal, decision: ProposalApprovalStatus) {
        viewModelScope.launch {
            councilOrchestrator.reviewProposal(proposal, decision)
            _statusBanner.value = "Proposal marked ${decision.id}"
        }
    }

    // ---- Knowledge & Learning ----
    fun ingestKnowledge(title: String, content: String, category: String, source: String, topicsCsv: String) {
        if (title.isBlank() || content.isBlank()) {
            _statusBanner.value = "Title and content are required."
            return
        }
        viewModelScope.launch {
            val hash = KnowledgeRetrievalEngine.sha256Hex(content)
            val duplicate = ecosystemRepository.findKnowledgeByChecksum(hash)
            if (duplicate != null) {
                _statusBanner.value = "Duplicate skipped: matches '${duplicate.title}'."
                return@launch
            }
            val chunks = KnowledgeRetrievalEngine.chunkText(content)
            val now = System.currentTimeMillis()
            val item = KnowledgeItem(
                id = "know_${UUID.randomUUID().toString().replace("-", "").take(10)}",
                title = title.trim(),
                content = content.trim(),
                category = category.trim().ifBlank { "General" },
                source = source.trim().ifBlank { "manual://user-entry" },
                sourceType = "MANUAL_INGEST",
                acquiredAtMillis = now,
                lastVerifiedAtMillis = now,
                reliabilityScore = 0.85f,
                confidence = 0.85f,
                topicsCsv = topicsCsv.trim().lowercase(),
                version = 1,
                validationStatus = ValidationStatus.VERIFIED,
                chunkCount = chunks.size.coerceAtLeast(1),
                checksumSha256 = hash
            )
            ecosystemRepository.saveKnowledgeItem(item)
            ecosystemRepository.addLog("INFO", "Knowledge", "Ingested '${item.title}' (${item.chunkCount} chunk(s)).")
            _statusBanner.value = "Ingested '${item.title}' (${item.chunkCount} chunk(s))"
        }
    }

    fun verifyKnowledgeItem(item: KnowledgeItem, status: ValidationStatus) {
        viewModelScope.launch {
            ecosystemRepository.saveKnowledgeItem(
                item.copy(
                    validationStatus = status,
                    lastVerifiedAtMillis = System.currentTimeMillis(),
                    version = item.version + 1
                )
            )
            _statusBanner.value = "Knowledge status -> ${status.id}"
        }
    }

    fun deleteKnowledgeItem(id: String) {
        viewModelScope.launch {
            ecosystemRepository.deleteKnowledgeItem(id)
        }
    }

    fun searchKnowledge(query: String) {
        _knowledgeMatches.value = if (query.isBlank()) {
            emptyList()
        } else {
            KnowledgeRetrievalEngine.search(query, knowledgeItems.value, topK = 6)
        }
    }

    fun runLearningCycleNow() {
        viewModelScope.launch {
            _isBusy.value = true
            val summary = learningOrchestrator.runBoundedLearningCycle()
            _statusBanner.value = summary
            _isBusy.value = false
        }
    }

    fun logManualExperience(task: String, outcome: ExperienceOutcomeType, rootCause: String, lesson: String) {
        if (task.isBlank() || lesson.isBlank()) return
        viewModelScope.launch {
            learningOrchestrator.recordInteractionOutcome(task, outcome, rootCause, lesson)
            _statusBanner.value = "Learning experience recorded."
        }
    }

    // ---- Skills, MCP & Connectors ----
    fun importSkill(name: String, markdown: String, category: String) {
        if (markdown.isBlank()) {
            _statusBanner.value = "Paste SKILL.md content first."
            return
        }
        viewModelScope.launch {
            val allowScripts = settings.value.allowSkillScriptExecution
            val inspection = SkillsInspector.inspectSkillMarkdown(markdown, allowScripts)
            val resolvedName = name.trim().ifBlank { inspection.extractedName ?: "Custom Skill" }
            val skill = SkillPackage(
                id = "skill_${UUID.randomUUID().toString().replace("-", "").take(10)}",
                name = resolvedName,
                description = inspection.extractedDescription ?: "Imported SKILL.md package",
                version = "1.0.0",
                category = category.trim().ifBlank { "General" },
                sourceType = "IMPORTED_MD",
                sourceUri = "local://imported",
                skillMarkdown = markdown.trim(),
                permissionsCsv = inspection.extractedPermissions.joinToString(",").ifBlank { "READ_KNOWLEDGE" },
                dependenciesCsv = "NONE",
                enabled = inspection.safeToEnable,
                inspected = inspection.safeToEnable,
                inspectionNotes = inspection.summary,
                updatedAtMillis = System.currentTimeMillis()
            )
            ecosystemRepository.saveSkill(skill)
            ecosystemRepository.addLog(
                if (inspection.safeToEnable) "INFO" else "WARN",
                "Skills",
                "Skill '${skill.name}': ${inspection.summary}"
            )
            _statusBanner.value = if (inspection.safeToEnable) {
                "Skill '${skill.name}' inspected & enabled."
            } else {
                "Skill saved DISABLED: ${inspection.summary}"
            }
        }
    }

    fun toggleSkill(skill: SkillPackage) {
        viewModelScope.launch {
            if (!skill.enabled && !skill.inspected) {
                _statusBanner.value = "Cannot activate unverified/flagged skill '${skill.name}'. Fix flagged rules first."
                return@launch
            }
            ecosystemRepository.saveSkill(skill.copy(enabled = !skill.enabled))
        }
    }

    fun setAllowSkillScripts(allowed: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setAllowSkillScriptExecution(allowed)
        }
    }

    fun saveMcpServer(name: String, transport: McpTransport, endpointUrl: String, requireApproval: Boolean, token: String) {
        if (name.isBlank() || endpointUrl.isBlank()) {
            _statusBanner.value = "Server name and endpoint URL are required."
            return
        }
        viewModelScope.launch {
            val id = "mcp_${UUID.randomUUID().toString().replace("-", "").take(10)}"
            if (token.isNotBlank()) {
                vaultManager.storeCredential(id, token)
            }
            val server = McpServerConfig(
                id = id,
                name = name.trim(),
                transport = transport,
                endpointUrl = endpointUrl.trim(),
                status = "Configured",
                discoveredToolsSummary = "Not queried yet",
                enabledToolsCsv = "",
                requireApprovalPerCall = requireApproval,
                lastConnectedMillis = 0L,
                logsText = "Saved at ${System.currentTimeMillis()}"
            )
            ecosystemRepository.saveMcpServer(server)
            _statusBanner.value = "MCP server '${server.name}' saved."
        }
    }

    fun discoverMcpTools(server: McpServerConfig) {
        viewModelScope.launch {
            _isBusy.value = true
            val token = vaultManager.getCredential(server.id)
            val result = mcpHttpClient.discoverTools(server, token)
            val updated = result.fold(
                onSuccess = { tools ->
                    server.copy(
                        status = "Connected (${tools.size} tool(s))",
                        discoveredToolsSummary = if (tools.isEmpty()) "Connected; 0 tools exposed" else tools.joinToString("\n"),
                        lastConnectedMillis = System.currentTimeMillis(),
                        logsText = "Discovered ${tools.size} tool(s)"
                    )
                },
                onFailure = { err ->
                    server.copy(
                        status = "Error",
                        logsText = PrivateVaultManager.redactSecrets(err.localizedMessage ?: "Discovery failed")
                    )
                }
            )
            ecosystemRepository.saveMcpServer(updated)
            _statusBanner.value = "${server.name}: ${updated.status}"
            _isBusy.value = false
        }
    }

    fun testConnector(connector: ConnectorIntegration, newEndpoint: String, newToken: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val updatedEndpoint = newEndpoint.trim().ifBlank { connector.endpointOrScope }
            if (newToken.isNotBlank()) {
                vaultManager.storeCredential(connector.id, newToken)
            }
            val candidate = connector.copy(endpointOrScope = updatedEndpoint)
            val token = vaultManager.getCredential(connector.id)
            val (ok, message) = connectorProbeClient.testConnector(candidate, token)
            ecosystemRepository.saveConnector(
                candidate.copy(
                    enabled = ok && candidate.isSupportedOfficially,
                    status = message,
                    lastCheckedMillis = System.currentTimeMillis()
                )
            )
            _statusBanner.value = message
            _isBusy.value = false
        }
    }

    // ---- Cloud Backend, Hosting & Migration ----
    fun saveAndTestBackend(baseUrl: String, bearerToken: String, enabled: Boolean) {
        viewModelScope.launch {
            _isBusy.value = true
            preferencesRepository.setBackendConfig(baseUrl, enabled)
            if (bearerToken.isNotBlank()) {
                vaultManager.storeCredential("james_cloud_backend", bearerToken)
            }
            if (baseUrl.isBlank()) {
                _statusBanner.value = "Backend URL cleared (local Android orchestration active)."
                _isBusy.value = false
                return@launch
            }
            val token = vaultManager.getCredential("james_cloud_backend")
            val result = cloudBackendClient.checkHealth(baseUrl, token)
            val msg = result.fold(
                onSuccess = { it },
                onFailure = { "Backend check failed: ${it.localizedMessage}" }
            )
            ecosystemRepository.addLog(if (result.isSuccess) "INFO" else "WARN", "CloudBackend", msg)
            _statusBanner.value = msg
            _isBusy.value = false
        }
    }

    fun runStagingMigration(sourceLabel: String, targetLabel: String) {
        viewModelScope.launch {
            _isBusy.value = true
            val payloadMap = linkedMapOf<String, String>()
            ecosystemRepository.getKnowledgeOnce().forEachIndexed { i, item ->
                payloadMap["knowledge_${i}_${item.id}.txt"] = "${item.title}\n${item.content}"
            }
            ecosystemRepository.getSkillsOnce().forEachIndexed { i, sk ->
                payloadMap["skill_${i}_${sk.id}.md"] = sk.skillMarkdown
            }
            if (payloadMap.isEmpty()) {
                payloadMap["manifest_readme.txt"] = "JAMES Independent Core Export Snapshot"
            }
            val record = migrationEngine.executeVerifiedStagingMigration(
                stagingDir = stagingFilesDir,
                sourceLabel = sourceLabel,
                targetLabel = targetLabel,
                payloads = payloadMap
            )
            _statusBanner.value = record.reportSummary
            _isBusy.value = false
        }
    }

    fun approveMigrationSourceCleanup(record: MigrationRecord) {
        viewModelScope.launch {
            runCatching { migrationEngine.approveSourceCleanup(record) }
                .onSuccess { _statusBanner.value = "Secondary approval applied for ${it.id}" }
                .onFailure { _statusBanner.value = it.localizedMessage }
        }
    }

    fun rollbackMigration(record: MigrationRecord) {
        viewModelScope.launch {
            migrationEngine.rollbackMigration(record)
            _statusBanner.value = "Rolled back ${record.id}"
        }
    }

    // ---- Scheduler ----
    fun toggleScheduledJob(job: ScheduledJobConfig) {
        viewModelScope.launch {
            ecosystemRepository.saveScheduledJob(job.copy(enabled = !job.enabled))
        }
    }

    fun runScheduledJobNow(job: ScheduledJobConfig) {
        viewModelScope.launch {
            _isBusy.value = true
            val summary = when (job.taskType) {
                "LEARNING_ANALYSIS" -> learningOrchestrator.runBoundedLearningCycle(job.maxBudgetTokens)
                "KNOWLEDGE_VERIFICATION" -> {
                    val items = ecosystemRepository.getKnowledgeOnce()
                    "Checked ${items.size} knowledge record(s); ${items.count { it.validationStatus == ValidationStatus.VERIFIED }} verified."
                }
                "PROVIDER_HEALTH_CHECK" -> {
                    val provs = ecosystemRepository.getProvidersOnce().filter { it.enabled }
                    val reachable = provs.count {
                        unifiedModelClient.testConnection(it, vaultManager.getCredential(it.id)).reachable
                    }
                    "$reachable/${provs.size} enabled provider(s) reachable."
                }
                else -> "Completed bounded job ${job.name}."
            }
            ecosystemRepository.saveScheduledJob(
                job.copy(
                    lastRunMillis = System.currentTimeMillis(),
                    lastStatus = "COMPLETED",
                    lastSummary = summary
                )
            )
            _statusBanner.value = summary
            _isBusy.value = false
        }
    }

    // ---- Private Vault ----
    fun setupVaultPin(pin: String) {
        val result = vaultManager.setupPin(pin)
        refreshVaultState()
        _statusBanner.value = result.fold(
            onSuccess = { "Private Vault PIN configured & unlocked." },
            onFailure = { it.localizedMessage ?: "Failed to set PIN." }
        )
    }

    fun unlockVaultWithPin(pin: String) {
        val ok = vaultManager.unlockWithPin(pin)
        refreshVaultState()
        _statusBanner.value = if (ok) "Private Vault unlocked." else "Incorrect Vault PIN."
    }

    fun unlockVaultWithBiometrics(activity: FragmentActivity) {
        vaultManager.promptBiometricUnlock(
            activity = activity,
            onSuccess = {
                refreshVaultState()
                _statusBanner.value = "Biometric verification succeeded."
            },
            onError = { err ->
                _statusBanner.value = err
            }
        )
    }

    fun lockVault() {
        vaultManager.lockVault()
        refreshVaultState()
        _statusBanner.value = "Private Vault locked."
    }

    fun setVaultAutoLockMinutes(minutes: Int) {
        viewModelScope.launch {
            preferencesRepository.setVaultAutoLockMinutes(minutes)
        }
    }

    fun addVaultItem(title: String, type: VaultItemType, content: String) {
        if (title.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            runCatching {
                ecosystemRepository.addPrivateVaultItem(title, type, content)
            }.onSuccess {
                vaultManager.touchActivity()
                _statusBanner.value = "Encrypted item saved to Private Vault."
            }.onFailure {
                _statusBanner.value = it.localizedMessage ?: "Unlock vault first."
            }
        }
    }

    fun deleteVaultItem(id: String) {
        viewModelScope.launch {
            ecosystemRepository.deletePrivateVaultItem(id)
        }
    }

    // ---- Diagnostics & Logs ----
    fun runSelfDiagnostics() {
        viewModelScope.launch {
            _isBusy.value = true
            val checks = mutableListOf<Pair<String, String>>()
            val provs = ecosystemRepository.getProvidersOnce()
            val primary = provs.firstOrNull { it.isDefaultPrimary }
            checks.add("Room Database v2" to "OK (${provs.size} providers, ${knowledgeItems.value.size} knowledge items)")
            checks.add("Private Vault Security" to if (vaultManager.isPinConfigured()) "PIN Configured · AutoLock ${settings.value.vaultAutoLockMinutes}m" else "PIN Not Configured")
            checks.add("Biometric Hardware" to if (vaultManager.isBiometricAvailable()) "Available" else "Not enrolled / Hardware absent")
            if (primary != null) {
                val probe = unifiedModelClient.testConnection(primary, vaultManager.getCredential(primary.id))
                checks.add("Primary Open-Weight (${primary.modelId})" to probe.statusMessage)
            }
            val backendUrl = settings.value.backendBaseUrl
            if (backendUrl.isNotBlank()) {
                val h = cloudBackendClient.checkHealth(backendUrl, vaultManager.getCredential("james_cloud_backend"))
                checks.add("JAMES Cloud Backend" to h.getOrElse { it.localizedMessage ?: "Unreachable" })
            } else {
                checks.add("JAMES Cloud Backend" to "Not configured (running standalone Android Core)")
            }
            checks.add("Active Skills Safety" to "${skills.value.count { it.enabled && it.inspected }}/${skills.value.size} verified & active")
            _diagnosticsReport.value = checks
            ecosystemRepository.addLog("INFO", "Diagnostics", "Completed system self-check (${checks.size} checks).")
            _isBusy.value = false
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            ecosystemRepository.clearLogs()
        }
    }
}
