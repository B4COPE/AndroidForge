package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.credentials.CredentialManager
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppLanguage
import com.example.di.JamesContainer
import com.example.security.configureAppCheck
import com.example.ui.i18n.LocalJamesStrings
import com.example.ui.i18n.stringsFor
import com.example.ui.navigation.JamesNavHost
import com.example.ui.theme.JamesTheme
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.EcosystemViewModel
import com.example.ui.viewmodel.MainAppViewModel
import com.example.util.attemptAutoSignIn

class MainActivity : FragmentActivity() {

    private lateinit var container: JamesContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // App Check MUST be configured before Firebase AI / Firestore / ViewModel initialization.
        configureAppCheck(this, intent)

        container = JamesContainer(applicationContext)
        enableEdgeToEdge()

        val credentialManager = CredentialManager.create(this)

        setContent {
            val factory = JamesViewModelFactory(container)
            val mainViewModel: MainAppViewModel = viewModel(factory = factory)
            val chatViewModel: ChatViewModel = viewModel(factory = factory)
            val ecosystemViewModel: EcosystemViewModel = viewModel(factory = factory)

            val settings by mainViewModel.settings.collectAsStateWithLifecycle()
            val isArabic = settings.appLanguage == AppLanguage.ARABIC
            val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
            val strings = stringsFor(settings.appLanguage)

            CompositionLocalProvider(
                LocalLayoutDirection provides layoutDirection,
                LocalJamesStrings provides strings
            ) {
                JamesTheme(
                    themeMode = settings.themeMode,
                    accent = settings.accent,
                    fontScale = settings.fontScale,
                    isArabic = isArabic
                ) {
                    JamesNavHost(
                        chatViewModel = chatViewModel,
                        mainViewModel = mainViewModel,
                        ecosystemViewModel = ecosystemViewModel
                    )
                }
            }
        }

        // Silent restore of prior Google session if user previously opted in; never blocks local-only use.
        attemptAutoSignIn(
            context = this,
            credentialManager = credentialManager,
            onAuthSuccess = {},
            onUnauthenticated = {},
            scope = lifecycleScope
        )
    }
}

private class JamesViewModelFactory(
    private val container: JamesContainer
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ChatViewModel::class.java) -> {
                ChatViewModel(
                    repository = container.repository,
                    aiService = container.aiService,
                    preferencesRepository = container.preferencesRepository,
                    networkMonitor = container.networkMonitor,
                    voiceOutputManager = container.voiceOutputManager,
                    jamesCoreOrchestrator = container.jamesCoreOrchestrator
                ) as T
            }
            modelClass.isAssignableFrom(MainAppViewModel::class.java) -> {
                MainAppViewModel(
                    repository = container.repository,
                    preferencesRepository = container.preferencesRepository,
                    cloudSyncRepository = container.cloudSyncRepository,
                    cryptoManager = container.cryptoManager,
                    networkMonitor = container.networkMonitor,
                    voiceInputManager = container.voiceInputManager,
                    voiceOutputManager = container.voiceOutputManager
                ) as T
            }
            modelClass.isAssignableFrom(EcosystemViewModel::class.java) -> {
                EcosystemViewModel(
                    ecosystemRepository = container.ecosystemRepository,
                    preferencesRepository = container.preferencesRepository,
                    unifiedModelClient = container.unifiedModelClient,
                    cloudBackendClient = container.cloudBackendClient,
                    mcpHttpClient = container.mcpHttpClient,
                    connectorProbeClient = container.connectorProbeClient,
                    councilOrchestrator = container.councilOrchestrator,
                    learningOrchestrator = container.learningOrchestrator,
                    migrationEngine = container.migrationEngine,
                    vaultManager = container.privateVaultManager,
                    stagingFilesDir = container.stagingFilesDir
                ) as T
            }
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
