package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryEntity::class,
        NoteEntity::class,
        KnowledgeEntity::class,
        LearningExperienceEntity::class,
        SkillEntity::class,
        McpServerEntity::class,
        ConnectorEntity::class,
        AiProviderEntity::class,
        CouncilSessionEntity::class,
        ImprovementProposalEntity::class,
        PrivateVaultEntity::class,
        ScheduledJobEntity::class,
        MigrationRecordEntity::class,
        SystemLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class JamesDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun noteDao(): NoteDao
    abstract fun ecosystemDao(): EcosystemDao

    companion object {
        @Volatile
        private var INSTANCE: JamesDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `knowledge_items` (
                        `id` TEXT NOT NULL, `title` TEXT NOT NULL, `content` TEXT NOT NULL,
                        `category` TEXT NOT NULL, `source` TEXT NOT NULL, `sourceType` TEXT NOT NULL,
                        `acquiredAtMillis` INTEGER NOT NULL, `lastVerifiedAtMillis` INTEGER NOT NULL,
                        `reliabilityScore` REAL NOT NULL, `confidence` REAL NOT NULL,
                        `topicsCsv` TEXT NOT NULL, `version` INTEGER NOT NULL,
                        `validationStatus` TEXT NOT NULL, `chunkCount` INTEGER NOT NULL,
                        `checksumSha256` TEXT NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_knowledge_items_checksumSha256` ON `knowledge_items` (`checksumSha256`)")

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `learning_experiences` (
                        `id` TEXT NOT NULL, `taskSummary` TEXT NOT NULL, `outcomeType` TEXT NOT NULL,
                        `rootCause` TEXT NOT NULL, `lessonLearned` TEXT NOT NULL,
                        `relatedSkillId` TEXT, `createdAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `skills` (
                        `id` TEXT NOT NULL, `name` TEXT NOT NULL, `description` TEXT NOT NULL,
                        `version` TEXT NOT NULL, `category` TEXT NOT NULL, `sourceType` TEXT NOT NULL,
                        `sourceUri` TEXT NOT NULL, `skillMarkdown` TEXT NOT NULL, `permissionsCsv` TEXT NOT NULL,
                        `dependenciesCsv` TEXT NOT NULL, `enabled` INTEGER NOT NULL,
                        `inspected` INTEGER NOT NULL, `inspectionNotes` TEXT NOT NULL,
                        `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `mcp_servers` (
                        `id` TEXT NOT NULL, `name` TEXT NOT NULL, `transport` TEXT NOT NULL,
                        `endpointUrl` TEXT NOT NULL, `status` TEXT NOT NULL,
                        `discoveredToolsSummary` TEXT NOT NULL, `enabledToolsCsv` TEXT NOT NULL,
                        `requireApprovalPerCall` INTEGER NOT NULL, `lastConnectedMillis` INTEGER NOT NULL,
                        `logsText` TEXT NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `connectors` (
                        `id` TEXT NOT NULL, `providerKey` TEXT NOT NULL, `displayName` TEXT NOT NULL,
                        `category` TEXT NOT NULL, `endpointOrScope` TEXT NOT NULL, `authMode` TEXT NOT NULL,
                        `isSupportedOfficially` INTEGER NOT NULL, `enabled` INTEGER NOT NULL,
                        `status` TEXT NOT NULL, `notes` TEXT NOT NULL,
                        `lastCheckedMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `ai_providers` (
                        `id` TEXT NOT NULL, `name` TEXT NOT NULL, `providerType` TEXT NOT NULL,
                        `runtimeType` TEXT NOT NULL, `endpointUrl` TEXT NOT NULL, `modelId` TEXT NOT NULL,
                        `enabled` INTEGER NOT NULL, `isDefaultPrimary` INTEGER NOT NULL,
                        `estimatedInputCostPer1M` REAL NOT NULL, `estimatedOutputCostPer1M` REAL NOT NULL,
                        `totalRequests` INTEGER NOT NULL, `totalEstimatedTokens` INTEGER NOT NULL,
                        `requestLimitPerDay` INTEGER NOT NULL, `lastStatus` TEXT NOT NULL,
                        `lastTestedMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `council_sessions` (
                        `id` TEXT NOT NULL, `topic` TEXT NOT NULL, `mode` TEXT NOT NULL,
                        `status` TEXT NOT NULL, `maxRounds` INTEGER NOT NULL, `roundsCompleted` INTEGER NOT NULL,
                        `participantsSummary` TEXT NOT NULL, `transcriptMarkdown` TEXT NOT NULL,
                        `agreementsText` TEXT NOT NULL, `disagreementsText` TEXT NOT NULL,
                        `conclusionText` TEXT NOT NULL, `estimatedTokensUsed` INTEGER NOT NULL,
                        `createdAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `improvement_proposals` (
                        `id` TEXT NOT NULL, `sessionId` TEXT NOT NULL, `title` TEXT NOT NULL,
                        `problemDescription` TEXT NOT NULL, `proposedSolution` TEXT NOT NULL,
                        `expectedBenefits` TEXT NOT NULL, `potentialRisks` TEXT NOT NULL,
                        `dependenciesText` TEXT NOT NULL, `implementationPlan` TEXT NOT NULL,
                        `testPlan` TEXT NOT NULL, `rollbackPlan` TEXT NOT NULL,
                        `approvalStatus` TEXT NOT NULL, `createdAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `private_vault_items` (
                        `id` TEXT NOT NULL, `title` TEXT NOT NULL, `itemType` TEXT NOT NULL,
                        `encryptedPayload` TEXT NOT NULL, `updatedAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `scheduled_jobs` (
                        `id` TEXT NOT NULL, `name` TEXT NOT NULL, `taskType` TEXT NOT NULL,
                        `intervalHours` INTEGER NOT NULL, `enabled` INTEGER NOT NULL,
                        `maxBudgetTokens` INTEGER NOT NULL, `lastRunMillis` INTEGER NOT NULL,
                        `lastStatus` TEXT NOT NULL, `lastSummary` TEXT NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `migration_records` (
                        `id` TEXT NOT NULL, `sourceProvider` TEXT NOT NULL, `targetProvider` TEXT NOT NULL,
                        `status` TEXT NOT NULL, `totalFiles` INTEGER NOT NULL, `transferredFiles` INTEGER NOT NULL,
                        `checksumManifestSha256` TEXT NOT NULL, `reportSummary` TEXT NOT NULL,
                        `sourceDeleteApproved` INTEGER NOT NULL, `createdAtMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `system_logs` (
                        `id` TEXT NOT NULL, `level` TEXT NOT NULL, `component` TEXT NOT NULL,
                        `message` TEXT NOT NULL, `timestampMillis` INTEGER NOT NULL, PRIMARY KEY(`id`)
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): JamesDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    JamesDatabase::class.java,
                    "james_encrypted_vault.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
