package com.example.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Isolated Private Vault & API Credential Security Manager.
 * - Uses a dedicated Android Keystore AES-256-GCM key ("james_private_vault_aes256_key")
 *   separate from standard conversation storage.
 * - Supports PIN protection via PBKDF2WithHmacSHA256 + random salt + constant-time verify.
 * - Supports Android BiometricPrompt authentication when enrolled on the device.
 * - Enforces configurable auto-lock timeout and strict secret redaction for logs.
 */
class PrivateVaultManager(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(VAULT_PREFS_NAME, Context.MODE_PRIVATE)
    private val keyLock = Any()

    @Volatile
    private var unlocked: Boolean = false

    @Volatile
    private var lastActivityMillis: Long = 0L

    @Volatile
    private var sessionVaultKey: SecretKey? = null

    fun isPinConfigured(): Boolean = !prefs.getString(KEY_PIN_HASH, null).isNullOrBlank()

    fun isVaultUnlocked(autoLockMinutes: Int = 5): Boolean {
        if (!isPinConfigured()) return false
        if (!unlocked) return false
        if (autoLockMinutes > 0 && lastActivityMillis > 0L) {
            val elapsed = System.currentTimeMillis() - lastActivityMillis
            if (elapsed > autoLockMinutes * 60_000L) {
                lockVault()
                return false
            }
        }
        return true
    }

    fun touchActivity() {
        if (unlocked) {
            lastActivityMillis = System.currentTimeMillis()
        }
    }

    fun lockVault() {
        unlocked = false
        sessionVaultKey = null
        lastActivityMillis = 0L
    }

    fun setupPin(pin: String): Result<Unit> = runCatching {
        require(pin.length >= 4) { "Vault PIN must be at least 4 characters." }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP)
        val hashB64 = derivePinDigest(pin, salt)
        prefs.edit()
            .putString(KEY_PIN_SALT, saltB64)
            .putString(KEY_PIN_HASH, hashB64)
            .apply()
        sessionVaultKey = deriveAesKeyFromPin(pin, salt)
        unlocked = true
        lastActivityMillis = System.currentTimeMillis()
    }

    fun unlockWithPin(pin: String): Boolean {
        val saltB64 = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val expectedHashB64 = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        val candidateHash = derivePinDigest(pin, salt)
        val ok = MessageDigest.isEqual(
            candidateHash.toByteArray(StandardCharsets.UTF_8),
            expectedHashB64.toByteArray(StandardCharsets.UTF_8)
        )
        if (ok) {
            sessionVaultKey = deriveAesKeyFromPin(pin, salt)
            unlocked = true
            lastActivityMillis = System.currentTimeMillis()
        }
        return ok
    }

    fun isBiometricAvailable(): Boolean {
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.BIOMETRIC_WEAK
        return BiometricManager.from(appContext).canAuthenticate(authenticators) ==
            BiometricManager.BIOMETRIC_SUCCESS
    }

    fun markBiometricUnlocked() {
        unlocked = true
        lastActivityMillis = System.currentTimeMillis()
    }

    fun promptBiometricUnlock(
        activity: FragmentActivity,
        title: String = "Unlock JAMES Private Vault",
        subtitle: String = "Verify your identity to access isolated private data",
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(
            activity,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    markBiometricUnlocked()
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    onError(errString.toString())
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    onError("Biometric verification failed.")
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(subtitle)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            .setNegativeButtonText("Use PIN")
            .build()
        prompt.authenticate(info)
    }

    /**
     * Encrypts sensitive Private Vault item payloads using dedicated Android Keystore AES-256-GCM.
     * Falls back to session PBKDF2 key in Robolectric JVM environments where AndroidKeyStore is absent.
     */
    fun encryptVaultPayload(plaintext: String): String {
        if (plaintext.isEmpty()) return plaintext
        val key = getOrCreateVaultKeystoreKey() ?: sessionVaultKey
            ?: throw IllegalStateException("Vault encryption key unavailable. Set PIN or unlock vault first.")
        return VAULT_CIPHER_PREFIX + encryptAesGcm(plaintext, key)
    }

    fun decryptVaultPayload(stored: String): String {
        if (!stored.startsWith(VAULT_CIPHER_PREFIX)) return stored
        val key = getOrCreateVaultKeystoreKey() ?: sessionVaultKey
            ?: return "[Locked — Unlock Private Vault]"
        return try {
            decryptAesGcm(stored.removePrefix(VAULT_CIPHER_PREFIX), key)
        } catch (e: Exception) {
            Log.e(TAG, "Private vault decryption failed")
            "[Unable to decrypt Private Vault item]"
        }
    }

    /**
     * Stores an API token/credential for a provider or backend strictly encrypted in isolated vault storage.
     * Never logged, never serialized in Chat export, and never synced unencrypted.
     */
    fun storeCredential(credentialId: String, rawSecret: String) {
        val trimmed = rawSecret.trim()
        if (trimmed.isEmpty()) {
            clearCredential(credentialId)
            return
        }
        val key = getOrCreateVaultKeystoreKey() ?: sessionVaultKey ?: fallbackDeviceKeyForJvmTests()
        val encrypted = CRED_CIPHER_PREFIX + encryptAesGcm(trimmed, key)
        prefs.edit().putString("$KEY_CRED_PREFIX$credentialId", encrypted).apply()
    }

    fun getCredential(credentialId: String): String? {
        val stored = prefs.getString("$KEY_CRED_PREFIX$credentialId", null) ?: return null
        if (!stored.startsWith(CRED_CIPHER_PREFIX)) return stored
        val key = getOrCreateVaultKeystoreKey() ?: sessionVaultKey ?: fallbackDeviceKeyForJvmTests()
        return try {
            decryptAesGcm(stored.removePrefix(CRED_CIPHER_PREFIX), key)
        } catch (e: Exception) {
            Log.e(TAG, "Credential decryption failed for $credentialId")
            null
        }
    }

    fun hasCredential(credentialId: String): Boolean =
        !prefs.getString("$KEY_CRED_PREFIX$credentialId", null).isNullOrBlank()

    fun getMaskedCredentialHint(credentialId: String): String {
        val raw = getCredential(credentialId) ?: return "Not configured"
        if (raw.length <= 8) return "Configured (****)"
        return "${raw.take(4)}••••••••${raw.takeLast(4)}"
    }

    fun clearCredential(credentialId: String) {
        prefs.edit().remove("$KEY_CRED_PREFIX$credentialId").apply()
    }

    fun clearAllVaultData() {
        lockVault()
        prefs.edit().clear().apply()
    }

    private fun derivePinDigest(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val bytes = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun deriveAesKeyFromPin(pin: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val bytes = factory.generateSecret(spec).encoded
        spec.clearPassword()
        return SecretKeySpec(bytes, "AES")
    }

    private fun encryptAesGcm(plaintext: String, key: SecretKey): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val cipherBytes = cipher.doFinal(plaintext.toByteArray(StandardCharsets.UTF_8))
        val combined = ByteArray(1 + iv.size + cipherBytes.size)
        combined[0] = iv.size.toByte()
        System.arraycopy(iv, 0, combined, 1, iv.size)
        System.arraycopy(cipherBytes, 0, combined, 1 + iv.size, cipherBytes.size)
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decryptAesGcm(encoded: String, key: SecretKey): String {
        val combined = Base64.decode(encoded, Base64.NO_WRAP)
        require(combined.size > 14) { "Invalid vault payload." }
        val ivLen = combined[0].toInt() and 0xFF
        require(ivLen in 12..16 && combined.size > 1 + ivLen) { "Invalid vault IV." }
        val iv = combined.copyOfRange(1, 1 + ivLen)
        val cipherBytes = combined.copyOfRange(1 + ivLen, combined.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(cipherBytes), StandardCharsets.UTF_8)
    }

    private fun getOrCreateVaultKeystoreKey(): SecretKey? {
        synchronized(keyLock) {
            return try {
                val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
                (ks.getKey(VAULT_KEY_ALIAS, null) as? SecretKey) ?: run {
                    val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                    val spec = KeyGenParameterSpec.Builder(
                        VAULT_KEY_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256)
                        .build()
                    kg.init(spec)
                    kg.generateKey()
                }
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun fallbackDeviceKeyForJvmTests(): SecretKey {
        // Used strictly when AndroidKeyStore is absent in non-device JVM test runners.
        val raw = MessageDigest.getInstance("SHA-256")
            .digest(appContext.packageName.toByteArray(StandardCharsets.UTF_8))
        return SecretKeySpec(raw, "AES")
    }

    companion object {
        private const val TAG = "PrivateVaultManager"
        private const val VAULT_PREFS_NAME = "james_isolated_private_vault"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val VAULT_KEY_ALIAS = "james_private_vault_aes256_key"
        private const val KEY_PIN_SALT = "vault_pin_salt"
        private const val KEY_PIN_HASH = "vault_pin_hash"
        private const val KEY_CRED_PREFIX = "cred_"
        private const val VAULT_CIPHER_PREFIX = "vault:v1:"
        private const val CRED_CIPHER_PREFIX = "cred:v1:"
        private const val PBKDF2_ITERATIONS = 100_000

        private val SECRET_REGEXES = listOf(
            Regex("""sk-[A-Za-z0-9\-_]{16,}"""),
            Regex("""AIza[0-9A-Za-z\-_]{20,}"""),
            Regex("""Bearer\s+[A-Za-z0-9\-_.~+/=]{12,}""", RegexOption.IGNORE_CASE),
            Regex("""(x-api-key|api_key|apiKey|token|password|secret)["':=\s]+[^\s,;}"']{6,}""", RegexOption.IGNORE_CASE)
        )

        fun redactSecrets(input: String): String {
            var clean = input
            SECRET_REGEXES.forEach { regex ->
                clean = clean.replace(regex, "[REDACTED]")
            }
            return clean
        }
    }
}
