package com.example.data.ai

import com.example.data.model.AiProviderConfig
import com.example.data.model.ModelRuntimeType
import com.example.data.model.ProviderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class UnifiedInferenceResponse(
    val text: String,
    val providerId: String,
    val providerName: String,
    val modelId: String,
    val estimatedTokens: Long,
    val latencyMs: Long
)

data class ProviderProbeResult(
    val reachable: Boolean,
    val statusMessage: String,
    val discoveredModels: List<String> = emptyList(),
    val latencyMs: Long = 0L
)

/**
 * Unified HTTP inference & health-check client for JAMES's Model Abstraction Layer:
 * - Self-hosted Open-Weight Runtimes: Ollama (/api/chat), llama.cpp (/v1/chat/completions), vLLM (/v1/chat/completions)
 * - External Providers: OpenAI, Anthropic Claude, DeepSeek, Custom OpenAI-compatible endpoints
 *
 * Credentials are supplied per-call from PrivateVaultManager and never persisted in logs or chat history.
 */
class UnifiedModelClient(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun generate(
        provider: AiProviderConfig,
        apiKey: String?,
        systemPrompt: String,
        messages: List<Pair<String, String>>,
        temperature: Float = 0.6f,
        maxTokens: Int = 1400
    ): UnifiedInferenceResponse = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        val endpoint = normalizeEndpoint(provider)
        require(endpoint.isNotBlank()) { "${provider.name} endpoint URL is empty." }

        if (provider.providerType.isCommercialApi &&
            provider.providerType != ProviderType.CUSTOM_OPENAI &&
            apiKey.isNullOrBlank()
        ) {
            throw IllegalStateException("API key is not configured for ${provider.name}. Add it in Control Center -> AI Providers.")
        }

        val text = when {
            provider.runtimeType == ModelRuntimeType.OLLAMA ||
                (provider.providerType == ProviderType.JAMES_PRIMARY_OPEN_WEIGHT &&
                    provider.runtimeType == ModelRuntimeType.OLLAMA) -> {
                invokeOllama(endpoint, provider.modelId, systemPrompt, messages, temperature, maxTokens)
            }
            provider.providerType == ProviderType.ANTHROPIC -> {
                invokeAnthropic(endpoint, apiKey.orEmpty(), provider.modelId, systemPrompt, messages, temperature, maxTokens)
            }
            else -> {
                invokeOpenAiCompatible(endpoint, apiKey, provider.modelId, systemPrompt, messages, temperature, maxTokens)
            }
        }

        val elapsed = (System.currentTimeMillis() - started).coerceAtLeast(1L)
        val estimatedTokens = ((systemPrompt.length + messages.sumOf { it.second.length } + text.length) / 4.0)
            .toLong().coerceAtLeast(1L)

        UnifiedInferenceResponse(
            text = text,
            providerId = provider.id,
            providerName = provider.name,
            modelId = provider.modelId,
            estimatedTokens = estimatedTokens,
            latencyMs = elapsed
        )
    }

    suspend fun testConnection(
        provider: AiProviderConfig,
        apiKey: String?
    ): ProviderProbeResult = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        if (provider.providerType == ProviderType.FIREBASE_AI_LOGIC) {
            return@withContext ProviderProbeResult(
                reachable = true,
                statusMessage = "Configured via Firebase AI Logic + App Check SDK",
                discoveredModels = GeminiModelCatalog.models.map { it.id },
                latencyMs = 1L
            )
        }

        val base = provider.endpointUrl.trim().trimEnd('/')
        if (base.isBlank()) {
            return@withContext ProviderProbeResult(
                reachable = false,
                statusMessage = "Endpoint URL is not set."
            )
        }
        if (provider.providerType.isCommercialApi &&
            provider.providerType != ProviderType.CUSTOM_OPENAI &&
            apiKey.isNullOrBlank()
        ) {
            return@withContext ProviderProbeResult(
                reachable = false,
                statusMessage = "Missing API credential in Private Vault."
            )
        }

        return@withContext try {
            when {
                provider.runtimeType == ModelRuntimeType.OLLAMA -> {
                    val req = Request.Builder().url("$base/api/tags").get().build()
                    httpClient.newCall(req).execute().use { resp ->
                        val body = resp.body?.string().orEmpty()
                        val latency = System.currentTimeMillis() - started
                        if (!resp.isSuccessful) {
                            ProviderProbeResult(false, "HTTP ${resp.code}: ${body.take(140)}", latencyMs = latency)
                        } else {
                            val modelsArr = JSONObject(body).optJSONArray("models") ?: JSONArray()
                            val names = buildList {
                                for (i in 0 until modelsArr.length()) {
                                    add(modelsArr.optJSONObject(i)?.optString("name").orEmpty())
                                }
                            }.filter { it.isNotBlank() }
                            ProviderProbeResult(
                                reachable = true,
                                statusMessage = "Ollama online (${names.size} model(s) ready)",
                                discoveredModels = names,
                                latencyMs = latency
                            )
                        }
                    }
                }
                provider.providerType == ProviderType.ANTHROPIC -> {
                    val req = Request.Builder()
                        .url("https://api.anthropic.com/v1/models")
                        .addHeader("x-api-key", apiKey.orEmpty())
                        .addHeader("anthropic-version", "2023-06-01")
                        .get()
                        .build()
                    httpClient.newCall(req).execute().use { resp ->
                        val latency = System.currentTimeMillis() - started
                        if (resp.isSuccessful) {
                            ProviderProbeResult(true, "Anthropic API key verified (HTTP ${resp.code})", latencyMs = latency)
                        } else {
                            ProviderProbeResult(false, "Anthropic check returned HTTP ${resp.code}", latencyMs = latency)
                        }
                    }
                }
                else -> {
                    val modelsUrl = if (base.endsWith("/chat/completions")) {
                        base.removeSuffix("/chat/completions") + "/models"
                    } else if (base.endsWith("/v1")) {
                        "$base/models"
                    } else {
                        "$base/v1/models"
                    }
                    val builder = Request.Builder().url(modelsUrl).get()
                    if (!apiKey.isNullOrBlank()) {
                        builder.addHeader("Authorization", "Bearer $apiKey")
                    }
                    httpClient.newCall(builder.build()).execute().use { resp ->
                        val latency = System.currentTimeMillis() - started
                        if (resp.isSuccessful) {
                            val body = resp.body?.string().orEmpty()
                            val data = runCatching { JSONObject(body).optJSONArray("data") }.getOrNull()
                            val ids = buildList {
                                if (data != null) {
                                    for (i in 0 until data.length()) {
                                        add(data.optJSONObject(i)?.optString("id").orEmpty())
                                    }
                                }
                            }.filter { it.isNotBlank() }
                            ProviderProbeResult(
                                reachable = true,
                                statusMessage = "Endpoint reachable (${ids.size} model(s))",
                                discoveredModels = ids,
                                latencyMs = latency
                            )
                        } else {
                            ProviderProbeResult(false, "Endpoint check returned HTTP ${resp.code}", latencyMs = latency)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            ProviderProbeResult(
                reachable = false,
                statusMessage = "Unreachable: ${e.localizedMessage ?: "Connection failed"}",
                latencyMs = System.currentTimeMillis() - started
            )
        }
    }

    private fun invokeOllama(
        baseOrUrl: String,
        modelId: String,
        systemPrompt: String,
        messages: List<Pair<String, String>>,
        temperature: Float,
        maxTokens: Int
    ): String {
        val url = if (baseOrUrl.endsWith("/api/chat")) baseOrUrl else "${baseOrUrl.trimEnd('/')}/api/chat"
        val msgArray = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            messages.forEach { (role, text) ->
                put(JSONObject().put("role", if (role == "assistant") "assistant" else "user").put("content", text))
            }
        }
        val payload = JSONObject()
            .put("model", modelId)
            .put("stream", false)
            .put("messages", msgArray)
            .put(
                "options",
                JSONObject()
                    .put("temperature", temperature.toDouble())
                    .put("num_predict", maxTokens)
            )

        val request = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        httpClient.newCall(request).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IllegalStateException("Ollama HTTP ${resp.code}: ${raw.take(240)}")
            }
            val parsed = JSONObject(raw)
            val content = parsed.optJSONObject("message")?.optString("content").orEmpty()
                .ifBlank { parsed.optString("response") }
            if (content.isBlank()) throw IllegalStateException("Ollama returned an empty response.")
            return content
        }
    }

    private fun invokeOpenAiCompatible(
        url: String,
        apiKey: String?,
        modelId: String,
        systemPrompt: String,
        messages: List<Pair<String, String>>,
        temperature: Float,
        maxTokens: Int
    ): String {
        val msgArray = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            messages.forEach { (role, text) ->
                put(JSONObject().put("role", if (role == "assistant") "assistant" else "user").put("content", text))
            }
        }
        val payload = JSONObject()
            .put("model", modelId)
            .put("temperature", temperature.toDouble())
            .put("max_tokens", maxTokens)
            .put("messages", msgArray)

        val builder = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody(jsonMediaType))
        if (!apiKey.isNullOrBlank()) {
            builder.addHeader("Authorization", "Bearer $apiKey")
        }

        httpClient.newCall(builder.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IllegalStateException("Provider HTTP ${resp.code}: ${raw.take(240)}")
            }
            val choices = JSONObject(raw).optJSONArray("choices")
            val content = choices?.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()
            if (content.isBlank()) throw IllegalStateException("Provider returned empty choices.")
            return content
        }
    }

    private fun invokeAnthropic(
        url: String,
        apiKey: String,
        modelId: String,
        systemPrompt: String,
        messages: List<Pair<String, String>>,
        temperature: Float,
        maxTokens: Int
    ): String {
        val msgArray = JSONArray().apply {
            messages.forEach { (role, text) ->
                put(JSONObject().put("role", if (role == "assistant") "assistant" else "user").put("content", text))
            }
        }
        val payload = JSONObject()
            .put("model", modelId)
            .put("system", systemPrompt)
            .put("temperature", temperature.toDouble())
            .put("max_tokens", maxTokens)
            .put("messages", msgArray)

        val request = Request.Builder()
            .url(url)
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        httpClient.newCall(request).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IllegalStateException("Anthropic HTTP ${resp.code}: ${raw.take(240)}")
            }
            val contentArray = JSONObject(raw).optJSONArray("content")
            val text = buildString {
                if (contentArray != null) {
                    for (i in 0 until contentArray.length()) {
                        val block = contentArray.optJSONObject(i)
                        if (block?.optString("type") == "text") {
                            append(block.optString("text"))
                        }
                    }
                }
            }
            if (text.isBlank()) throw IllegalStateException("Anthropic returned empty content.")
            return text
        }
    }

    private fun normalizeEndpoint(provider: AiProviderConfig): String {
        val raw = provider.endpointUrl.trim().trimEnd('/')
        if (raw.isBlank()) return ""
        return when {
            provider.runtimeType == ModelRuntimeType.OLLAMA -> raw
            provider.providerType == ProviderType.ANTHROPIC ->
                if (raw.endsWith("/messages")) raw else "$raw/v1/messages"
            raw.endsWith("/chat/completions") -> raw
            raw.endsWith("/v1") -> "$raw/chat/completions"
            else -> "$raw/v1/chat/completions"
        }
    }
}
