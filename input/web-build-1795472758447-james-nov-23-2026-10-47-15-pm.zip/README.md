# JAMES — Independent Personal AI Ecosystem

> **Founder & Developer:** **Abbas Adel Rahim** *(also known as **Cope / Mark**)*  
> **Project Status:** Independent Native Android App (Kotlin + Jetpack Compose + Material 3) + Standalone Cloud Core Backend (Node.js)

---

## Independence & Identity Statement

**JAMES is an independent artificial intelligence project**, founded and developed by **Abbas Adel Rahim (Cope / Mark)**.  
JAMES is **not** an official product of Google, OpenAI, Anthropic, DeepSeek, Meta, or Alibaba, nor is it officially affiliated with any external AI vendor. External models and cloud APIs serve strictly as optional collaborators or inference backends underneath **JAMES Core**.

**Vision:** Enable a personal AI ecosystem that owns its identity, persistent memory, verified knowledge, learning history, security vault, skills, and routing policies without permanent commercial vendor lock-in.

---

## Key Subsystems Built

1. **Native Android App (Preserved + Expanded Ecosystem)**
   - **14 Core Preserved Screens:** Splash, Onboarding (EN/AR RTL), Home Chat workspace (Markdown tables/headings/syntax-highlighted code/copy/edit/regenerate/delete/stop), Conversation History + Offline Notes, Individual Conversation, Voice Mode (`SpeechRecognizer` + `TextToSpeech` EN/AR), Personal Memory, Account & E2EE Cloud Sync (Google Sign-In + Firestore), AI Settings, General Settings, Appearance, Privacy & Data Export, Attachment Preview (Photo Picker + SAF PDF/Text), About JAMES.
   - **8 Expanded Ecosystem Control Screens:**
     - **Control Center (22 subsystem hubs)**
     - **AI Council Dashboard** (8 configurable roles, multi-round bounded deliberation, disagreement preservation, explicit human Approve/Reject/Rollback gates)
     - **Open-Weight & AI Providers** (Gemma 3 / Qwen 2.5 / Llama 3.1 catalog, Ollama / `llama.cpp` / vLLM runtimes, OpenAI / Anthropic / DeepSeek / Custom OpenAI credentials, live `Test`, usage/cost counters)
     - **Knowledge & Continuous Learning** (Overlapping chunker, SHA-256 deduplication, TF-IDF hybrid retrieval, verification lifecycle, error/gap experience learning)
     - **Extensions Hub** (Inspected `SKILL.md` Skills Manager, Streamable HTTP / HTTP+SSE MCP Client with prompt-injection wrapping, Connectors + transparent TeraBox limitation)
     - **Cloud Backend & Migration Center** (Oracle Cloud Always Free hosting guide, Cloud Core URL/auth config, 13-step SHA-256 verified repository migration staging + secondary deletion gate, bounded scheduler)
     - **Isolated Private Vault** (Separate Android Keystore AES-256-GCM key, PBKDF2-HMAC-SHA256 PIN lock, `BiometricPrompt`, auto-lock timeout)
     - **Diagnostics & System Logs** (Live self-check + secret-redacted audit logs)

2. **Standalone Cloud Core Backend (`/backend/`)**
   - Zero-bloat Node.js HTTP service mirroring JAMES Core orchestration, Knowledge TF-IDF retrieval, 8-role AI Council, Learning Engine, `SKILL.md` inspector, MCP HTTP Client, Storage/Migration SHA-256 Manager, SSRF/path-traversal/timing-safe Auth protections, and bounded Scheduler.
   - Modular Docker Compose profiles (`ollama`, `llamacpp`, `vllm`) + `backend/deploy/oci-always-free-setup.sh`.

---

## Quick Start

### 1. Build & Test Android App
```bash
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```
*(Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`)*

### 2. Run & Test Cloud Core Backend
```bash
node --test backend/test/backend.test.js
node backend/src/server.js
```

---

## Documentation Index

- `docs/ARCHITECTURE.md` — Layered architecture, JAMES Core routing, and component diagrams
- `docs/SECURITY.md` — Threat model, Private Vault, SSRF guards, MCP untrusted wrapping, and log redaction
- `docs/DATABASE_SCHEMA.md` — Room Database v1 -> v2 schema & `MIGRATION_1_2` specification
- `docs/MODEL_INTEGRATION_GUIDE.md` — Gemma 3, Qwen 2.5, Llama 3.1, Ollama, llama.cpp, vLLM & QLoRA notes
- `docs/AI_PROVIDER_GUIDE.md` — Connecting Firebase AI Logic, OpenAI, Anthropic, DeepSeek, and custom endpoints
- `docs/AI_COUNCIL.md` — 8-role collaborative governance & proposal approval gates
- `docs/LEARNING_ENGINE.md` — Knowledge chunking, SHA-256 dedup, TF-IDF retrieval & continuous learning
- `docs/CLOUD_HOSTING_GUIDE.md` — Oracle Cloud Infrastructure Always Free ARM64 setup vs serverless tiers
- `docs/SKILLS_AND_MCP.md` — Distinct roles of Skills, MCP (Streamable HTTP/SSE), and Connectors (incl. TeraBox honesty note)
- `docs/THIRD_PARTY_NOTICES.md` — Open-source and open-weight license notices
- `docs/TESTING_AND_STATUS_REPORT.md` — Test coverage and verified implementation classification

---

## License

Apache License 2.0 — Copyright 2026 **Abbas Adel Rahim (Cope / Mark)**. See `LICENSE` and `docs/THIRD_PARTY_NOTICES.md`.
