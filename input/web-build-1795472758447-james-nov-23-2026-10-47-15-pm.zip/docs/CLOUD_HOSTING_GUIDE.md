# Cloud Backend Hosting & Migration Guide

## Hosting Architecture Comparison

| Option | Resources | Background Scheduler Fit | Limitations / Caveats |
|---|---|---|---|
| **Oracle Cloud Always Free (OCI)** | Up to 4 Ampere A1 ARM OCPUs + 24 GB RAM + 200 GB Block Storage | **Best Free Fit**: Always-on Docker VM runs JAMES Backend + quantized 4B CPU inference without sleeping. | Credit-card verification on signup; ARM capacity varies by region. |
| **Google Cloud Run** | Serverless vCPU/RAM, 2M free req/mo | **Good for stateless HTTP API**: Requires external DB & paid min-instances for continuous daemons. | Scales to zero after idle; request timeout limits. |
| **Render / Fly.io Free/Hobby** | 256–512 MB RAM | Poor for open-weight models or long jobs; Render free tier sleeps after 15m idle. | Low RAM; unsuitable for LLM weights. |
| **Dedicated GPU VPS** | 24–48 GB VRAM (L4 / RTX 4090 / A10G) | **Recommended for 12B–32B vLLM & LoRA/QLoRA training.** | Paid usage; plug into JAMES Core anytime via endpoint URL. |

## Setup Script
See `backend/deploy/oci-always-free-setup.sh`, `backend/Dockerfile`, and `backend/docker-compose.yml`.

## 13-Step Cloud Migration Center
`RepositoryMigrationEngine` stages payload manifests with SHA-256 checksums, verifies transferred file digests byte-for-byte, supports rollback on mismatch or user command, and **requires secondary human approval** before marking original sources for cleanup/archival.
