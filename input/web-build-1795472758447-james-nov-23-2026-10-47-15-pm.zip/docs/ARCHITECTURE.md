# JAMES Architecture Guide

**Founder & Developer:** Abbas Adel Rahim (Cope / Mark)  
**Core Principle:** JAMES owns its identity, orchestration policies, verified knowledge, learning logs, encrypted vault, and skills. External LLMs (open-weight or cloud commercial) operate strictly as interchangeable backends behind the Model Abstraction Layer.

## High-Level Layers

1. **Presentation Layer (`ui/screens/`, `ui/components/`, `ui/theme/`, `ui/i18n/`)**
   - Native Jetpack Compose + Material 3 with full Dark/Light themes, accent palette, RTL Arabic & LTR English layout switching.
   - 14 original assistant screens + 8 expanded Ecosystem Control screens organized under the 22-section Control Center.

2. **ViewModel & State Layer (`ui/viewmodel/`)**
   - `MainAppViewModel`: Settings, history drawer, E2EE passphrases, Google Sign-In, data export/deletion.
   - `ChatViewModel`: Streaming chat lifecycle, attachments, voice mode, editing/regenerating/stopping, routing through `JamesCoreOrchestrator`.
   - `EcosystemViewModel`: Control Center, Providers/Runtimes, AI Council, Knowledge/Learning, Skills/MCP/Connectors, Cloud Migration, Scheduler, Private Vault, Diagnostics, and Audit Logs.

3. **JAMES Core & Domain Engines (`data/core/`)**
   - `JamesCoreOrchestrator`: Routing Policy evaluation (`PRIMARY_FIRST`, `BALANCED_HYBRID`, `COUNCIL_RESEARCH`, `FIREBASE_GEMINI_FALLBACK`, `BACKEND_DELEGATED`), TF-IDF knowledge enrichment, inspected skill guidance injection, memory injection, and automatic learning experience logging.
   - `CouncilOrchestrator`: 8-role bounded multi-round deliberations preserving disagreements and requiring human decision on `ImprovementProposal`.
   - `KnowledgeRetrievalEngine`, `LearningOrchestrator`, `SkillsInspector`, `McpHttpClient`, `CloudBackendClient`, `ConnectorProbeClient`, `RepositoryMigrationEngine`.

4. **Model Abstraction Layer (`data/ai/`)**
   - `UnifiedModelClient`: Standard HTTP client for `Ollama` (`/api/chat`), `llama.cpp` / `vLLM` / `OpenAI` / `DeepSeek` (`/v1/chat/completions`), and `Anthropic` (`/v1/messages`).
   - `GeminiAiService`: Built-in Firebase AI Logic (`Firebase.ai`) + App Check streaming and multimodal vision/PDF support.

5. **Security & Persistence Layer (`security/`, `data/local/`, `data/remote/`)**
   - `PrivateVaultManager`: Dedicated Android Keystore AES-256-GCM key (`james_private_vault_aes256_key`), PBKDF2-HMAC-SHA256 PIN lock, `BiometricPrompt`, encrypted credential storage, secret redaction.
   - `JamesDatabase` (Room SQLite v2 with verified `MIGRATION_1_2`) + DataStore Preferences + optional client-side E2EE Firestore sync.

6. **Independent Cloud Core Backend (`/backend/`)**
   - Standalone Node.js service providing server-side JAMES Core, Council, Knowledge, Learning, MCP, Migration, and bounded Scheduler over authenticated HTTP REST APIs.
