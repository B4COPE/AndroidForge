# External AI Provider Configuration Guide

Collaborator providers connect transparently beneath JAMES Core's Model Abstraction Layer:

1. **Firebase AI Logic (Gemini)**: Built-in default cloud fallback using App Check attestation (no manual API key entry needed inside the app).
2. **OpenAI** (`https://api.openai.com/v1/chat/completions`): Enter API key in **Control Center -> Open-Weight & AI Providers**. Stored exclusively in encrypted `PrivateVaultManager`.
3. **Anthropic Claude** (`https://api.anthropic.com/v1/messages`): Uses `x-api-key` + `anthropic-version: 2023-06-01` headers via `UnifiedModelClient`.
4. **DeepSeek** (`https://api.deepseek.com/v1/chat/completions`): OpenAI-compatible Bearer auth endpoint.
5. **Custom OpenAI-Compatible** (LM Studio, Together, Groq, self-hosted LiteLLM): Configure any HTTPS base URL and optional API key.

All providers expose a live **Test** button (`UnifiedModelClient.testConnection`), request/token usage telemetry, daily request caps, and estimated cost calculation.
