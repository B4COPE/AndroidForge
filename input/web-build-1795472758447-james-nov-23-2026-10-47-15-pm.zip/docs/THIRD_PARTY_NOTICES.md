# Third-Party Notices & Model Licenses

**Founder & Developer of JAMES:** Abbas Adel Rahim (Cope / Mark)

- **JAMES Original Code**: Apache License 2.0 (`LICENSE`).
- **Jetpack Compose / AndroidX / Room / DataStore / Biometric / OkHttp / Coroutines**: Apache License 2.0.
- **Firebase Android SDKs (Auth, Firestore, App Check, Firebase AI Logic)**: Apache License 2.0.
- **Google Gemma 3 Weights**: Subject to Google Gemma Terms of Use (open-weight with acceptable-use restrictions; not OSI-approved).
- **Alibaba Qwen 2.5 (14B)**: Apache License 2.0.
- **Meta Llama 3.1**: Meta Llama 3.1 Community License.
