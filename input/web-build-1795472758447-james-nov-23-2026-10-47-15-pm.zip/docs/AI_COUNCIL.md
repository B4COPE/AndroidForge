# JAMES Collaborative AI Council Architecture

## 8 Configured Governance Roles
1. **AI Architect** — Designs clean modular improvements.
2. **AI Researcher** — Evaluates retrieval, open-weight methods, and trade-offs.
3. **AI Developer** — Produces actionable Kotlin/Node implementation steps.
4. **AI Critic** — Surfaces edge cases and challenges weak assumptions.
5. **AI Security Auditor** — Audits credential isolation, SSRF, and prompt-injection risks.
6. **AI Tester** — Defines regression, unit, and Room migration verification plans.
7. **AI Knowledge Analyst** — Synthesizes reusable verified facts vs unverified hypotheses.
8. **JAMES Moderator** — Compares viewpoints while preserving genuine disagreements instead of forcing artificial consensus.

## Human-in-the-Loop Approval Gate
Every Council run produces an `ImprovementProposal` containing:
- Problem statement, proposed solution, expected benefits, potential risks, dependencies, implementation plan, test plan, and rollback plan.
- Initial status is always `PENDING`. Code/policy activation is strictly gated behind human decision (`APPROVED`, `REJECTED`, `ROLLED_BACK`).
