# Continuous Learning Engine & Persistent Knowledge Repository

## 1. Persistent Knowledge Lifecycle (`KnowledgeRetrievalEngine`)
1. **Normalization & Chunking**: Overlapping 520-char windows (`overlap = 80`) preserve semantic context across boundaries.
2. **SHA-256 Deduplication**: Identical entries are detected via `findKnowledgeByChecksum(...)` before insertion.
3. **Hybrid TF-IDF Retrieval**: Scores normalized tokens weighted by `reliabilityScore` and excludes `OUTDATED` knowledge.
4. **Verification Tracking**: Records track `source`, `sourceType`, `acquiredAtMillis`, `lastVerifiedAtMillis`, `reliabilityScore`, `confidence`, `version`, and `validationStatus` (`VERIFIED`, `PENDING_REVIEW`, `OUTDATED`, `DISPUTED`).

## 2. Experience-Driven Learning (`LearningOrchestrator`)
- Logs `SUCCESS`, `ERROR`, `GAP`, and `INSIGHT` outcomes with root cause and redacted lessons learned.
- Bounded learning cycles obey token budgets (`maxBudgetTokens`), flag unverified entries older than 30 days as `OUTDATED`, and never access `private_vault_items`.
