# JAMES Security & Threat Model

**Founder & Developer:** Abbas Adel Rahim (Cope / Mark)

## 1. Credential & API Key Isolation
- Zero hardcoded API keys in Kotlin source code, Gradle build scripts, or backend source.
- User-entered API tokens (`OpenAI`, `Anthropic`, `DeepSeek`, `Custom OpenAI`, `Cloud Backend`, `MCP Bearer Tokens`, `Connector Tokens`) are encrypted with **Android Keystore AES-256-GCM** inside `PrivateVaultManager`.
- `PrivateVaultManager.redactSecrets(...)` and `backend/src/security.js#redactSecrets(...)` scrub `sk-...`, `AIza...`, `Bearer ...`, and token/password key-value pairs before saving any `SystemLogEntity` or emitting logs.

## 2. Isolated Private Vault (`private_vault_items`)
- Uses a separate Android Keystore key alias (`james_private_vault_aes256_key`) distinct from general `CryptoManager`.
- Protected by PBKDF2-HMAC-SHA256 (100,000 iterations, random 128-bit salt, constant-time `MessageDigest.isEqual`) PIN verification and `BiometricPrompt`.
- Configurable auto-lock timeout (`1–60` minutes).
- Private Vault contents are **never** injected into AI chat context, learning cycles, exported JSON bundles, or unencrypted cloud sync.

## 3. Prompt-Injection & Skill Safety
- `SkillsInspector.inspectSkillMarkdown(...)` blocks skills containing destructive filesystem commands (`rm -rf`, `mkfs`), remote pipe-to-shell (`curl ... | sh`), arbitrary `eval`/`exec`, `ignore previous instructions` overrides, or `.env`/vault targeting.
- Script execution blocks are gated behind `allowSkillScriptExecution` (disabled by default).
- All external MCP tool responses are scrubbed and wrapped in `[UNTRUSTED_EXTERNAL_DATA source="..."] ... [/UNTRUSTED_EXTERNAL_DATA]` inside both Android (`SkillsInspector`) and Backend (`skillsAndMcp.js`).

## 4. Backend Protections (`backend/src/security.js`)
- Bearer authentication uses `crypto.timingSafeEqual`.
- File operations use `resolveSafePath` (`path.resolve` + `path.sep` boundary check) to stop path traversal.
- Outbound HTTP probes/connectors enforce `validateOutboundUrl` blocking loopback, link-local metadata (`169.254.169.254`), and private RFC-1918 ranges unless `ALLOW_LOCAL_INFERENCE=true` is explicitly enabled for local Ollama/llama.cpp/vLLM containers.
