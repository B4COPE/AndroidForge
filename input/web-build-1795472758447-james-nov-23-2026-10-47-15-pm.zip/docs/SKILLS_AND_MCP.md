# Skills, MCP Servers & Connectors — Clear Separation of Concerns

## 1. Skills (`SkillsInspector`)
- Markdown-based capability definitions (`SKILL.md`) stored locally and inspected for destructive commands, injection overrides, and unapproved script blocks before activation.

## 2. MCP Client (`McpHttpClient`)
- Model Context Protocol JSON-RPC 2.0 client supporting **Streamable HTTP** and **HTTP + SSE**.
- **Android Platform Boundary**: Android apps cannot spawn arbitrary desktop STDIO CLI subprocesses directly inside the sandbox; desktop STDIO servers must run behind a remote HTTPS/Streamable-HTTP bridge.
- Enforces per-call user approval (`requireApprovalPerCall`) and wraps all returned data in `[UNTRUSTED_EXTERNAL_DATA]`.

## 3. External Connectors (`ConnectorProbeClient`)
- Supports Google Drive (REST v3), WebDAV / Nextcloud, S3-Compatible (OCI / R2 / MinIO), Dropbox, OneDrive (Graph), and GitHub.
- **TeraBox Technical Honesty Notice**: TeraBox does **not** expose an official public OAuth/REST developer API for autonomous background sync. JAMES marks TeraBox `isSupportedOfficially = false` rather than bundling fragile, policy-violating web scrapers.
