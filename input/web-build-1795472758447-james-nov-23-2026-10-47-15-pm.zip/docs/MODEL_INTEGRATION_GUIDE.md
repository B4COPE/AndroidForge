# Open-Weight Model Integration & Licensing Guide

**Founder & Developer:** Abbas Adel Rahim (Cope / Mark)

## 1. Recommended Open-Weight Models
| Model | Org | License | OSI Open-Source? | Recommended Quantization | Min RAM/VRAM |
|---|---|---|---|---|---|
| Google Gemma 3 12B Instruct (`gemma3:12b-it`) | Google | Gemma Terms of Use | **No** (Open-weight with acceptable-use restrictions) | Q4_K_M (~7.8 GB) | 12 GB |
| Google Gemma 3 4B Instruct (`gemma3:4b-it`) | Google | Gemma Terms of Use | **No** | Q4_K_M (~2.8 GB) | 6 GB |
| Qwen 2.5 14B Instruct (`qwen2.5:14b-instruct`) | Alibaba | Apache 2.0 | **Yes (OSI)** | Q4_K_M (~9.0 GB) | 16 GB |
| Meta Llama 3.1 8B Instruct | Meta | Llama 3.1 Community License | **No** (Custom community terms) | Q4_K_M (~4.9 GB) | 8 GB |

*Note: Gemma open-weight models are completely separate from the proprietary Google Gemini cloud API.*

## 2. Supported Runtimes (`UnifiedModelClient` + Docker Compose Profiles)
- **Ollama** (`/api/chat`, `/api/tags`): `docker compose --profile ollama up -d`
- **llama.cpp Server** (`/v1/chat/completions` GGUF): `docker compose --profile llamacpp up -d`
- **vLLM Server** (`/v1/chat/completions` GPU high-throughput): `docker compose --profile vllm up -d`

## 3. Fine-Tuning & Continuous Improvement Boundary
- Full pre-training is outside free-tier compute; JAMES supports **domain LoRA / QLoRA** adaptation datasets exported from verified Knowledge & Learning experiences when a 16–24 GB VRAM GPU worker is connected.
- GPU training is **not** fabricated inside Android or CPU-only VMs.
